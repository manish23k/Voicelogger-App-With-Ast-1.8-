from flask import Flask, render_template
import mysql.connector

app = Flask(__name__)

# Define a route to display the dashboard page
@app.route('/dashboard')
def dashboard():
    # Connect to the Vicidial database and fetch data
    # Replace these database connection details with your own
    connection = mysql.connector.connect(
        host='localhost',
        user='cron',
        password='1234',
        database='asterisk'
    )
    cursor = connection.cursor()
    
    # Fetch data from the database (example query)
    cursor.execute('SELECT * FROM vicidial_closer_log')
    data = cursor.fetchall()
    
    # Close the database connection
    cursor.close()
    connection.close()
    
    # Render the dashboard template with the fetched data
    return render_template('dashboard.html', data=data)

if __name__ == '__main__':
    #app.run(debug=True)
	app.run(host='0.0.0.0', port=5000, debug=True)

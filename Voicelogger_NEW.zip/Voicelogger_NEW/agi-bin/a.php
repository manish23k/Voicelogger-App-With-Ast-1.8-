<?php
echo date('c');
?>

# This Code works with python v 3.6 only to run this script use python3.6 smdr.py
#for startup at boot
# nano /etc/systemd/system/smdr.service 
#[Unit]
#Description=SMDR Script

#[Service]
#ExecStart=/usr/bin/python3.6 /opt/smdr.py
#Restart=always
##User=root
#Group=root

#[Install]
#WantedBy=multi-user.target
## EOF

# Create folder mkdir -p /var/log/smdr/
#pip install import socket
#pip install mysql-connector-python

# SMDR DETAILS:-
# Listening for syslog messages on 192.168.0.201:5555...
# Accepted connection from ('192.168.0.250', 39969)
# Outgoing Calls data:-

# 12   4001 000 V001 OUTGOIGNNA         05-10-23 15:28:24     0    0    0.00  U

# These are some flags for OG calls
# Trunk            : C=CO,  B=BRI,  P=T1E1,  E=E&M,  M=MOB,  V=SIP
# Extension        : S=SLT,  D=DKP,  G=MAG,  I=SIP Extn,  R=Virtual Extn,  N=ISDN Extn
# CALL TYPE        : O=DISA,  A=Auto Redial,  E=External Forwarded,  G=Gateway,  T=Transfer, C=Conference
# MATURITY         : C=CPD,  R=Reversal,  D=Delay,  I=Connect,  U=Unanswered

# #################################################################################################################################
# Incoming Calls Data:-

# 53 9227201111@192.1 V001    MI   05-10-23   15:24:58  10   0     0 U

# These are some flags for IC Calls
# Trunk            : C=CO,  B=BRI,  P=T1E1,  E=E&M,  M=MOB,  V=SIP
# Extension        : S=SLT,  D=DKP,  G=MAG,  I=SIP Extn,  R=Virtual Extn,  N=ISDN Extn
# CALL TYPE        : N=Normal,  U=UnAnswered,  I=DISA,  G=Gateway,  T=Transfer,  Q=Qsig, C=Conference, F=Forward
#                    D=Built-In Auto Attendant,  DU=Built-In Auto Attendant Unanswered

# #################################################################################################################################
# Matrix PBX SMDR settings
# Parameter                      Start Column No.     Field Length

# Incoming Data format
# Serial Number                       01                 04
# Calling Number                      06                 16
# Trunk Number                        23                 05
# Connected Number                    29                 06
# Date                                36                 08
# Time                                47                 08
# Answer Duration                     56                 03
# Hold Duration                       60                 03
# Speech Duration                     64                 05
# Remarks                             70                 02

# Mysql Table Sructer for invoip and ogvoip
# invoip table
# CREATE TABLE IF NOT EXISTS `invoip` (
#   `month` tinyint(2) DEFAULT NULL,
#   `day` tinyint(2) DEFAULT NULL,
#   `time` char(8) DEFAULT NULL,
#   `PM` char(1) DEFAULT NULL,
#   `hrs` char(2) DEFAULT NULL,
#   `mins` char(2) DEFAULT NULL,
#   `sec` char(5) DEFAULT NULL,
#   `callingparty` char(20) DEFAULT NULL,
#   `leaddigit` char(3) DEFAULT NULL,
#   `calledno` char(26) DEFAULT NULL,
#   `calltype` char(2) DEFAULT NULL,
#   `calledparty` char(6) DEFAULT NULL,
#   `transferext` char(5) DEFAULT NULL,
#   `accountcode` int(12) DEFAULT NULL,
#   `year` char(4) DEFAULT NULL,
#   `id` int(11) NOT NULL AUTO_INCREMENT,
#   PRIMARY KEY (`id`)
# ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='voicecatch Import data table' AUTO_INCREMENT=0 ;

# Outgoing Data format
# Serial Number                      001                 004
# Calling Number                     006                 005
# Trunk Number                       012                 005
# Connected Number                   018                 019
# Date                               037                 010
# Time                               048                 008
# Duration                           057                 005
# Units                              063                 004
# Amount                             068                 007
# Remarks                            076                 002

# ogvoip table
# CREATE TABLE IF NOT EXISTS `ogvoip` (
#   `month` tinyint(2) DEFAULT NULL,
#   `day` tinyint(2) DEFAULT NULL,
#   `time` char(8) DEFAULT NULL,
#   `PM` char(1) DEFAULT NULL,
#   `hrs` char(2) DEFAULT NULL,
#   `mins` char(2) DEFAULT NULL,
#   `sec` char(5) DEFAULT NULL,
#   `callingparty` char(20) DEFAULT NULL,
#   `leaddigit` char(3) DEFAULT NULL,
#   `calledno` char(26) DEFAULT NULL,
#   `calltype` char(2) DEFAULT NULL,
#   `calledparty` char(6) DEFAULT NULL,
#   `acccode` char(3) DEFAULT NULL,
#   `cost` int(12) DEFAULT NULL,
#   `year` char(4) DEFAULT NULL,
#   `id` int(11) NOT NULL AUTO_INCREMENT,
#   PRIMARY KEY (`id`)
# ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='voicecatch Import data table' AUTO_INCREMENT=0 ;

# TODO:-
# 1. log file create for output messages into /var/log/smdr/DD-MM-YYYY.log
# 2. insert data into the invoip or ogvoip as per call direction
# 3. will change MAtrix default SMDR to custom format to capture No Answet OG calls number.

# added logging of all messages into /var/log/smdr/DD-MM-YYYY.log
# END OF DETAILS
import socket
import logging
import datetime
import time
from MySQLdb import _mysql

def parse_ic(syslog_message):
    call_data = {}
    call_data["call_type"] = "IC"
    call_data["month"] = syslog_message[36:38].strip() 
    call_data["day"] = syslog_message[33:35].strip()  
    call_data["time"] = syslog_message[44:54].strip() 
    call_data["PM"] = syslog_message[00:00].strip() 
    call_data["hrs"] = syslog_message[00:00].strip()
    call_data["mins"] = syslog_message[00:00].strip()
    call_data["sec"] = syslog_message[64:66].strip() #duration
    call_data["callingparty"] = syslog_message[3:20].strip()  #NUMBER
    call_data["leaddigit"] = syslog_message[0:0].strip() 
    call_data["calledno"] = syslog_message[20:25].strip()    #TRUNK
    call_data["calltype"] = syslog_message[67:70].strip() 
    call_data["calledparty"] = syslog_message[28:33].strip()  #EXT
    call_data["transferext"] = syslog_message[00:00].strip()
    call_data["accountcode"] = syslog_message[68:75].strip()	
    call_data["year"] = time.strftime("%Y", time.localtime())
    return call_data


def insert_ic(call_data):
    sql = "INSERT INTO invoip (month, day, time, PM, hrs, mins, sec, callingparty, leaddigit, calledno, calltype, calledparty, transferext, accountcode, year) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s','%s','%s','%s')"
    val = (
        call_data["month"],
        call_data["day"],
        call_data["time"],
        call_data["PM"],
        call_data["hrs"],
        call_data["mins"],
        call_data["sec"],
        call_data["callingparty"],
        call_data["leaddigit"],
        call_data["calledno"],
        call_data["calltype"],
        call_data["calledparty"],
        call_data["transferext"],
        call_data["accountcode"],
        call_data["year"],
    )
    print(val)
    mydb.query(sql % val)
    mydb.commit()

    return

# Outgoing Call parse
def parse_og(syslog_message):
    call_data = {}
    call_data["call_type"] = "OG"
    call_data["month"] = syslog_message[46:48].strip() 
    call_data["day"] = syslog_message[43:45].strip()  
    call_data["time"] = syslog_message[54:62].strip() 
    call_data["PM"] = syslog_message[00:00].strip() 
    call_data["hrs"] = syslog_message[00:00].strip()
    call_data["mins"] = syslog_message[00:00].strip()
    call_data["sec"] = syslog_message[64:69].strip()
    call_data["callingparty"] = syslog_message[12:17].strip()
    call_data["leaddigit"] = syslog_message[6:7].strip() 
    call_data["calledno"] = syslog_message[18:30].strip()
    call_data["calltype"] = syslog_message[76:79].strip() 
    call_data["calledparty"] = syslog_message[5:13].strip()
    call_data["acccode"] = syslog_message[00:00].strip()
    call_data["cost"] = syslog_message[68:75].strip()	
    call_data["year"] = time.strftime("%Y", time.localtime())
    return call_data

def insert_og(call_data):
    sql = "INSERT INTO ogvoip (month, day, time, PM, hrs, mins, sec, callingparty, leaddigit, calledno, calltype, calledparty, acccode, cost, year) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s','%s','%s','%s')"
    val = (
        call_data["month"],
        call_data["day"],
        call_data["time"],
        call_data["PM"],
        call_data["hrs"],
        call_data["mins"],
        call_data["sec"],
        call_data["callingparty"],
        call_data["leaddigit"],
        call_data["calledno"],
        call_data["calltype"],
        call_data["calledparty"],
        call_data["acccode"],
        call_data["cost"],
        call_data["year"],
    )
    print(val)
    mydb.query(sql % val)
    mydb.commit()

    return




def main():
    global mydb

    mydb = _mysql.connect(
        host="localhost",
        user="cron",
        passwd="1234",
        #database="cron",
        db="voicecatch",
        port=3306,
        charset="utf8",
    )

    host = "192.168.0.201"  # This Server IP ADDRESS where data is recieved
    port = 5555  # PBX SMDR TCP port

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)

    print("Listening for syslog messages on {}:{}...".format(host, port))

    logging.basicConfig(
        filename="/var/log/smdr/{}.log".format(
            datetime.datetime.now().strftime("%d-%m-%Y")
        ),
        format="%(asctime)s %(message)s",
        datefmt="%m/%d/%Y %I:%M:'%s' %p",
        level=logging.DEBUG,
    )

    while True:
        client_socket, client_address = server_socket.accept()
        print("Accepted connection from {}".format(client_address))

        try:
            while True:
                data = client_socket.recv(1024)
                if not data:
                    break

                syslog_message = data.decode("utf-8").strip()

                # Print the entire syslog message without modification
                logging.info(syslog_message)
                print(syslog_message)

                # parse the syslog message into its PRI, HEADER, and MSG components
                # determine if syslog message refers to incoming or outgoing
                syslog_len = len(syslog_message)
                call_data = {}
                call_type = "NA"

                if syslog_len > 72:
                    call_type = "OG"
                    call_data = parse_og(syslog_message)
                    print(call_data)
                    insert_og(call_data)

                # #8   4001 V001             9227545645   09-10-2023 15:43:36    0    0.00  U  = Outgoing NA Call    
                # elif syslog_len == 74:  # New condition for OG_NA count total lengh and -1.
                #     call_type = "OG_NA"
                #     call_data = parse_og_na(syslog_message)
                #     print(call_data)
                #     insert_og_na(call_data)

                elif syslog_len == 68:
                    call_type = "IC"
                    call_data = parse_ic(syslog_message)
                    print(call_data)
                    insert_ic(call_data)

                
    

        except KeyboardInterrupt:
            print("Server terminated by user.")
            break

        except Exception as e:
            print("Error: {}".format(e))

        finally:
            client_socket.close()

    server_socket.close()


if __name__ == "__main__":
    main()

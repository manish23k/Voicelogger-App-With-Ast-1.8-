-- MariaDB dump 10.19  Distrib 10.6.15-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: voicecatch
-- ------------------------------------------------------
-- Server version	10.6.15-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `autobackup`
--

DROP TABLE IF EXISTS `autobackup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autobackup` (
  `backuptime` time DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autobackup`
--

LOCK TABLES `autobackup` WRITE;
/*!40000 ALTER TABLE `autobackup` DISABLE KEYS */;
INSERT INTO `autobackup` VALUES ('17:45:00');
/*!40000 ALTER TABLE `autobackup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avayaagents`
--

DROP TABLE IF EXISTS `avayaagents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avayaagents` (
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `exten` varchar(10) DEFAULT NULL,
  KEY `index4` (`exten`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avayaagents`
--

LOCK TABLES `avayaagents` WRITE;
/*!40000 ALTER TABLE `avayaagents` DISABLE KEYS */;
/*!40000 ALTER TABLE `avayaagents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avayacdr`
--

DROP TABLE IF EXISTS `avayacdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avayacdr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calldate` datetime DEFAULT NULL,
  `direction` char(1) DEFAULT NULL,
  `exten` varchar(10) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `mapped` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calldate` (`calldate`),
  KEY `index3` (`exten`),
  KEY `index10` (`calldate`),
  KEY `phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avayacdr`
--

LOCK TABLES `avayacdr` WRITE;
/*!40000 ALTER TABLE `avayacdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `avayacdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calldetails`
--

DROP TABLE IF EXISTS `calldetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calldetails` (
  `PhoneNumber` varchar(50) DEFAULT NULL,
  `Extension` varchar(50) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Filename` varchar(100) DEFAULT NULL,
  `pri` varchar(1) DEFAULT NULL,
  `callidpk` int(11) NOT NULL AUTO_INCREMENT,
  `agentid` varchar(50) DEFAULT NULL,
  `isbackedup` int(11) DEFAULT NULL,
  `test` int(11) DEFAULT NULL,
  `pbxextn` varchar(50) DEFAULT NULL,
  `isprocessed` int(11) DEFAULT 0,
  PRIMARY KEY (`callidpk`),
  KEY `starttime` (`StartTime`),
  KEY `phonenumber` (`PhoneNumber`),
  KEY `calls_phonenumber` (`PhoneNumber`,`Extension`,`Filename`),
  KEY `index1` (`PhoneNumber`),
  KEY `index6` (`Filename`),
  KEY `index7` (`StartTime`),
  KEY `index9` (`EndTime`)
) ENGINE=InnoDB AUTO_INCREMENT=142613 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calldetails`
--



--
-- Table structure for table `channelnames`
--

DROP TABLE IF EXISTS `channelnames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channelnames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unitid` int(11) DEFAULT NULL,
  `linenumber` int(11) DEFAULT NULL,
  `channelname` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channelnames`
--



--
-- Table structure for table `commentsmaster`
--

DROP TABLE IF EXISTS `commentsmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commentsmaster` (
  `Filename` varchar(100) DEFAULT NULL,
  `CustName` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(50) DEFAULT NULL,
  `Extension` varchar(50) DEFAULT NULL,
  `UserID` varchar(50) DEFAULT NULL,
  `UserName` varchar(50) DEFAULT NULL,
  `DateTime` datetime DEFAULT NULL,
  `Comments` text DEFAULT NULL,
  KEY `index5` (`Filename`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commentsmaster`
--



--
-- Table structure for table `contact_phone`
--

DROP TABLE IF EXISTS `contact_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_phone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_id` int(11) DEFAULT NULL,
  `phonenumber` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_phone`
--

LOCK TABLES `contact_phone` WRITE;
/*!40000 ALTER TABLE `contact_phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `ContactId` int(11) NOT NULL AUTO_INCREMENT,
  `CustName` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(50) DEFAULT NULL,
  `MobileNumber` varchar(50) DEFAULT NULL,
  `AlternatePhoneNumber` varchar(50) DEFAULT NULL,
  `Company` varchar(50) DEFAULT NULL,
  `AlternateMobileNumber` varchar(50) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `CustId` int(11) DEFAULT NULL,
  PRIMARY KEY (`ContactId`),
  KEY `index8` (`PhoneNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupextensions`
--

DROP TABLE IF EXISTS `groupextensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groupextensions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupextensions`
--

LOCK TABLES `groupextensions` WRITE;
/*!40000 ALTER TABLE `groupextensions` DISABLE KEYS */;
INSERT INTO `groupextensions` VALUES (6,1,'+917922804655');
/*!40000 ALTER TABLE `groupextensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'dsadasd');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoip`
--

DROP TABLE IF EXISTS `invoip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoip` (
  `month` tinyint(2) DEFAULT NULL,
  `day` tinyint(2) DEFAULT NULL,
  `time` char(8) DEFAULT NULL,
  `PM` char(1) DEFAULT NULL,
  `hrs` char(2) DEFAULT NULL,
  `mins` char(2) DEFAULT NULL,
  `sec` char(5) DEFAULT NULL,
  `callingparty` char(20) DEFAULT NULL,
  `leaddigit` char(3) DEFAULT NULL,
  `calledno` char(26) DEFAULT NULL,
  `calltype` char(2) DEFAULT NULL,
  `calledparty` char(6) DEFAULT NULL,
  `transferext` char(5) DEFAULT NULL,
  `accountcode` int(12) DEFAULT NULL,
  `year` char(4) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=79518 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='smdr Import data table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoip`
--


--
-- Table structure for table `landings`
--

DROP TABLE IF EXISTS `landings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `landings` (
  `extension` varchar(200) DEFAULT NULL,
  `callerid` varchar(200) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `callername` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landings`
--

LOCK TABLES `landings` WRITE;
/*!40000 ALTER TABLE `landings` DISABLE KEYS */;
/*!40000 ALTER TABLE `landings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logrules`
--

DROP TABLE IF EXISTS `logrules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logrules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phonenumber` varchar(50) DEFAULT NULL,
  `numbertype` varchar(50) DEFAULT NULL,
  `logflag` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logrules`
--

LOCK TABLES `logrules` WRITE;
/*!40000 ALTER TABLE `logrules` DISABLE KEYS */;
/*!40000 ALTER TABLE `logrules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logsettings`
--

DROP TABLE IF EXISTS `logsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phonenumber` varchar(38) DEFAULT NULL,
  `phonetype` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logsettings`
--

LOCK TABLES `logsettings` WRITE;
/*!40000 ALTER TABLE `logsettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `logsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitoring`
--

DROP TABLE IF EXISTS `monitoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitoring` (
  `location` varchar(200) DEFAULT NULL,
  `logtimestamp` varchar(200) DEFAULT NULL,
  `msgrtterm` varchar(200) DEFAULT NULL,
  `msgrtapp` varchar(200) DEFAULT NULL,
  `msgrttermstop` varchar(200) DEFAULT NULL,
  `msgrtappstop` varchar(200) DEFAULT NULL,
  `msgline1` varchar(200) DEFAULT NULL,
  `msgline2` varchar(200) DEFAULT NULL,
  `msgline3` varchar(200) DEFAULT NULL,
  `msgline4` varchar(200) DEFAULT NULL,
  `msgline5` varchar(200) DEFAULT NULL,
  `msgline6` varchar(200) DEFAULT NULL,
  `msgline7` varchar(200) DEFAULT NULL,
  `msgline8` varchar(200) DEFAULT NULL,
  `msgline9` varchar(200) DEFAULT NULL,
  `msgline10` varchar(200) DEFAULT NULL,
  `msgline11` varchar(200) DEFAULT NULL,
  `msgline12` varchar(200) DEFAULT NULL,
  `msgline13` varchar(200) DEFAULT NULL,
  `msgline14` varchar(200) DEFAULT NULL,
  `msgline15` varchar(200) DEFAULT NULL,
  `msgline16` varchar(200) DEFAULT NULL,
  `exerunning` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitoring`
--

LOCK TABLES `monitoring` WRITE;
/*!40000 ALTER TABLE `monitoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `monitoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ogvoip`
--

DROP TABLE IF EXISTS `ogvoip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ogvoip` (
  `month` tinyint(2) DEFAULT NULL,
  `day` tinyint(2) DEFAULT NULL,
  `time` char(8) DEFAULT NULL,
  `PM` char(1) DEFAULT NULL,
  `hrs` char(2) DEFAULT NULL,
  `mins` char(2) DEFAULT NULL,
  `sec` char(5) DEFAULT NULL,
  `callingparty` char(20) DEFAULT NULL,
  `leaddigit` char(3) DEFAULT NULL,
  `calledno` char(26) DEFAULT NULL,
  `calltype` char(2) DEFAULT NULL,
  `calledparty` char(6) DEFAULT NULL,
  `acccode` char(3) DEFAULT NULL,
  `cost` int(12) DEFAULT NULL,
  `year` char(4) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32338 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='smdr Import data table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ogvoip`
--



--
-- Table structure for table `othercalls`
--

DROP TABLE IF EXISTS `othercalls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `othercalls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniqueprimaryid` int(11) DEFAULT NULL,
  `unitid` int(11) DEFAULT NULL,
  `linenumber` int(11) DEFAULT NULL,
  `calldate` datetime DEFAULT NULL,
  `calltime` float DEFAULT NULL,
  `duration` float DEFAULT NULL,
  `clid` varchar(50) DEFAULT NULL,
  `calltype` int(11) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `clientcustid` varchar(50) DEFAULT NULL,
  `phonetype` int(11) DEFAULT NULL,
  `isbackedup` int(11) DEFAULT NULL,
  `locationname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `othercalls`
--

LOCK TABLES `othercalls` WRITE;
/*!40000 ALTER TABLE `othercalls` DISABLE KEYS */;
/*!40000 ALTER TABLE `othercalls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdetails`
--

DROP TABLE IF EXISTS `userdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userdetails` (
  `UserID` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Extension` varchar(50) DEFAULT NULL,
  `groupid` int(11) DEFAULT NULL,
  `playright` int(11) DEFAULT NULL,
  `deleteright` int(11) DEFAULT NULL,
  `downloadright` int(11) DEFAULT NULL,
  `commentright` int(11) DEFAULT NULL,
  `callsdownload` int(11) DEFAULT NULL,
  `callsdelete` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdetails`
--

LOCK TABLES `userdetails` WRITE;
/*!40000 ALTER TABLE `userdetails` DISABLE KEYS */;
INSERT INTO `userdetails` VALUES ('admin','YWRtaW4=','System Administrator','',0,1,1,1,1,1,1),('Nitin','cmFqYTIwMjQ=','Nitin','',0,1,0,1,1,0,0);
/*!40000 ALTER TABLE `userdetails` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-14 12:05:38

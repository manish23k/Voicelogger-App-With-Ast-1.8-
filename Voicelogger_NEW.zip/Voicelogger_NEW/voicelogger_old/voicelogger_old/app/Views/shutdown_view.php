<h1>System Shutdown</h1>
<?php echo form_open('/shutdown/confirm'); ?>
<tr>
<td><?php echo form_submit('shutdown', 'Shutdown');?></td>
</tr>

<tr>
<td><?php echo form_submit('reboot', 'Reboot');?></td>
</tr>
<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<?php echo form_open("/clients/add"); ?>
Client Id <?php echo form_input(array("name" => 'custid', "id" => 'custid'));?><br/>
Client Name <?php echo form_input(array("name" => 'custname', "id" => 'custname'));?><br/>
Company <?php echo form_input(array('name' => 'company', 'id' => 'company'))?><br/>
Address <?php echo form_textarea(array('name'=>'address', 'id'=>'address'));?><br/>
Phone 1 <?php echo form_input(array("name" => 'phonenumber', "id" => 'phonenumber'));?><br/>
Phone 2 <?php echo form_input(array("name" => 'mobilenumber', "id" => 'mobilenumber'));?><br/>
Phone 3 <?php echo form_input(array("name" => 'alternatephonenumber', "id" => 'alternatephonenumber'));?><br/>
Phone 4 <?php echo form_input(array("name" => 'alternatemobilenumber', "id" => 'alternatemobilenumber'));?><br/>
<!-- <?php echo form_submit("submit", "Add");?> -->
<div class="form-actions">
	<button type="submit" class="btn">Add</button>
</div>
<?php echo form_close();?>
<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<?php echo form_open("/incomingcheck/add"); ?>
Name <?php echo form_input(array("name" => 'extension', "id" => 'extension'));?><br/>
Number <?php echo form_input(array("name" => 'extension', "id" => 'number'));?><br/>
<?php echo form_submit("submit", "Add");?>
<?php echo form_close();?>
<?php
$session = \Config\Services::session();
?>

<head>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- Include Flatpickr CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>

<body>
    <div class="container">
        <h2>Customize Time and Duration Fields</h2>
        <?php echo form_open("/calls/search"); ?>
        <div class="form-group">
            <label for="custom_start_time">Start Time (HH:MM:SS):</label>
            <input type="text" class="form-control" name="custom_start_time" id="custom_start_time" value="<?php echo $session->get('csstarttime'); ?>" placeholder="HH:MM:SS" autocomplete="off">
        </div>
        <div class="form-group">
            <label for="custom_end_time">End Time (HH:MM:SS):</label>
            <input type="text" class="form-control" name="custom_end_time" id="custom_end_time" value="<?php echo $session->get('csendtime'); ?>" placeholder="HH:MM:SS" autocomplete="off">
        </div>
        <div class="form-group">
            <label for="custom_start_duration">Start Duration (HH:MM:SS):</label>
            <input type="text" class="form-control" name="custom_start_duration" id="custom_start_duration" value="<?php echo $session->get('csstartduration'); ?>" placeholder="HH:MM:SS" autocomplete="off">
        </div>
        <div class="form-group">
            <label for="custom_end_duration">End Duration (HH:MM:SS):</label>
            <input type="text" class="form-control" name="custom_end_duration" id="custom_end_duration" value="<?php echo $session->get('csendduration'); ?>" placeholder="HH:MM:SS" autocomplete="off">
        </div>
        <?php echo form_submit('submit', 'Search', 'class="btn btn-primary"'); ?>
        <?php echo form_submit('clear', 'Clear', 'id="clear-button" class="btn btn-secondary"'); ?>
        <?php echo form_close(); ?>
    </div>

    <!-- Include jQuery library -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Include Flatpickr JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            // Initialize Flatpickr for date and time inputs
            flatpickr("#custom_start_time, #custom_end_time, #custom_start_duration, #custom_end_duration", {
                enableTime: true,
                enableSeconds: true,
                noCalendar: true,
                dateFormat: "H:i:S",
                defaultDate: "<?php echo $session->get('csstarttime'); ?>",
                allowInput: true,
                clickOpens: true,
                onClose: function(selectedDates, dateStr, instance) {
                    if (!dateStr) {
                        instance.clear();
                    }
                }
            });
        });
    </script>
</body>

</html>

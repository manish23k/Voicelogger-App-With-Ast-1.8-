<h1>Shutdown</h1>
<p>You are about to Shutdown/Reboot System.</p>

<p>All Running Calls and Recordings will be stop Press Shutdown/Rebbot ONLY IF YOU ARE SURE</p>

<?php echo form_open('/shutdown/process'); ?>
<?php echo form_submit('submit', 'Shutdown'); ?>
<td>
<?php echo form_submit('submit', 'Reboot'); ?>
</td>
<?php echo form_close(); ?>

<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
*/

$session = \Config\Services::session();

?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#startdate').datepick({
            dateFormat: 'yy-mm-dd'
        });
        $('#enddate').datepick({
            dateFormat: 'yy-mm-dd'
        });

        $('#id-select-all').click(function() {
            if ($('#id-select-all').attr('checked'))
                $(':checkbox').attr('checked', 'checked');
            else
                $(':checkbox').removeAttr('checked');
        });
    });
</script>

 
<!--<?php echo anchor("/calls/index/$previous", "Previous"); ?> <?php echo anchor("/calls/index/$next", "Next"); ?> -->
 
 <a title="Previous Page"   href="<?php echo site_url() . "/calls/index/$previous" ?>">
                        <img border="0"  src="<?php echo base_url() . 'images/icon_left_arrow.png' ?>" /> 
                        </a>
                 
                      
 <a title="Next Page"  href="<?php echo site_url() . "/calls/index/$next" ?>">
                        <img border="0" style="float:right" src="<?php echo base_url() . 'images/icon_right_arrow.png' ?>" />
                    </a> 
                    
                   

<div>
    <?php echo form_open("/calls/search"); ?>
    <table>
        <tr>
            <td>Call Type</td>
            <td><?php echo form_dropdown('calltype', array('incoming' => 'Incoming', 'outgoing' => 'Outgoing', 'mi' => 'Missed', 'na' => 'No Answer', 'xx' => 'All'), $session->get('cscalltype')); ?></td>
        </tr>
        <tr>
            <td>Date</td>
            <td>
                <?php echo form_input(array('name' => 'startdate', 'id' => 'startdate'), $session->get('csstartdate')); ?>
                <?php echo form_input(array('name' => 'enddate', 'id' => 'enddate'), $session->get('csenddate')); ?>
            </td>
            <td>Time
                (HH:MM:SS)
            </td>
            <td>
                <?php echo form_input('starttime', $session->get('csstarttime')); ?>
                <?php echo form_input('endtime', $session->get('csendtime')); ?>
            </td>
            <td>
                Duration
                (HH:MM:SS)
            </td>
            <td>
                <?php echo form_input('startduration', $session->get('csstartduration')); ?>
                <?php echo form_input('endduration', $session->get('csendduration')); ?>

            </td>
        </tr>
        <tr>
            <td>Client Id</td>
            <td><?php echo form_input('clientid', $session->get('csclientid')); ?></td>
            <td>Client Name</td>
            <td><?php echo form_input('clientname', $session->get('csclientname')); ?></td>
            <td>Phone</td>
            <td><?php echo form_input('phonenumber', $session->get('csphonenumber')); ?>
            </td>
        </tr>
        <tr>
            <td>Comments</td>
            <td><?php echo form_input('comments', $session->get('cscomments')); ?></td>
            <td>Extensions</td>
            <td><?php echo form_input('extension', $session->get('csextension')); ?></td>
        </tr>
    </table>
    <?php echo form_submit('submit', 'Search'); ?>
    <?php echo form_close(); ?>
</div>
<!-- <?php echo anchor('/calls/index/download', 'Download CSVs'); ?> -->


<div>

    <?php echo form_open("/calls/multiselect"); ?>
    
    <a title="Downalod CSV" style="float:left" href="<?php echo site_url() . '/calls/index/download' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/csv.png' ?>" />
                    </a>&nbsp;&nbsp;&nbsp;

    <?php if ($session->get('callsdownload') == '1') { ?>
        <?php echo form_submit('submit', 'Download Selected'); ?>&nbsp;&nbsp;&nbsp;
    <?php } ?>


    <?php if ($session->get('callsdelete') == '1') { ?>
        <?php echo form_submit('submit', 'Delete Selected'); ?>
    <?php } ?>
    <table>
        <tr>
            <!--<th>Mark</th>-->
            <th><input type="checkbox" value="on" name="allbox" id="id-select-all"><strong>Select</strong></td>
            </th>

            <th>Extension</th>
            <th>CLID</th>
            <th>Date</th>
            <th>Time</th>
            <th>Duration</th>
            <th>Call Type</th>
            <th>Actions</th>
            <th>Client</th>
            <th>Comments</th>
        </tr>

        <?php foreach ($result->getResult() as $row) : ?>
            <?php
            $calltype = $session->get('cscalltype');
            if (($calltype == 'mi' || $calltype == 'na') && file_exists(config(App::class)->recording_path . $row->FileName)) {
                continue;
            }
            if (($calltype == 'incoming' || $calltype == 'outgoing') && !file_exists(config(App::class)->recording_path . $row->FileName)) {
                continue;
            }
            ?>
            <tr>

                <td><?php echo form_checkbox('filenames[]', $row->FileName) ?></td>
                <td><?php echo $row->Extension; ?></td>
                <td><?php echo $row->PhoneNumber; ?></td>
                <td><?php echo $row->StartDate; ?></td>
                <td><?php echo $row->StartTimeTime; ?></td>
                <td><?php echo $row->Duration; ?></td>
                <td>
                    <?php
                    if ($row->Type == 'incoming') {
                        // echo config(App::class)->recording_path . $row->FileName;
                        if (!file_exists(config(App::class)->recording_path . $row->FileName)) {
                            echo 'Missed';
                        } else {
                            echo $row->Type;
                        }
                    } else {
                        if (!file_exists(config(App::class)->recording_path . $row->FileName)) {
                            echo 'No Answer';
                        } else {
                            echo $row->Type;
                        }
                    }
                    ?>
                <td>
                    <?php if ($session->get('playright') == '1' && file_exists(config(App::class)->recording_path . $row->FileName)) { ?>
                        <audio controls>
                            <source src="<?php echo '/recordings/files/' . $row->FileName ?>" type="audio/mpeg">
                        </audio>

                        <a title="play" href="#" onclick='playfile("<?php echo site_url() . "/wave/play/" . $row->FileName; ?>")'>
                            <!--<img border="0" src='<?php echo base_url() . "images/icon_play.png" ?>' />-->
                        </a>
                    <?php } ?>
                    <?php if ($session->get('downloadright') == '1' && file_exists(config(App::class)->recording_path . $row->FileName)) { ?>
                        <a title="Download" style="text-decoration: none" href="<?php echo site_url() . "/wave/download/" . $row->FileName; ?>">
                            <img border="0" src='<?php echo base_url() . "images/icon_download large.gif" ?>' />
                        </a>
                    <?php } ?>
                    <?php if ($session->get('deleteright') == '1') { ?>
                        <a title="Delete" style="text-decoration: none" href="#" onclick='playfile("<?php echo site_url() . "/wave/delete/" . $row->FileName; ?>")'>
                            <img border="0" src='<?php echo base_url() . "images/icon_delete large.gif" ?>' />
                        </a>
                    <?php } ?>
                </td>
                <td><?php echo $row->custname; ?></td>
                <!--<td><?php echo nl2br($row->comments); ?><br /><?php echo anchor("/calls/comments/$row->FileName", 'edit'); ?></td>-->
                <td><?php echo nl2br($row->comments); ?><br />
                    <!-- <?php echo anchor("/calls/comments/$row->FileName",); ?> -->
                    <a title="Comment" href="<?php echo site_url() . '/calls/comments/' . $row->FileName ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_edit.gif' ?>" />
                    </a>
                </td>            
            </tr>
        <?php endforeach; ?>
    </table>
    <?php echo form_close(); ?>

</div>
<!--<?php echo anchor("/calls/index/$previous", "Previous"); ?> <?php echo anchor("/calls/index/$next", "Next"); ?>-->
 <a title="Previous Page"   href="<?php echo site_url() . "/calls/index/$previous" ?>">
                        <img border="0"  src="<?php echo base_url() . 'images/icon_left_arrow.png' ?>" /> 
                        </a>
                 
                      
 <a title="Next Page"  href="<?php echo site_url() . "/calls/index/$next" ?>">
                        <img border="0" style="float:right" src="<?php echo base_url() . 'images/icon_right_arrow.png' ?>" />
                    </a> 
                    
<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<!-- <td><?php echo anchor("/clients/add", "New Phonebook Entry"); ?></td>&nbsp;&nbsp;&nbsp;
<td><?php echo anchor("/clients/upload", "Upload Phonebook Entry"); ?></td> -->
<td> <a title="Add New Phonebook Entry" style="text-decoration: none" href="<?php echo site_url() . '/clients/add' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_newcontact.png' ?>" />
</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a title="Upload Phonebook" style="text-decoration: none" href="<?php echo site_url() . '/clients/upload' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_phonebookupload.gif' ?>" />
</a>
</td>
<table>
    <tr>
        <th>Cust ID</th>
        <th>Cust Name</th>
        <th>Company</th>
        <th>Address</th>
        <th>Phone 1</th>
        <th>MobileNumber</th>
        <th>Alternate PH</th>
        <th>Alternate MB</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($result->getResult() as $row) : ?>
        <tr>
            <td><?php echo $row->CustId; ?></td>
            <td><?php echo $row->CustName; ?></td>
            <td><?php echo $row->Company; ?></td>
            <td><?php echo nl2br($row->Address); ?></td>
            <td><?php echo $row->PhoneNumber; ?></td>
            <td><?php echo $row->MobileNumber; ?></td>
            <td><?php echo $row->AlternatePhoneNumber; ?></td>
            <td><?php echo $row->AlternateMobileNumber; ?></td>
            <!-- <td><?php echo anchor("/clients/edit/$row->ContactId", "Edit"); ?>
                <?php echo anchor("/clients/delete/$row->ContactId", "Delete"); ?></td> -->
                <td> <a title="Edit" style="text-decoration: none" href="<?php echo site_url() . '/clients/edit/' . $row->ContactId ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_edit.png' ?>" />
</a>
					<a title="Delete" style="text-decoration: none" href="<?php echo site_url() . '/clients/delete/' . $row->ContactId ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_delete.png' ?>" />
</a>
</td>
        </tr>
    <?php endforeach; ?>
</table>
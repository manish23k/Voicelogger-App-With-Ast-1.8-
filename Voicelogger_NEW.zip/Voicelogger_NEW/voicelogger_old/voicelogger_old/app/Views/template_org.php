<html>

<head>
    <title>VoiceCatch Ver-2.0</title>
    <style type="text/css">
        body {
            background-color: white;
            /*font-family: Arial, Verdana, sans-serif;*/
            font: 0.8em Verdana, Geneva, Arial, Helvetica, sans-serif;
            margin: 0;
            padding: 0;
        }

        #wrapper {
            margin: 10px auto;
            padding: 10px;
            background-color: #FFFFFF;
            border: 2px solid #0000FF;
        }

        #nav {
            display: block;
            height: auto;
            padding: 25px;
        }

        #nav a {}

        #main {
            margin-left: 0px;
            height: auto;
        }

        #header {
            font-size: 12px;
            margin-bottom: 10px;
            display: block;
            border: 1px solid black;
        }

        #header h2 {
            display: inline;
            float: right;
        }

        #header img {}

        #footer {
            clear: both;
            padding-top: 40px;
            font-size: 9px;
        }

        table {
            border: 2px solid #D6DDE6;
            border-collapse: collapse;
        }

        table td,
        table th {
            border: 1px solid #73C0D4;
            text-align: right;
            padding: 0.2em;
        }

        table th {
            font-weight: bold;
            text-align: left;
            background-color: #BCBCBC;
        }

        table tr:nth-child(odd) {
            background-color: #DFE7F2;
            color: #000000;
        }

        table tr:hover {
            background-color: #DFE7F2;
            color: #000000;
        }

        form {
            border: 1px dotted #AAAAAA;
            padding: 0.5em;
        }

        input {
            color: #00008B;
            background-color: #ADD8E6;
            border: 1px solid #00008B;
        }

        select {
            width: 100px;
            color: #00008B;
            background-color: #ADD8E6;
            border: 1px solid #00008B;
        }

        textarea {
            width: 200px;
            height: 40px;
            color: #00008B;
            background-color: #ADD8E6;
            border: 1px solid #00008B;
        }

        form input:focus {
            border: 2px solid #000000;
        }

        form div {
            clear: left;
            margin: 0;
            padding: 0;
            padding-top: 0.6em;
        }

        form div label {
            float: left;
            width: 40%;
            font: bold 0.9em Arial, Helvetica, sans-serif;
        }

        a:hover {
            text-decoration: blink;
            color: #006600;
        }
    </style>
    <script type="text/javascript" src="<?php echo base_url(); ?>scripts/playfuncs.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>scripts/jquery-1.3.2.min.js"></script>
    <style type="text/css">
        @import "<?php echo base_url(); ?>scripts/datepicker/jquery.datepick.css";
    </style>
    <script type="text/javascript" src="<?php echo base_url(); ?>scripts/datepicker/jquery.datepick.js"></script>
    <script src='<?php echo base_url() ?>scripts/js/bootstrap-datetimepicker.min.js'></script>
    <!--<link rel="stylesheet" href="<?php echo base_url() ?>scripts/css/bootstrap.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>scripts/css/bootstrap-responsive.css">-->

</head>

<body>
    <div id="wrapper">
        <div id="header">
            <h2>Arrow VoiceCatch</h2><img alt="logo" src="<?php echo base_url() . 'images/logo.jpg'; ?>" />
        </div>
        <link rel="shortcut icon" href="<?php echo base_url() . 'images/arrow.ico'; ?>" <div id="nav">
        <?php if (isset($_SESSION['userid'])) { ?>

            <!--<b><?php echo anchor("/home", "Home"); ?></b>&nbsp;&nbsp;&nbsp;-->
            <a title="Home" style="text-decoration: none" href="<?php echo site_url() . '/home' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/home.png' ?>" />&nbsp;&nbsp;&nbsp;
                        </a>

            <!--<b><?php echo anchor("/calls", "Calls"); ?></b>&nbsp;&nbsp;&nbsp;-->
            <a title="Calls List" style="text-decoration: none" href="<?php echo site_url() . '/calls' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/calls.png' ?>" />&nbsp;&nbsp;&nbsp;
                        </a>

            <!--<b><a href='/phpsysinfo'>System Info</a></b>&nbsp;&nbsp;&nbsp;-->
            <a title="System Information" style="text-decoration: none" href='/phpsysinfo' ?>
                        <img border="0" src="<?php echo base_url() . 'images/sysinfo.png' ?>" />&nbsp;&nbsp;&nbsp;
                        </a>

            <?php if ($_SESSION['userid'] == 'admin') { ?>

                <!--<b><?php echo anchor("/users", "Users"); ?>&nbsp;&nbsp;&nbsp;-->
                <a title="Users"  style="text-decoration: none" href="<?php echo site_url() . '/users' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/user.png' ?>" />&nbsp;&nbsp;&nbsp;
                        </a>

                    <!--<b><?php echo anchor("/groups", "Groups"); ?>&nbsp;&nbsp;&nbsp;-->
                    <a title="Extensions Groups" style="text-decoration: none" href="<?php echo site_url() . '/groups' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/groups.png' ?>" />&nbsp;&nbsp;&nbsp;
                        </a>

                        <!--<b><?php echo anchor("/disable", "Disable"); ?>&nbsp;&nbsp;&nbsp;-->
                        <a title="Recording Disable" style="text-decoration: none" href="<?php echo site_url() . '/disable' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/disable.png' ?>" />&nbsp;&nbsp;&nbsp;
                        </a>

                            <!--<b><?php echo anchor("/landing", "Landing Groups"); ?>&nbsp;&nbsp;&nbsp;-->
                            <a title="Landing Groups" style="text-decoration: none" href="<?php echo site_url() . '/landing' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/landing.png' ?>" />&nbsp;&nbsp;&nbsp;
                        </a>

                                <!--<b><?php echo anchor("/clients", "Clients"); ?>&nbsp;&nbsp;&nbsp;-->
                                <a title="Phone Book" style="text-decoration: none" href="<?php echo site_url() . '/clients' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/clients.png' ?>" />&nbsp;&nbsp;&nbsp;
                        </a>

                                    <!--<b><?php echo anchor('/delete', 'System Maintenance'); ?>&nbsp;&nbsp;&nbsp;-->
                                    <a title="System Maintenance" style="text-decoration: none" href="<?php echo site_url() . '/delete' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/delete.png' ?>" />&nbsp;&nbsp;&nbsp;
                        </a>
                                        <!--b><?php echo anchor('/incomingcheck', 'Allow Incoming'); ?>&nbsp;&nbsp;&nbsp;-->
                                        <!--<b><a href='/adminer.php'>PhpMyAdmin</a></b>&nbsp;&nbsp;&nbsp;-->

                                        <a title="Database Utility" style="text-decoration: none" href='/adminer.php' ?>
                        <img border="0" src="<?php echo base_url() . 'images/database.png' ?>" />&nbsp;&nbsp;&nbsp;
                        </a>

                                        <!--<b><b><?php echo anchor('/shutdown', 'Shutdown'); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
                                        <a title="Shutdown / Reboot" style="text-decoration: none" href="<?php echo site_url() . '/shutdown' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/shutdown.png' ?>" />&nbsp;&nbsp;&nbsp;
                        </a>
                        
                                        <!--<b><?php echo anchor("/home/logout", "Logout"); ?></b>-->
                                        
                                        
                                                <!--</div>-->

                                                <!--  <b><?php echo anchor("/barge", "Listen"); ?>-->
                                                <!--<b><?php echo anchor('/delete', 'Delete Physically'); ?>-->
                                                <!--	<b><?php echo anchor('/download', 'Download Files'); ?> -->
                                            <?php } ?>
                                            <!--<div style="text-align: right">-->
                                                <!--<b><?php echo anchor("/home/logout", "Logout"); ?></b>-->
                                                <a title="Logout" style="text-decoration: none" href="<?php echo site_url() . '/home/logout' ?>">
                        <img border="0"  style="float:right" src="<?php echo base_url() . 'images/logout.png'  ?>" />
						</a>
                                                
                                            <!-- </div> -->

                                        <?php } ?>
    </div>

    <div id="main">
        <?php echo view($main); ?>
    </div>
    <div id="footertext">
        <b>
            <p align="center"> <a href="http://voicecatch.in" title="http://voicecatch.in" target="_blank">Arrow Telecom PVT LTD</a>
        </b>
        <b>
            <p align="center"> <a href="" target="_blank">Voicecatch Ver 2.0</a>
        </b>
    </div>
</body>

</html>

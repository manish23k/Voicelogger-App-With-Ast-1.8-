<?php 
                    $pos = strrpos($filename, '/');
                    $file = substr($filename,0, $pos+1);
                    $file = $file . urlencode(substr($filename, $pos+1)); 
?>
<?php echo form_open("/calls/comments/$file"); ?>
Comment for call<br/>
<textarea name="comments"style="width:400px; height:100px;"> 
<?php if(isset($comments)) echo $comments; ?>
</textarea>
<br/>
<input type="submit" value="Update">
<?php echo form_close(); ?>
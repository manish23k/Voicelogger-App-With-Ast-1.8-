<table>
    <tr>
        <th>Channel</th>
        <th>Status</th>
    </tr>
    <tr>
        <td><?php echo anchor('/barge/listen/1', 'Channel 1')?></td>
        <td>Idle</td>
    </tr>
    <tr>
        <td><?php echo anchor('/barge/listen/2', 'Channel 2')?></td>
        <td>Idle</td>
    </tr>
</table>
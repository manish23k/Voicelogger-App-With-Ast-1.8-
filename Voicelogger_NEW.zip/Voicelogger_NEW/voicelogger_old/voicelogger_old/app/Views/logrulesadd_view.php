<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<?php echo form_open("/disable/add"); ?>
Extension <?php echo form_input(array("name" => 'extension', "id" => 'extension'));?><br/>
<?php echo form_submit("submit", "Add");?>
<?php echo form_close();?>
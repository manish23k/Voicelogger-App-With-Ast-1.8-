<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<!-- <?php echo anchor("/disable/add", "Block extension"); ?> -->
<a title="Block extension" style="text-decoration: none" href="<?php echo site_url() . '/disable/add/' . $row->id ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_blockrec.png' ?>" />
</a>
<table>
    <tr>
        <th>Blocked Extension</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($result->getResult() as $row) : ?>
        <tr>
            <td><?php echo $row->phonenumber; ?></td>
            <!-- <td><?php echo anchor("/disable/delete/$row->id", "Delete"); ?></td> -->
           <td> <a title="Delete Extension" style="text-decoration: none" href="<?php echo site_url() . '/disable/delete/' . $row->id ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_delete.png' ?>" />
</a></td>
        </tr>
    <?php endforeach; ?>
</table>
<h1>Upload Success</h1>
<p>Your file was successfully uploaded!</p>
<p><?php echo anchor("/clients", "Back to Phonebook"); ?></p>

<?php ?>
<?php
// Path: app\Views\phonebookuploadsuccess_view.php
?>
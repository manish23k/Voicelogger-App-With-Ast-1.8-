<script>
$(function() { 
        $('.caldt').datepick({dateFormat: 'yy-mm-dd'});
    });

</script>
<h1>Delete Records and Recording Files Physically, Permanently and 
Irretrivably</h1>
<?php echo form_open('/delete/confirm'); ?>
<table>
<tr><td>
Date From: <?php echo form_input('datefrom', '', 'class=caldt');?></td>
<td>
Date To: <?php echo form_input('dateto', '', 'class=caldt');?></td>
</tr>
<tr>
<td>Time from:
<?php echo form_input('timefrom-hh','','size="2"');?>:
<?php echo form_input('timefrom-mm','','size="2"');?>:
<?php echo form_input('timefrom-ss','','size="2"');?>
</td>

<td>Time to:
<?php echo form_input('timeto-hh','','size="2"');?>:
<?php echo form_input('timeto-mm','','size="2"');?>:
<?php echo form_input('timeto-ss','','size="2"');?>
</td>
</tr>
<tr>
<td><?php echo form_submit('submit', 'Delete');?></td>
</tr>
</table>

<?php echo form_close(); ?>

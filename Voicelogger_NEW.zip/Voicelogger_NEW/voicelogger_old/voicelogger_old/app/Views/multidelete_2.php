<p>You are about to delete call records and their recording files permanently.</p>
<p>Press okay ONLY IF YOU ARE SURE</p>

<?php echo form_open('/calls/multiselect'); ?>
<?php echo form_hidden('filenames',$filenames); ?>
<?php echo form_submit('submit', 'OKAY'); ?>
<?php echo form_submit('submit', 'CANCEL'); ?>
<?php echo form_close(); ?>

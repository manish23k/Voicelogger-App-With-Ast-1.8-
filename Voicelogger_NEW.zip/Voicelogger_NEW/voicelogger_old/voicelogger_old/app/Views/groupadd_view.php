<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<?php echo validation_list_errors(); ?>
<?php echo form_open('/groups/add'); ?>
<?php
$groupname = '';
if (isset($result)) {
    $row = $result->getRow();
    echo form_hidden('id', "$row->id");
    $groupname = $row->groupname;
} ?>
Group Name <?php echo form_input('groupname', "$groupname"); ?><br />
<?php echo form_submit('submit', 'Save'); ?>
<?php echo form_close(); ?>
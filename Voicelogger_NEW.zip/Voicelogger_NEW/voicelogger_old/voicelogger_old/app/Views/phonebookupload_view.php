<?php echo form_open_multipart("/clients/upload"); ?>
<div class="form-control">
	<label class="control-label" for="userfile">File to upload</label>
	<div class="controls">
		<input type="file" name="userfile">
	</div>
</div>
<div class="form-actions">
	<button type="submit" class="btn">Upload</button>
</div>
<?php echo form_close(); ?>
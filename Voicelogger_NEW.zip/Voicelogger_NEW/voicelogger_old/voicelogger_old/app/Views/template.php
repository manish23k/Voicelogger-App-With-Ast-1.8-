<html>
<head>
    <title>VoiceCatch Ver-2.2</title>
    <link rel="shortcut icon" href="<?php echo base_url(); ?>/images/arrow.ico" />
    <style type="text/css">
         
         <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- Other CSS and scripts... -->

    <!-- Include Bootstrap CSS (if not already included) -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

<!-- Include Bootstrap Timepicker CSS and JavaScript -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/js/bootstrap-timepicker.min.js"></script>

    
body {
            background-color: #f0f0f0;
            font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
            margin: 0;
            padding: 0;
        }

            #wrapper {
        margin: 10px auto;
        padding: 10px;
        background-color: #FFFFFF;
        border: 1.5px solid #d4d4d9;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        width: 95%;
        max-width: 1500px;
        margin: -47px auto;
    }

    
  
  }
   /*old :-----
    #main {
        margin-left: auto;
        margin-right: auto;
        height: auto;
        padding: 20px;
        display: flex;
        position: absolute;
       
      
        flex-direction: column;
    }*/

/*    new*/

        /* Updated #main div styles */
   #main {
      margin: 20px auto;
    padding: 20px;
    /*display: flex;
    position: absolute;
    flex-direction: column;
    overflow-x: auto; /* Add this line for horizontal scrolling */
    max-width: 1200px; /* Set a consistent max-width for content */
    width: 99%; /* Set a consistent width for content */*/
}
 





    #header {
        font-size: 20px;
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    #header h2 {
        display: inline;
        font-weight: bold;
    }

    #header img {
        width: 100px;
        height: auto;
    }

    #footer {
        clear: both;
        padding-top: 40px;
        font-size: 9px;
        text-decoration: none;
    }

/*   old changes done by dhruv*/
 /*       table {
            border: 2px solid #D6DDE6;
            border-collapse: collapse;
            margin: 20px auto;
            width: 100%;
        }

        table td,
        table th {
            border: 1px solid #73C0D4;
            text-align: center;
            padding: 10px;
        }

        table th {
            font-weight: bold;
            text-align: center;
            background-color: #BCBCBC;
        }

        table tr:nth-child(odd) {
            background-color: #FFFFFF;
        }

        table tr:hover {
            background-color: #F1F1F1;
        }

*/

.pagination-link {
    display: inline-block;
    margin-right: 5px;
    padding: 5px 10px;
    border: 1px solid #ccc;
    text-decoration: none;
    color: #333;
    border-radius: 3px;
}

.pagination-link.active {
    background-color: #007BFF;
    color: #fff;
    border: 1px solid #007BFF;
}





 

/* Updated table styles */
table {
    border: 2px solid #D6DDE6;
    border-collapse: collapse;
    width: 100%;
}

table td,
table th {
    border: 1px solid #73C0D4;
    text-align: center;
    padding: 10px;
}

table th {
    font-weight: bold;
    text-align: center;
    background-color: #BCBCBC;
}

table tr:nth-child(odd) {
    background-color: #FFFFFF;
}

table tr:hover {
    background-color: #F1F1F1;
}



/* Table container styles */
#table-container-1,
#table-container-2 {
    margin: 0 auto;
    width: 100%; /* Adjust the width as needed */
    overflow: auto; /* Add this line for vertical scrolling if needed */
}

/* Form container styles */
#form-container-1,
#form-container-2 {
    margin: 20px auto; /* Adjust margin as needed */
    width: 100%; /* Adjust the width as needed */
    overflow: hidden; /* Add this line for vertical scrolling if needed */
}

/*  end  */



/*old 
    form {
        border: 3px solid #d4d4d9;
        padding: 20px;
        border-radius: 10px;
        width: 100%;
        
        margin-bottom: 20px;
    }

*/

/* Updated form styles */


 
form {
    border: 3px solid #d4d4d9;
    padding: 20px;
    border-radius: 10px;
    width: 100%;
    margin-bottom: 20px;
}


    form input:focus {
            border: 2px solid #000000;
        }

        form div {
            clear: left;
            margin: 0;
            padding: 0;
            padding-top: 0.6em;
        }

        form div label {
            float: left;
            width: 40%;
            font: bold 0.9em Arial, Helvetica, sans-serif;
        }

        a:hover {
            text-decoration: blink;
            color: #006600;
        }
        
  input {
  font-size: 0.8em; /* reduce font size */
  padding: 0.2em 0.5em; /* reduce vertical padding and increase horizontal padding */
   border-radius: 5px;
}
      
    select,
    textarea {
        margin-top: 10px;
        width: 100%;
        padding: 10px;
        border: 2px solid #6a6a74;
        border-radius: 5px;
        font-size: 14px;
        color: #555555;
        background-color: #f5
  
    }



/*   new  */
    
        #nav {
    display: flex;
    padding: 16px 0px;
    background-color: #283747;
    color: #FFFFFF;
    display: flex;
    justify-content: space-around;
    align-items: center;
    
    text-decoration: none;
}

#nav a {
    text-decoration: none;
    color: #FFFFFF;
    font-size: 16px;
    font-weight: bold;
/*   margin: 0 10px; /* Adjust the margin to control spacing between icons */*/
}
#nav a:hover {
    text-decoration: underline;
}

#nav .menu-name {
    font-size: 14px;
    margin-top: 5px;
}



    /* old---- 
       #nav {
            display: block;
            height: auto;
            padding: 16px 5px;
            background-color: #283747;
            color: #FFFFFF;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 10px;
            text-decoration: none;
        }

        #nav a {
            text-decoration: none;
            color: #FFFFFF;
            font-size: 16px;
            font-weight: bold;
            margin-right: 20px;
        }

        #nav a:hover {
            text-decoration: underline;
        }

        #nav .menu-name {
            font-size: 14px;
            margin-top: 5px;
        }
     */

    /* Dashboard styles Add by dhruv */
        #dashboard {
            background-color: #ECECEC;
            border: 1px solid #CCCCCC;
            border-radius: 5px;
            padding: 20px;
            margin-top: 20px;
        }

        .dashboard-content {
            display: flex;
                   flex-wrap: wrap;
        }

        .widget {
            background-color: #FFFFFF;
            border: 1px solid #DDDDDD;
            border-radius: 5px;
            padding: 10px;
            width: 30%;
         margin: 0 2% 20px 0;
        }

        .widget h4 {
            margin: 0;
            padding-bottom: 5px;
            border-bottom: 1px solid #DDDDDD;
        }
        
        
    #footer {
        text-align: center; /* Align the content to the center */
        padding: 20px 10px; /* Add padding top and bottom */
        font-size: 12px; /* Adjust the font size */
        color: #888; /* Change text color if needed */
    }

    </style>
    <script type="text/javascript" src="<?php echo base_url(); ?>scripts/playfuncs.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>scripts/jquery-1.3.2.min.js"></script>
    <style type="text/css">
        @import "<?php echo base_url(); ?>scripts/datepicker/jquery.datepick.css";
    </style>
    <script type="text/javascript" src="<?php echo base_url(); ?>scripts/datepicker/jquery.datepick.js"></script>
    <script src='<?php echo base_url() ?>scripts/js/bootstrap-datetimepicker.min.js'></script>
    <!--<link rel="stylesheet" href="<?php echo base_url() ?>scripts/css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>scripts/css/bootstrap-responsive.css">-->

</head>

<body><br/><br/><br/>
    <div id="wrapper">
        <div id="header">
            <img alt="logo" src="<?php echo base_url() . 'images/logo1.png'; ?>"/><img alt="logo" src="<?php echo base_url() . 'images/logo.jpg'; ?>" />
        </div>
         <!-- <link rel="shortcut icon" href="<?php echo base_url() . 'images/arrow.ico'; ?>" <div id="nav">       -->
         
      <div id="nav">
        <?php if (isset($_SESSION['userid'])) { ?>

               <a title="Home" style="text-decoration: none" href="<?php echo site_url() . '/home' ?>">
                    <img border="0" src="<?php echo base_url() . 'images/home.png' ?>" />
                    <div class="menu-name">Home</div>
                </a>

              <a title="Calls List" style="text-decoration: none" href="<?php echo site_url() . '/calls' ?>">
                    <img border="0" src="<?php echo base_url() . 'images/calls.png' ?>" />
                    <div class="menu-name">Calls</div>
                </a>

                <a title="System Information" style="text-decoration: none" href='/phpsysinfo'>
                    <img border="0" src="<?php echo base_url() . 'images/sysinfo.png' ?>" />
                    <div class="menu-name">System Info</div>
                </a>

    


            <?php if ($_SESSION['userid'] == 'admin') { ?>

                <!--<b><?php echo anchor("/users", "Users"); ?>&nbsp;&nbsp;&nbsp;-->
               
                <a title="Users"  style="text-decoration: none" href="<?php echo site_url() . '/users' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/user.png' ?>" />&nbsp;&nbsp;&nbsp;
                         <div class="menu-name">Users</div> 
                        </a>

                    <!--<b><?php echo anchor("/groups", "Groups"); ?>&nbsp;&nbsp;&nbsp;-->
                    <a title="Extensions Groups" style="text-decoration: none" href="<?php echo site_url() . '/groups' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/groups.png' ?>" />&nbsp;&nbsp;&nbsp;
                            <div class="menu-name">Extensions Groups</div> 
                        </a>

                        <!--<b><?php echo anchor("/disable", "Disable"); ?>&nbsp;&nbsp;&nbsp;-->
                        <a title="Recording Disable" style="text-decoration: none" href="<?php echo site_url() . '/disable' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/disable.png' ?>" />&nbsp;&nbsp;&nbsp;
                         <div class="menu-name">Recording Disable</div>
                        </a>

                            <!--<b><?php echo anchor("/landing", "Landing Groups"); ?>&nbsp;&nbsp;&nbsp;-->
                            <a title="Landing Groups" style="text-decoration: none" href="<?php echo site_url() . '/landing' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/landing.png' ?>" />&nbsp;&nbsp;&nbsp;
                         <div class="menu-name">Landing Groups</div>
                         </a>

                                <!--<b><?php echo anchor("/clients", "Clients"); ?>&nbsp;&nbsp;&nbsp;-->
                                <a title="Phone Book" style="text-decoration: none" href="<?php echo site_url() . '/clients' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/clients.png' ?>" />&nbsp;&nbsp;&nbsp;
                         <div class="menu-name">Phone Book</div>
                        </a>

                                    <!--<b><?php echo anchor('/delete', 'System Maintenance'); ?>&nbsp;&nbsp;&nbsp;-->
                                    <a title="System Maintenance" style="text-decoration: none" href="<?php echo site_url() . '/delete' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/delete.png' ?>" />&nbsp;&nbsp;&nbsp;
                         <div class="menu-name">System Maintenance</div>
                        </a>

                                        <!--b><?php echo anchor('/incomingcheck', 'Allow Incoming'); ?>&nbsp;&nbsp;&nbsp;-->
                                        <!--<b><a href='/adminer.php'>PhpMyAdmin</a></b>&nbsp;&nbsp;&nbsp;-->
                                        

                                        <a title="Database Utility" style="text-decoration: none" href='/adminer.php' ?>
                        <img border="0" src="<?php echo base_url() . 'images/database.png' ?>" />&nbsp;&nbsp;&nbsp;
                         <div class="menu-name">Database Utility</div>
                         </a>

                                        <!--<b><b><?php echo anchor('/shutdown', 'Shutdown'); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
                                        <a title="Shutdown / Reboot" style="text-decoration: none" href="<?php echo site_url() . '/shutdown' ?>">
                        <img border="0" src="<?php echo base_url() . 'images/shutdown.png' ?>" />&nbsp;&nbsp;&nbsp;
                         <div class="menu-name">Shutdown</div>
                        </a>


      <?php } else { ?>
            <!-- Add a Logout link for non-admin users -->
            <a title="Logout" style="text-decoration: none" href="<?php echo site_url() . '/home/logout' ?>">
                <img border="0" style="float:right" src="<?php echo base_url() . 'images/logout.png' ?>" />
                <div class="menu-name">Logout</div>
            </a>
        <?php } ?>

        <!-- Always display a Logout link for admin users -->
        <?php if ($_SESSION['userid'] == 'admin') { ?>
            <a title="Logout" style="text-decoration: none" href="<?php echo site_url() . '/home/logout' ?>">
                <img border="0" style="float:right" src="<?php echo base_url() . 'images/logout.png' ?>" />
                <div class="menu-name">Logout</div>
            </a>
        <?php } ?>

    <?php } ?>
</div>




    <div id="main">
        <?php echo view($main); ?>
    </div>
    <div id="footertext">
        <b>
            <p align="center"> <a href="http://voicecatch.in" title="http://voicecatch.in" target="_blank">Arrow Telecom PVT LTD</a>
        </b>
        <b>
            <p align="center"> <a href="" target="_blank">Voicecatch Ver 2.2</a>
        </b>
    </div>
</body>

</html>
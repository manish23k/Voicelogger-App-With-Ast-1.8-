<h1>Deleting</h1>
<p>You are about to delete <b><?php echo $count;?></b> records and their recording files permanently.</p>

<p>Press okay ONLY IF YOU ARE SURE</p>

<?php echo form_open('/delete/process'); ?>
<?php echo form_hidden('where', $where); ?>
<?php echo form_submit('submit', 'OKAY'); ?>
<?php echo form_submit('submit', 'CANCEL'); ?>
<?php echo form_close(); ?>

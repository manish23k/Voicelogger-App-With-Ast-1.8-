<?php echo form_open("/clients/edit/$id"); ?>
Client Id <?php echo form_input(array("name" => 'custid', "id" => 'custid', "value" => $result->CustId)); ?><br />
Client Name <?php echo form_input(array("name" => 'custname', "id" => 'custname', "value" => $result->CustName)); ?><br />
Company <?php echo form_input(array('name' => 'company', 'id' => 'company', "value" => $result->Company)) ?><br />
Address <?php echo form_textarea(array('name' => 'address', 'id' => 'address', "value" => $result->Address)); ?><br />
Phone 1 <?php echo form_input(array("name" => 'phonenumber', "id" => 'phonenumber', "value" => $result->PhoneNumber)); ?><br />
Phone 2 <?php echo form_input(array("name" => 'mobilenumber', "id" => 'mobilenumber', "value" => $result->MobileNumber)); ?><br />
Phone 3 <?php echo form_input(array("name" => 'alternatephonenumber', "id" => 'alternatephonenumber', "value" => $result->AlternatePhoneNumber)); ?><br />
Phone 4 <?php echo form_input(array("name" => 'alternatemobilenumber', "id" => 'alternatemobilenumber', "value" => $result->AlternateMobileNumber)); ?><br />
<?php echo form_submit("submit", "Edit"); ?>
<?php echo form_close(); ?>
<?php
// Path: app\Views\phonebook_view.php
?>
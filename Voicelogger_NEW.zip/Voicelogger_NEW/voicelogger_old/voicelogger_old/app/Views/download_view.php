<?php echo $this->session->flashdata('dlmess'); ?>
<?php echo form_open("/download/createdl");?>

Start Date: <?php echo form_input("startdate");?>(yyyy-mm-dd)<br/>
End Date: <?php echo form_input("enddate");?>(yyyy-mm-dd)<br/>
<?php echo form_submit("submit", "Download");?>
<?php echo form_close();?>

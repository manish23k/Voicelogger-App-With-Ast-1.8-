
<br><br/>
<br><br/>
<?php echo form_open("/home/checklogin"); ?>

<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
    }
    h1 {
      color: #333;
      text-align: center;
    }
    form {
      background-color: #fff;
      border: 1px solid #ddd;
      padding: 20px;
      width: 400px;
      margin: 0 auto;
      border-radius: 5px;
      box-shadow: 0 0 10px #ddd;
    }
    input[type=text], input[type=password] {
      display: block;
      margin-bottom: 10px;
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      box-sizing: border-box;
    }
    input[type=submit] {
      background-color: #333;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      width: 100%;
    }
    input[type=submit]:hover {
      background-color: #555;
    }
  </style>
</head>
<body>
  <h1>Login</h1>
  <form >
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required>
    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>
    <input type="submit" value="Login">
  </form>
</body>
</html>

<?php echo form_close(); ?>
<br><br/>
<br><br/>
<?php echo form_open("agents/add"); ?>
Extension: <input type=text name=exten><br />
Firstname <input type=text name=firstname><br />
Lastname <input type=text name=lastname><br />
<input type=submit name=submit value=add>
<?php echo form_close(); ?>
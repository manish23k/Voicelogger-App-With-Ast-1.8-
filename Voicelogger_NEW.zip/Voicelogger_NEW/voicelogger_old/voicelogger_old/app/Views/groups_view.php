<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<?php echo isset($_SESSION['status']) ? $_SESSION['status'] : ''; ?>
<!-- <?php echo anchor("/groups/add", "New Group"); ?> -->
<a title="New Group" style="text-decoration: none" href="<?php echo site_url() . '/groups/add/' . $row->id ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_newgroup.png' ?>" />
</a>
<table>
    <tr>
        <th>Group ID</th>
        <th>Group name</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($result->getResult() as $row) : ?>
        <tr>
            <td><?php echo $row->id; ?></td>
            <td><?php echo $row->groupname; ?></td>
            <td><a title="Group Edit" style="text-decoration: none" href="<?php echo site_url() . '/groups/edit/' . $row->id ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_edit.png' ?>" />
</a>
<a title="Group Delete" style="text-decoration: none" href="<?php echo site_url() . '/groups/delete/' . $row->id ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_delete.png' ?>" />
</a>
<a title="Extensions" style="text-decoration: none" href="<?php echo site_url() . '/groups/extensions/' . $row->id ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_extensions.png' ?>" />
</a></td>
            <!-- <td><?php echo anchor("/groups/edit/$row->id", "Edit"); ?>
                <?php echo anchor("/groups/delete/$row->id", "Delete"); ?>
                <?php echo anchor("/groups/extensions/$row->id", "Extensions"); ?></td> -->
        </tr>
    <?php endforeach; ?>
</table>
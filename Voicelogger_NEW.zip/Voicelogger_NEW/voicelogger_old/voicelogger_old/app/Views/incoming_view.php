<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<?php echo anchor("/incomingcheck/add", "Block extension"); ?>
<table>
    <tr>
        <th>Allow Numbers</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($result->getResult() as $row) : ?>
        <tr>
            <td><?php echo $row->phonenumber; ?></td>
            <td><?php echo anchor("/incomingcheck/delete/$row->id", "Delete"); ?></td>
        </tr>
    <?php endforeach; ?>
</table>
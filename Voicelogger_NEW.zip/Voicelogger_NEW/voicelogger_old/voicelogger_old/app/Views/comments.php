<?php echo form_open("/calls/comments/$filename"); ?>
Comment for call<br />
<textarea name="comments" style="width:400px; height:100px;">
<?php if (isset($comments)) echo $comments; ?>
</textarea>
<input type="hidden" name="filename" value="<?php echo $filename; ?>">
<br />
<input type="submit" value="Update">
<?php echo form_close(); ?>
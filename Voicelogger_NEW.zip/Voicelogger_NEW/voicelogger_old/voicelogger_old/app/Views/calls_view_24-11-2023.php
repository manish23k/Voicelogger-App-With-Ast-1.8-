<?php
$session = \Config\Services::session();
?>

<head>


    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/html-duration-picker@latest/dist/html-duration-picker.min.js"></script>
    <script src="html-duration-picker.min.js"></script>

    <!-- Include jQuery library -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Include jQuery Duration Picker CSS and JavaScript -->
    <link rel="stylesheet" href="path/to/jquery-duration-picker/jquery.duration-picker.css">
    <script src="path/to/jquery-duration-picker/jquery.duration-picker.js"></script>

    <!-- Include flatpickr CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <!-- Include flatpickr JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
</head>

<script type="text/javascript">
    document.addEventListener("DOMContentLoaded", function () {
        // Initialize Flatpickr for date and time inputs
        flatpickr("#startdate, #enddate", {
            dateFormat: "Y-m-d"
        });

        flatpickr("#starttime, #endtime", {
            enableTime: true,
            enableSeconds: true,
            noCalendar: true,
            dateFormat: "H:i:S",
            // defaultDate: "<?php echo $session->get('csstarttime'); ?>",
            allowInput: true,
            clickOpens: true,
            onClose: function (selectedDates, dateStr, instance) {
                if (!dateStr) {
                    instance.clear();
                }
            }
        });


        flatpickr("#startduration, #endduration", {
            enableTime: true,
            enableSeconds: true,
            noCalendar: true,
            dateFormat: "H:i:S",
            // defaultDate: "<?php echo $session->get('csstartduration'); ?>",
            allowInput: true,
            clickOpens: true,
            onClose: function (selectedDates, dateStr, instance) {
                if (!dateStr) {
                    instance.clear();
                }
            }
        });


        $('#id-select-all').click(function () {
            if ($('#id-select-all').attr('checked'))
                $(':checkbox').attr('checked', 'checked');
            else
                $(':checkbox').removeAttr('checked');
        });
    });





</script>

<script>
    $(document).ready(function () {
        $('#clear-button').click(function () {
            // Clear all input fields except the Call Type dropdown
            $('input[type="text"], input[type="password"], input[type="number"], input[type="email"], textarea').not('[name="calltype"]').val('');
        });
    });
</script>







<style>
    /* Default styles for larger screens */
    /* Add your existing CSS rules here */

    /* Media query for smaller screens */
    @media (max-width: 768px) {
        /* Adjust styles for screens with a maximum width of 768px */

        /* Example: Stack form fields for smaller screens */
        input[type="text"],
        input[type="password"],
        input[type="number"],
        input[type="email"],
        textarea {
            width: 100%;
            margin-bottom: 10px;
        }
    }

    img {
        max-width: 100%;
        height: auto;
    }


    /* Style for the Clear button */
    #clear-button {
        float: right;
        margin-top: 10px;
    }

    .inline {
        display: inline-block;
        float: right;
        margin: 20px 0px;
    }

    input,
    button {
        height: 34px;
    }

    .pagination-container {
        text-align: center;
    }

    .pagination {
        display: inline-block;
    }

    .pagination a {
        font-weight: bold;
        font-size: 18px;
        color: black;
        float: left;
        padding: 8px 16px;
        text-decoration: none;
        border: 1px solid black;
    }

    .pagination a.active {
        background-color: pink;
    }

    .pagination a:hover:not(.active) {
        background-color: skyblue;
    }
</style>
<!-- 
<a title="Previous Page" href="<?php echo site_url() . "/calls/index/$previous" ?>">
    <img border="0" src="<?php echo base_url() . 'images/icon_left_arrow.png' ?>" />
</a>

<a title="Next Page" href="<?php echo site_url() . "/calls/index/$next" ?>">
    <img border="0" style="float:right" src="<?php echo base_url() . 'images/icon_right_arrow.png' ?>" />
</a> -->

<div id="main">
    <!-- Table 1 container -->
    <div id="table-container-1">
        <?php echo form_open("/calls/search"); ?>
        <table>
            <tr>
                <td>Call Type</td>
                <td>
                    <?php echo form_dropdown('calltype', array('incoming' => 'Incoming', 'outgoing' => 'Outgoing', 'mi' => 'Missed', 'na' => 'No Answer', 'xx' => 'All'), $session->get('cscalltype')); ?>
                </td>
            </tr>
            <tr>
                <td>Date</td>
                <td>
                    <?php echo form_input(array('name' => 'startdate', 'id' => 'startdate'), $session->get('csstartdate')); ?>
                    <?php echo form_input(array('name' => 'enddate', 'id' => 'enddate'), $session->get('csenddate')); ?>
                </td>

                <!-- added by dhruv  -->
                <td>Time (HH:MM:SS)</td>
                <td>
                    <!-- <input type="text" name="starttime" id="csstarttime" value="<?php echo $session->get('csstarttime'); ?>" placeholder="HH:MM:SS"  >
                <input type="text" name="endtime" id="csendtime" value="<?php echo $session->get('csendtime'); ?>" placeholder="HH:MM:SS"  > -->
                    <?php echo form_input(array('name' => 'starttime', 'id' => 'starttime', 'placeholder' => 'HH:MM:SS', 'autocomplete' => 'off'), $session->get('csstarttime')); ?>
                    <?php echo form_input(array('name' => 'endtime', 'id' => 'endtime', 'placeholder' => 'HH:MM:SS', 'autocomplete' => 'off'), $session->get('csendtime')); ?>

                </td>

                <td>Duration (HH:MM:SS)</td>
                <td>
                    <!-- <input type="text"     name="startduration" id="csstartduration" value="<?php echo $session->get('csstartduration'); ?>" placeholder="HH:MM:SS" autocomplete="off">
    <input type="text"    name="endduration" id="csendduration" value="<?php echo $session->get('csendduration'); ?>" placeholder="HH:MM:SS" autocomplete="off"> -->


                    <?php echo form_input(array('name' => 'startduration', 'id' => 'startduration', 'placeholder' => 'HH:MM:SS', 'autocomplete' => 'off'), $session->get('csstartduration')); ?>
                    <?php echo form_input(array('name' => 'endduration', 'id' => 'endduration', 'placeholder' => 'HH:MM:SS', 'autocomplete' => 'off'), $session->get('csendduration')); ?>

                </td>


            </tr>
            <tr>
                <td>Client Id</td>
                <td>
                    <?php echo form_input('clientid', $session->get('csclientid')); ?>
                </td>
                <td>Client Name</td>
                <td>
                    <?php echo form_input('clientname', $session->get('csclientname')); ?>
                </td>
                <td>Phone</td>
                <td>
                    <?php echo form_input('phonenumber', $session->get('csphonenumber')); ?>
                </td>
            </tr>
            <tr>
                <td>Comments</td>
                <td>
                    <?php echo form_input('comments', $session->get('cscomments')); ?>
                </td>
                <td>Extensions</td>
                <td>
                    <?php echo form_input('extension', $session->get('csextension')); ?>
                </td>
                <td>PBX Ext</td>
                <td>
                    <?php echo form_input('pbxextn', $session->get('cspbxextn')); ?>
                </td>
            </tr>
        </table>


        <?php echo form_submit('submit', 'Search'); ?>
        <td colspan="2">
            <?php echo form_submit('clear', 'Clear', 'id="clear-button"'); ?>
        </td>
        <?php echo form_close(); ?>
    </div>
    <!-- End Table 1 container -->

    <!-- add and edit by dhruv -->
    <!-- New Table for call count  -->
    <div>
        <table>
            <tr>
                <th>Incoming</th>
                <th>Outgoing</th>
                <th>Missed</th>
                <th>No Answer</th>
                <th>Total Calls</th>
            </tr>
            <tr>
                <td>
                    <?php echo $incomingCount; ?>
                </td>
                <td>
                    <?php echo $outgoingCount; ?>
                </td>
                <td>
                    <?php echo $missedCount; ?>
                </td>
                <td>
                    <?php echo $noAnswerCount; ?>
                </td>
                <td>
                    <?php echo $incomingCount + $outgoingCount + $missedCount + $noAnswerCount; ?>
                </td>
            </tr>

        </table>
    </div>


    <!-- Table 2 container -->
    <div id="table-container-2">
        <?php echo form_open("/calls/multiselect"); ?>
        <a title="Download CSV" style="float:left" href="<?php echo site_url() . '/calls/index/download' ?>">
            <img border="0" src="<?php echo base_url() . 'images/csv.png' ?>" />
        </a>&nbsp;&nbsp;&nbsp;

        <?php if ($session->get('callsdownload') == '1') { ?>
            <?php echo form_submit('submit', 'Download Selected'); ?>&nbsp;&nbsp;&nbsp;
        <?php } ?>


        <?php if ($session->get('callsdelete') == '1') { ?>
            <?php echo form_submit('submit', 'Delete Selected', 'onclick="return confirmDelete()"'); ?>&nbsp;&nbsp;&nbsp;
        <?php } ?>


        <table>
            <tr>
                <th><input type="checkbox" value="on" name="allbox" id="id-select-all"><strong>Select</strong></th>
                <th>PBX Extension</th>
                <th>Extension</th>
                <th>CLID</th>
                <th>Date</th>
                <th>Time</th>
                <th>Duration</th>
                <th>Call Type</th>
                <th>Actions</th>
                <th>Client</th>
                <th>Comments</th>
            </tr>

            <?php foreach ($result->getResult() as $row): ?>
                <?php
                $calltype = $session->get('cscalltype');
                // if (($calltype == 'missed' || $calltype == 'noanswer') && file_exists(config(App::class)->recording_path . $row->FileName)) {
                //     //continue;
                // }
                // if (($calltype == 'incoming' || $calltype == 'outgoing') && !file_exists(config(App::class)->recording_path . $row->FileName)) {
                //     //continue;
                // }
                ?>
                <tr>
                    <td>
                        <?php echo form_checkbox('filenames[]', $row->FileName) ?>
                    </td>
                    <td>
                        <?php echo $row->pbxextn == NULL ? 'NA' : $row->pbxextn ?>
                    </td>
                    <td>
                        <?php echo $row->Extension; ?>
                    </td>
                    <td>
                        <?php echo $row->PhoneNumber; ?>
                    </td>
                    <td>
                        <?php echo $row->StartDate; ?>
                    </td>
                    <td>
                        <?php echo $row->StartTimeTime; ?>
                    </td>
                    <td>
                        <?php echo $row->Duration; ?>
                    </td>
                    <td>
                        <?php echo $row->Type; ?>
                    </td>
                    <td>
                        <?php
                        $pos = strrpos($row->FileName, '/');
                        $file = substr($row->FileName, 0, $pos + 1);
                        $file = $file . urlencode(substr($row->FileName, $pos + 1));
                        ?>
                        <?php if ($session->get('playright') == '1' && file_exists(config(App::class)->recording_path . $row->FileName)) { ?>
                            <audio controls style="width: 30rem;">
                                <source src="<?php echo '/recordings/files/' . $file ?>" type="audio/mpeg">
                            </audio>

                            <a title="play" href="#" onclick='playfile("<?php echo site_url() . "/wave/play/" . $file ?>")'>
                                <!--<img border="0" src='<?php echo base_url() . "images/icon_play.png" ?>' />-->
                            </a>
                        <?php } ?>
                        <?php if ($session->get('downloadright') == '1' && file_exists(config(App::class)->recording_path . $row->FileName)) { ?>
                            <a title="Download" style="text-decoration: none"
                                href="<?php echo site_url() . "/wave/download/" . $file ?>">
                                <img border="0" src='<?php echo base_url() . "images/icon_download large.gif" ?>' />
                            </a>
                        <?php } ?>
                        <?php if ($session->get('deleteright') == '1') { ?>
                            <a title="Delete" style="text-decoration: none" href="#"
                                onclick='playfile("<?php echo site_url() . "/wave/delete/" . $file ?>")'>
                                <img border="0" src='<?php echo base_url() . "images/icon_delete large.gif" ?>' />
                            </a>
                        <?php } ?>
                    </td>
                    <td>
                        <?php echo $row->custname; ?>
                    </td>
                    <td>
                        <?php echo nl2br($row->comments); ?><br />
                        <a title="Comment" href="<?php echo site_url() . '/calls/comments/' . $file ?>">
                            <img border="0" src="<?php echo base_url() . 'images/icon_edit.gif' ?>" />
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        <?php echo form_close(); ?>
    </div>
    <!-- End Table 2 container -->
</div>

<?php
$conn = mysqli_connect('localhost', 'cron', '1234');
if (!$conn) {
    die("Connection failed" . mysqli_connect_error());
} else {
    mysqli_select_db($conn, 'voicecatch');
}
?>


<!-- <?php
// Pagination Start
$per_page_record = 25; // Number of entries to show on a page.

// Look for a GET variable page; if not found, default is 1.
if (isset($_GET["page"])) {
    $page = $_GET["page"];
} else {
    $page = 1;
}

// Calculate the correct offset based on the page number.
$start_from = ($page - 1) * $per_page_record;

$query = "SELECT * FROM calldetails LIMIT $start_from, $per_page_record";
$rs_result = mysqli_query($conn, $query);

?> -->

<!-- Display your call details here -->

  <div class="pagination-container">
    <div class="pagination">  
<?php
$query = "SELECT COUNT(*) FROM calldetails";
$rs_result = mysqli_query($conn, $query);
$row = mysqli_fetch_row($rs_result);
$total_records = $row[0];

$total_pages = ceil($total_records / $per_page_record);

$pages_per_set = 25;

// Calculate the start and end page for the current set.
$start_page = max(1, min($page - floor($pages_per_set / 2), $total_pages - $pages_per_set + 1));
$end_page = min($start_page + $pages_per_set - 1, $total_pages);
       
// Display "Prev" link
        if ($page > 1) {
            $prev = $page - 1;
            echo "<a class='pagination-link' href='" . site_url() . "/calls/index/" . $prev . "'>Prev</a>";
        }

        // Display page numbers
        for ($i = $start_page; $i <= $end_page; $i++) {
            $class = ($i == $page) ? 'active' : '';
            echo "<a class='pagination-link $class' href='" . site_url() . "/calls/index/" . $i . "'>" . $i . "</a>";
        }

        // Display "Next" link
        if ($page < $total_pages) {
            $next = $page + 1;
            echo "<a class='pagination-link' href='" . site_url() . "/calls/index/" . $next . "'>Next</a>";
        }
// Pagination end
?>

</div>
</div>


<!-- Go to specific page -->
<div class="inline">
    <form action="<?php echo site_url() . '/calls/index/'; ?>" method="get">
        <input type="number" min="1" max="<?php echo $total_pages; ?>" name="page" placeholder="<?php echo $page . "/" . $total_pages; ?>" required>
        <button type="submit">Go</button>
    </form>
</div>





<!-- 
<a title="Previous Page" href="<?php echo site_url() . "/calls/index/$previous" ?>">
    <img border="0" src="<?php echo base_url() . 'images/icon_left_arrow.png' ?>" />
</a>

<a title="Next Page" href="<?php echo site_url() . "/calls/index/$next" ?>">
    <img border="0" style="float:right" src="<?php echo base_url() . 'images/icon_right_arrow.png' ?>" />
</a> -->


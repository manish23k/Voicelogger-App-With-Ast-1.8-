<?php echo form_open("/home/checklogin"); ?>
   <div align="center">
User Name <br><input type="text" name="username"><br />
Password <br><input type="password" name="password"><br />

<br><input type="submit" value="Login"><br/>
</div>


<?php echo form_close(); ?>
<?php
$row = $result->getRow();
$exten = $row->exten;
$firstname = $row->firstname;
$lastname = $row->lastname;
?>
<?php echo form_open("agents/edit/$exten"); ?>
Extension: <input type=text name=exten value="<?php echo $exten ?>"><br />
Firstname <input type=text name=firstname value="<?php echo $firstname ?>"><br />
Lastname <input type=text name=lastname value="<?php echo $lastname ?>"><br />
<input type=submit name=submit value=edit>
<?php echo form_close(); ?>
<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<!-- <?php echo anchor("/users/add", "New User"); ?> -->
<td><a title="User Add" style="text-decoration: none" href="<?php echo site_url() . '/users/add/' . $row->UserID ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_adduser.png' ?>" />
</a>
</td>
<table>
    <tr>
        <th>User ID</th>
        <th>Real Name</th>
        <th>Extension</th>
        <th>Group</th>
        <th>Play</th>
        <th>Download</th>
        <th>Delete</th>
        <th>Comment</th>
        <th>Download selected</th>
        <th>Delete selected</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($result->getResult() as $row) : ?>
        <tr>
            <td><?php echo $row->UserID; ?></td>
            <td><?php echo $row->Name; ?></td>
            <td><?php echo $row->Extension; ?></td>
            <td><?php echo $row->groupid == -1 ? '--self--' : ($row->groupid == 0 ? '--all--' : $row->groupname); ?></td>
            <td><?php echo $row->playright; ?></td>
            <td><?php echo $row->downloadright; ?></td>
            <td><?php echo $row->deleteright; ?></td>
            <td><?php echo $row->commentright; ?></td>
            <td><?php echo $row->callsdownload; ?></td>
            <td><?php echo $row->callsdelete; ?></td>

            <!--<td><?php echo anchor("/users/edit/$row->UserID", "Edit"); ?>
                <?php echo anchor("/users/delete/$row->UserID", "Delete"); ?></td>-->
                <td><a title="User Edit" style="text-decoration: none" href="<?php echo site_url() . '/users/edit/' . $row->UserID ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_edit.png' ?>" />
                        </a>

                        <a title="User Delete" style="text-decoration: none" href="<?php echo site_url() . '/users/delete/' .$row->UserID ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_delete.png' ?>" /></td>
                        </a>
        </tr>
    <?php endforeach; ?>
</table>
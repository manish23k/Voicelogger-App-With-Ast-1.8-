<script type="text/javascript">
    $(document).ready(function() {
        $('#id-select-all').click(function() {
            if ($('#id-select-all').attr('checked'))
                $(':checkbox').attr('checked', 'checked');
            else
                $(':checkbox').removeAttr('checked');
        });
    });
</script>

<?php echo form_open('/groups/exadd'); ?>
<?php echo form_hidden('groupid', $groupid); ?>
<?php echo form_submit('submit', 'Save'); ?>

<?php
$setextensions = array();
foreach ($result->getResult() as $row) {
    $setextensions[] = $row->extension;
}
?>
<table>
    <tr>
        <th><input type="checkbox" value="on" name="allbox" id="id-select-all"><strong>Select</strong></td>
        <th>Extensions</th>
    </tr>
    <?php foreach ($result_ext->getResult() as $row) : ?>
        <tr>
            <td>
                <?php echo form_checkbox('extension[]', $row->extension, in_array($row->extension, $setextensions) ? '1' : '') ?>
            </td>
            <td>
                <?php echo $row->extension; ?>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<?php echo form_submit('submit', 'Save'); ?>
<?php echo form_close(); ?>
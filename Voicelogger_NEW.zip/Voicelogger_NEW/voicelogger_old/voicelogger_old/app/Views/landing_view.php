<?php echo form_open('/landing/add'); ?>

<label>Caller id</label> <?php echo form_input('callerid', isset($edit_callerid) ? $edit_callerid : ''); ?><br />
<label>Extension</label> <?php echo form_input('extension', isset($edit_extension) ? $edit_extension : ''); ?><br />
<label>Caller name</label> <?php echo form_input('callername', isset($edit_callername) ? $edit_callername : ''); ?><br />
<?php echo form_hidden('edit_id', isset($edit_id) ? $edit_id : ''); ?>
<?php echo form_submit('submit', 'Save'); ?>

<?php echo form_close(); ?>

<table>
	<tr>
		<td>Caller id</td>
		<td>Caller name</td>
		<td>Extension</td>
		<td>Action</td>
	</tr>
	<?php foreach ($result->getResult() as $row) { ?>
		<tr>
			<td><?php echo $row->callerid; ?></td>
			<td><?php echo $row->callername; ?></td>
			<td><?php echo $row->extension; ?></td>
			<!-- <td>
				<?php echo anchor("/landing/edit/$row->id", "Edit"); ?>
				&nbsp;&nbsp;
				<?php echo anchor("/landing/delete/$row->id", "Delete"); ?></td> -->
				<td> <a title="Edit Extension" style="text-decoration: none" href="<?php echo site_url() . '/landing/edit/' . $row->id ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_edit.png' ?>" />
</a>
					<a title="Delete Extension" style="text-decoration: none" href="<?php echo site_url() . '/landing/delete/' . $row->id ?>">
                        <img border="0" src="<?php echo base_url() . 'images/icon_delete.png' ?>" />
</a>
</td>
		</tr>
	<?php } ?>
</table>
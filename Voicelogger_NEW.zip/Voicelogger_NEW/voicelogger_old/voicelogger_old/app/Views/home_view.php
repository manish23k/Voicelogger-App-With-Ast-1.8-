<head>
    <!-- ... (your existing code) ... -->
    <title>Call Summary</title>
    <script src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    
    <script type="text/javascript">
        var countdownInterval; // Store the countdown interval

        function updateLiveCountdown(refreshInterval) {
    var countdown = refreshInterval / 1000; // Convert to seconds
    var countdownDisplay = document.getElementById('countdownDisplay');
    countdownInterval = setInterval(function () {
        countdownDisplay.textContent = countdown;
        countdown--;

        if (countdown < 0) {
            countdown = refreshInterval / 1000; // Reset countdown when it reaches 0
        }
    }, 1000); // Update every second
}

        // Function to update countdown display
        function updateCountdownDisplay() {
            var countdownDisplay = document.getElementById('countdownDisplay');
            var refreshInterval = <?php echo isset($_COOKIE['customRefreshInterval']) ? (int)$_COOKIE['customRefreshInterval'] : 10000; ?>;
            countdownDisplay.textContent = refreshInterval / 1000;
        }

        // Function to hide countdown display
        function hideCountdownDisplay() {
            var countdownDisplay = document.getElementById('countdownDisplay');
            countdownDisplay.style.display = 'none';
        }

        $(document).ready(function () {
            $('#date').datepicker({
                dateFormat: 'yy-mm-dd'
            });

            $('#enddate').datepicker({
                dateFormat: 'yy-mm-dd'
            });

            // Function to toggle auto-refresh
            $('#autoRefreshToggle').change(function () {
                if (this.checked) {
                    startAutoRefresh();
                } else {
                    stopAutoRefresh();
                }
                updateCountdownDisplay();
            });

            // Function to update refresh interval when the input value changes
            $('#refreshInterval').on('input', function () {
                var refsec = parseInt(this.value);
                if (!isNaN(refsec) && refsec >= 1) {
                    var refreshInterval = refsec * 1000; // Convert to milliseconds
                    document.cookie = 'customRefreshInterval=' + refsec + '; path=/'; // Store in a cookie
                    if ($('#autoRefreshToggle').is(':checked')) {
                        stopAutoRefresh();
                        startAutoRefresh();
                    }
                }
                updateCountdownDisplay();
            });

            // Initialize auto-refresh
            if ($('#autoRefreshToggle').is(':checked')) {
                startAutoRefresh();
            } else {
                hideCountdownDisplay();
            }

            // Initial countdown display
            updateCountdownDisplay();
        });

      // Function to start auto-refresh
function startAutoRefresh() {
    var refreshInterval = <?php echo isset($_COOKIE['customRefreshInterval']) ? (int)$_COOKIE['customRefreshInterval'] : 10000; ?> * 1000; // Convert to milliseconds
    window.autoRefreshInterval = setInterval(function () {
        refreshPage();
    }, refreshInterval);
    updateLiveCountdown(refreshInterval);
}


        // Function to stop auto-refresh
        function stopAutoRefresh() {
            clearInterval(window.autoRefreshInterval);
            clearInterval(countdownInterval);
        }

        // Function to refresh the page
        function refreshPage() {
            location.reload();
        }
    </script>
    
    <style>
    /* Style the form container */
    .form-container {
        border: 3px solid #d4d4d9;
        padding: 20px;
        border-radius: 10px;
        width: 96%;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        background-color: #fff;
    }

    /* Style the date input */
    #date {
        padding: 10px;
        border: 2px solid #6a6a74;
        border-radius: 5px;
        font-size: 14px;
        color: #555555;
    }

    /* Style the "Go" button */
    #go-button {
        padding: 10px 20px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 14px;
    }

    /* Style the auto-refresh section */
    #autoRefreshSection {
        display: flex;
        align-items: center;
        margin-top: 10px; /* Add margin to separate from the "Go" button */
    }

    #autoRefreshToggle {
        margin-right: 10px;
    }

    /* Style the refresh interval label and input */
    #refreshIntervalLabel,
    #refreshInterval {
        margin-right: 10px;
    }

    #refreshInterval {
        padding: 10px;
        border: 2px solid #6a6a74;
        border-radius: 5px;
        font-size: 14px;
        color: #555555;
        width: 81px; /* Adjust the width as needed */
    }

    /* Style the countdown display */
    #countdownDisplay {
        font-weight: bold;
        margin-left: 10px:
    }
</style>



</head> 




 
     <!--    added by dhruv -->

<!-- Add the form style directly in the form element -->
<!-- <div id="autoRefreshSection">
        <label for="autoRefreshToggle">Auto Refresh:</label>
        <input type="checkbox" id="autoRefreshToggle" <?php echo isset($_COOKIE['customRefreshInterval']) ? 'checked' : ''; ?>>
        <br>
        <label id="refreshIntervalLabel" for="refreshInterval">Refresh Interval (seconds):</label>
        <input type="number" id="refreshInterval" min="1" value="<?php echo isset($_COOKIE['customRefreshInterval']) ? (int)$_COOKIE['customRefreshInterval'] : ''; ?>">
        <br>
        <div>Seconds until next refresh: <span id="countdownDisplay"></span></div>
    </div> -->


 

<div id="dashboard">
    <h2>Call Summary</h2>


    <form style="border: 3px solid #d4d4d9; padding: 20px; border-radius: 10px; width: 96%; margin-bottom: 20px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;">

<!-- Add datepicker inputs By Dhruv -->
<?php echo form_open('/') ?>
<!-- <?php echo anchor('/?date=' . $yesterday, 'Yesterday') ?> -->
<input type="text" id="date" name="date" placeholder="Select Start Date"  autocomplete="off">
<input type="submit" value="Go">
 
<div id="autoRefreshSection" style="display: flex;align-items: center;width: 421.938;">
    <label for="autoRefreshToggle">Auto Refresh:</label>
    <input type="checkbox" id="autoRefreshToggle" <?php echo isset($_COOKIE['customRefreshInterval']) ? 'checked' : ''; ?>>
    <label id="refreshIntervalLabel" for="refreshInterval">Refresh Interval (seconds):</label>
    <input type="number" id="refreshInterval" min="1" value="<?php echo isset($_COOKIE['customRefreshInterval']) ? (int)$_COOKIE['customRefreshInterval'] : ''; ?>">
    <div>Seconds until next refresh: <span id="countdownDisplay"></span></div>
</div>
<?php echo form_close() ?>
</form>

    <br>
    <p> Date :
        <?php echo $date ?>
    </p>




    <!-- add and edit by dhruv -->
    <!-- New Table -->
    <div>
        <table>
            <tr>
                <th>Incoming</th>
                <th>Outgoing</th>
                <th>Missed</th>
                <th>No Answer</th>
                <th>Total Calls</th>
            </tr>
            <tr>
                <td>
                    <?php echo $incoming; ?>
                </td>
                <td>
                    <?php echo $outgoing; ?>
                </td>
                <td>
                    <?php echo $missed; ?>
                </td>
                <td>
                    <?php echo $noanswer; ?>
                </td>
                <td>
                    <?php echo $incoming + $outgoing + $missed + $noanswer; ?>
                </td>
            </tr>

        </table>
    </div>
    <br>
    <div class="dashboard-content">




        <div id="pie-chart" style="width: 500px; height: 400px;"></div> <!-- Increase width and height here -->
        <div id="column-chart" style="width: 500px; height: 400px;"></div> <!-- Increase width and height here -->
    </div>
</div>
 

<script>
    <!-- Inside your existing <script> tag -->
// Inside your existing <script> tag
// Load the Google Charts library
google.charts.load('current', { 'packages': ['corechart'] });

// Set a callback to run when the Google Charts library is loaded
google.charts.setOnLoadCallback(drawCharts);

// Function to draw the pie and column charts
function drawCharts() {
    // Create data for the pie chart
    var pieData = google.visualization.arrayToDataTable([
        ['Call Type', 'Number of Calls'],
        ['Missed Calls', <?php echo $missed ?>],
        ['No Answer Calls', <?php echo $noanswer ?>],
        ['Incoming Calls', <?php echo $incoming ?>],
        ['Outgoing Calls', <?php echo $outgoing ?>]
    ]);

    // Create data for the column chart
    var columnData = google.visualization.arrayToDataTable([
        ['Call Type', ' Calls', { role: 'style' }], // Add a new column for custom color
        ['Missed Calls', <?php echo $missed ?>, ''], // Initialize with empty color
        ['No Answer Calls', <?php echo $noanswer ?>, ''],
        ['Incoming Calls', <?php echo $incoming ?>, ''],
        ['Outgoing Calls', <?php echo $outgoing ?>, '']
    ]);

    // Options for the pie chart
    var pieOptions = {
        title: 'Call Type Distribution',
        width: 500, // Set the width
        height: 400, // Set the height
        colors: ['#ff0000', '#ffb74d', '#3f8d43', '#0b6fc1'], // Define custom colors
    };

    // Options for the column chart
    var columnOptions = {
        title: 'Call Type Statistics',
        bars: 'vertical',
        width: 500, // Set the width
        height: 400, // Set the height
        legend: 'none', // Remove legend
    };

    // Create the pie chart and column chart objects
    var pieChart = new google.visualization.PieChart(document.getElementById('pie-chart'));
    var columnChart = new google.visualization.ColumnChart(document.getElementById('column-chart'));

    // Draw the charts
    pieChart.draw(pieData, pieOptions);
    columnChart.draw(columnData, columnOptions);
    
    // Match the column chart colors to the pie chart colors
    for (var i = 0; i < columnData.getNumberOfRows(); i++) {
        columnData.setValue(i, 2, pieOptions.colors[i]);
    }

    // Redraw the column chart with updated colors
    columnChart.draw(columnData, columnOptions);
}


</script>
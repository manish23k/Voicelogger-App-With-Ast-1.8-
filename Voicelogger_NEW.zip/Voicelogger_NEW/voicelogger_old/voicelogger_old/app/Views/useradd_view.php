<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<?php
$options = array();
foreach ($result->getResult() as $row) {
    $options[$row->id] = $row->groupname;
}
$options['0'] = '--All--';
$options['S'] = '--Self--';
?>
<?php echo form_open('/users/add'); ?>
<?php
$userid = "";
$password = "";
$name = "";
$extension = "";
$playright = "";
$downloadright = "";
$deleteright = "";
$commentright = "";
$ogroupid = "-1";
$callsdownload = "";
$callsdelete = "";
if (isset($result_user)) {
    $row = $result_user->getRow();

    echo form_hidden('ouserid', $row->UserID!=NULL?$row->UserID:'');

    $userid = $row->UserID != NULL?$row->UserID:'';
    $password = base64_decode($row->Password);
    $name = $row->Name != NULL ? $row->Name:'';
    $extension = $row->Extension!=NULL?$row->Extension:'';
    $ogroupid = $row->groupid!=NULL?$row->groupid:'';
    $playright = $row->playright!=NULL?$row->playright:'';
    $downloadright = $row->downloadright!=NULL?$row->downloadright:'';
    $deleteright = $row->deleteright!=NULL?$row->deleteright:'';
    $commentright = $row->commentright!=NULL?$row->commentright:'';
    $callsdownload = $row->callsdownload!=NULL?$row->calldownload:'';
    $callsdelete = $row->callsdelete!=NULL?$row->callsdelete:'';
}
if ($ogroupid == '-1') {
    $ogroupid = 'S';
}
?>
<div>
    <label>User Id</label> <?php echo form_input('userid', $userid); ?>
</div>
<div>
    <label>Password</label> <?php echo form_password('password', $password); ?>
</div>
<div>
    <label>Real name</label> <?php echo form_input('name', $name); ?>
</div>
<div>
    <label>Extension</label> <?php echo form_input('extension', $extension); ?>
</div>
<div>
    <label>Group</label> <?php echo form_dropdown('groupid', $options, $ogroupid); ?>
</div>
<div>
    <label>Play</label> <?php echo form_checkbox('playright', '1', $playright == '1'); ?>
</div>
<div>
    <label>Download</label> <?php echo form_checkbox('downloadright', '1', $downloadright == '1'); ?>
</div>
<div>
    <label>Delete</label> <?php echo form_checkbox('deleteright', '1', $deleteright == '1'); ?>
</div>
<div>
    <label>Comment</label> <?php echo form_checkbox('commentright', '1', $commentright == '1'); ?>
</div>
<div>
    <label>CallsDownload</label> <?php echo form_checkbox('callsdownload', '1', $callsdownload == '1'); ?>
</div>
<div>
    <label>CallsDelete</label> <?php echo form_checkbox('callsdelete', '1', $callsdelete == '1'); ?>
</diV> 
    <?php echo form_submit('submit', 'Save'); ?>
</div>
<?php echo form_close(); ?>
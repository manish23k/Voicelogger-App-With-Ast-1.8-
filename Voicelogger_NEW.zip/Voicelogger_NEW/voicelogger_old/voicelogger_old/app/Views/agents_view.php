<?php echo anchor("agents/add", "add"); ?>
<table>
    <?php foreach ($result->getResult() as $row) { ?>
        <tr>
            <td><?php echo $row->exten; ?></td>
            <td><?php echo $row->firstname; ?></td>
            <td><?php echo $row->lastname; ?></td>
            <td><?php echo anchor('agents/edit/' . $row->exten, 'edit'); ?> | <?php echo anchor("agents/delete/$row->exten", "delete"); ?>
        </tr>
    <?php } ?>
</table>
<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
// added by dhruv

$routes->get('cronjobs/processcalls', 'CronJobs::processCalls');
$routes->get('calls/getChartData', 'Calls::getChartData');

//end 
$routes->get('/', 'Home::index');
$routes->get('home', 'Home::index');
$routes->post('home/checklogin', 'Home::checklogin');
$routes->get('home/logout', 'Home::logout');
$routes->get('calls', 'Calls::index');
$routes->get('calls/index/(:num)', 'Calls::index/$1');
$routes->get('calls/index/(:alpha)', 'Calls::index/$1');
$routes->post('calls/search', 'Calls::search');
$routes->get('/calls/comments/(:num)/(:num)/(:num)/(:any)', 'Calls::comments/$1/$2/$3/$4');
$routes->post('calls/comments/(:num)/(:num)/(:num)/(:any)', 'Calls::comments/$1/$2/$3/$4');
$routes->post('calls/multiselect', 'Calls::multiselect');
$routes->get('users/', 'Users::index');
$routes->get('users/add', 'Users::add');
$routes->post('users/add', 'Users::add');
$routes->get('users/edit/(:alpha)', 'Users::edit/$1');
$routes->post('users/edit/(:alpha)', 'Users::edit/$1');
$routes->get('users/delete/(:alpha)', 'Users::delete/$1');
$routes->get('agents', 'Agents::index');
$routes->get('agents/add', 'Agents::add');
$routes->post('agents/add', 'Agents::add');
$routes->get('agents/edit/(:num)', 'Agents::edit/$1');
$routes->post('agents/edit/(:num)', 'Agents::edit/$1');
$routes->get('agents/delete/(:num)', 'Agents::delete/$1');
$routes->get('wave/play/(:num)/(:num)/(:num)/(:any)', 'Wave::play/$1/$2/$3/$4');
$routes->get('wave/download/(:num)/(:num)/(:num)/(:any)', 'Wave::download/$1/$2/$3/$4');
$routes->get('wave/delete/(:num)/(:num)/(:num)/(:any)', 'Wave::delete/$1/$2/$3/$4');

$routes->get('groups/', 'Groups::index');
$routes->get('groups/add', 'Groups::add');
$routes->post('groups/add', 'Groups::add');
$routes->get('groups/edit/(:num)', 'Groups::edit/$1');
$routes->post('groups/edit/(:num)', 'Groups::edit/$1');
$routes->get('groups/delete/(:num)', 'Groups::delete/$1');
$routes->get('groups/extensions/(:num)', 'Groups::extensions/$1');
$routes->post('groups/extensions/(:num)', 'Groups::extensions/$1');
$routes->get('groups/exdelete/(:num)/(:num)', 'Groups::exdelete/$1/$2');
$routes->get('groups/exadd/', 'Groups::exadd');
$routes->post('groups/exadd/', 'Groups::exadd');
$routes->get('disable/', 'Disable::index');
$routes->get('disable/add', 'Disable::add');
$routes->post('disable/add', 'Disable::add');
$routes->get('disable/delete/(:num)', 'Disable::delete/$1');
$routes->get('landing/', 'Landing::index');
$routes->get('landing/add', 'Landing::add');
$routes->post('landing/add', 'Landing::add');
$routes->get('landing/edit/(:num)', 'Landing::edit/$1');
$routes->post('landing/edit/(:num)', 'Landing::edit/$1');
$routes->get('landing/delete/(:num)', 'Landing::delete/$1');

$routes->get('clients/', 'Clients::index');
$routes->get('clients/add', 'Clients::add');
$routes->post('clients/add', 'Clients::add');
$routes->get('clients/edit/(:num)', 'Clients::edit/$1');
$routes->post('clients/edit/(:num)', 'Clients::edit/$1');
$routes->get('clients/delete/(:num)', 'Clients::delete/$1');
$routes->get('clients/upload', 'Clients::upload');
$routes->post('clients/upload', 'Clients::upload');

$routes->get('delete/', 'Delete::index');
$routes->post('delete/confirm', 'Delete::confirm');
$routes->post('delete/process', 'Delete::process');

$routes->get('shutdown/', 'Shutdown::index');
$routes->post('shutdown/confirm', 'Shutdown::confirm');
$routes->post('shutdown/process', 'Shutdown::process');

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}

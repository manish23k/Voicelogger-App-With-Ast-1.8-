<?php

namespace App\Controllers;

class Incomingcheck extends Controller
{
    function Incomingcheck()
    {
        parent::Controller();
    }
    function index()
    {
        $data = array();

        $query = "select * from incoming_check order by phonenumber";
        $result = $this->db->query($query);
        $data['result'] = $result;

        $data['main'] = "incoming_view";
        return view('template', $data);
    }

    function add()
    {
        $data = array();
        if ($_POST) {
            $extension = $_POST['extension'];
            $row = array(
                'phonenumber' => "$extension",
                'numbertype' => 'E'
            );
            $this->db->insert('incoming_check', $row);
            redirect('/incomingcheck');
        } else {
            $data['main'] = 'incomingadd_view';
            return view('template', $data);
        }
    }

    function delete()
    {
        $id = $this->uri->segment(3);
        $row = array('id' => $id);
        $this->db->delete('incoming_check', $row);
        redirect('/incomingcheck');
    }
}

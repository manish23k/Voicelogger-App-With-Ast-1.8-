<?php

namespace App\Controllers;

class Landing extends BaseController
{
	function __construct()
	{
		//parent::__construct();
	}

	function index()
	{

		$data = array();
		$query = "select * from landings order by extension, callerid";
		$result = $this->db->query($query);

		$data['main'] = 'landing_view';
		$data['result'] = $result;
		return view('template', $data);
	}

	function add()
	{
		$extension = $_POST['extension'];
		$callername = $_POST['callername'];
		$callerid = $_POST['callerid'];
		$edit_id = $_POST['edit_id'];
		if (empty($edit_id)) {
			$query = "insert into landings (extension, callername, callerid) values( '$extension', '$callername', '$callerid')";
		} else {
			$query = "update landings set extension='$extension', callerid='$callerid', callername='$callername' where id=$edit_id";
		}
		$this->db->query($query);
		return redirect("landing");
	}

	function delete($id)
	{
		$query = "delete from landings where id = $id";
		$this->db->query($query);
		return redirect("landing");
	}

	function edit($id)
	{
		$query = "select * from landings where id = $id";
		$result = $this->db->query($query);
		$data = array();
		$row = $result->getRow();
		$query = "select * from landings order by extension, callerid";
		$result = $this->db->query($query);

		$data['edit_extension'] = $row->extension;
		$data['edit_callerid'] = $row->callerid;
		$data['edit_callername'] = $row->callername;
		$data['edit_id'] = $row->id;
		$data['result'] = $result;
		$data['main'] = 'landing_view';
		return view('template', $data);
	}
}

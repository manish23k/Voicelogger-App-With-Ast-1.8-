<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *     class Home extends BaseController
 *
 * For security be sure to declare any new methods as protected or private.
 */
abstract class BaseController extends Controller
{
    /**
     * Instance of the main Request object.
     *
     * @var CLIRequest|IncomingRequest
     */
    protected $request;

    /**
     * An array of helpers to be loaded automatically upon
     * class instantiation. These helpers will be available
     * to all other controllers that extend BaseController.
     *
     * @var array
     */
    protected $helpers = ['form', 'file', 'download'];

    /**
     * Be sure to declare properties for any property fetch you initialized.
     * The creation of dynamic property is deprecated in PHP 8.2.
     */
    protected $session, $uri, $db;

    /**
     * Constructor.
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        // Preload any models, libraries, etc, here.

        $this->session = \Config\Services::session();
        $this->session->csstartdate = $this->session->csstartdate == NULL ? '' : $this->session->csstartdate;
        $this->session->csenddate = $this->session->csenddate == NULL ? '' : $this->session->csenddate;
        $this->session->csstarttime = $this->session->csstarttime == NULL ? '' : $this->session->csstarttime;
        $this->session->csendtime = $this->session->csendtime == NULL ? '' : $this->session->csendtime;
        $this->session->csstartduration = $this->session->csstartduration == NULL ? '' : $this->session->csstartduration;
        $this->session->cscalltype = $this->session->cscalltype == NULL ? '' : $this->session->cscalltype;
        $this->session->csendduration = $this->session->csendduration == NULL ? '' : $this->session->csendduration;
        $this->session->csclientid = $this->session->csclientid == NULL ? '' : $this->session->csclientid;
        $this->session->csclientname = $this->session->csclientname == NULL ? '' : $this->session->csclientname;
        $this->session->csphonenumber = $this->session->csphonenumber == NULL ? '' : $this->session->csphonenumber;
        $this->session->csextension = $this->session->csextension == NULL ? '' : $this->session->csextension;
        $this->session->cscomments = $this->session->cscomments == NULL ? '' : $this->session->cscomments;
        $this->session->cspbxextn = $this->session->cspbxextn == NULL? '': $this->session->cspbxextn;
        $this->uri = new \CodeIgniter\HTTP\URI(current_url());
        $this->db = \Config\Database::connect();
    }
}

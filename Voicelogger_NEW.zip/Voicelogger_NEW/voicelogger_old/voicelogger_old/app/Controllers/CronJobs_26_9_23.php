<?php

/**
 * @author kinjal dixit
 * @date 26-Sep-2023
 */

namespace App\Controllers;

class CronJobs extends BaseController
{

    function processCalls()
    {
        $this->db = \Config\Database::connect();
        $query = "select * from calldetails where isprocessed = 0 and EndTime <> '0000-00-00 00:00:00'";
        $result = $this->db->query($query);
        $rows = $result->getResultArray();
        foreach ($rows as $row) {
            $callid = $row['callidpk'];
            $type = $row['Type'];
            $filename = $row['Filename'];

            $starttime = $row['StartTime'];
            $endtime = $row['EndTime'];
            $phonenumber = $row['PhoneNumber'];
            $pbxextn = NULL;

            $updateFlag = false;
            // updated missed/no answer
            if ($type == 'incoming') {
                if (!file_exists(config(App::class)->recording_path . $filename)) {
                    $type = 'missed';
                } {
                    $query = "select calledparty from invoip where locate('$phonenumber',callingparty)>0 and time(time) between time('$starttime') and time('$endtime')";
                    $result = $this->db->query($query);
                    $rows = $result->getResultArray();
                    if (count($rows) > 0) {
                        $pbxextn = $rows[0]['calledparty'];
                    }
                }
            } else {
                if (!file_exists(config(App::class)->recording_path . $filename)) {
                    $type = 'noanswer';
                } {
                    $query = "select calledparty from ogvoip where locate('$phonenumber',calledno)>0 and time(time) between time('$starttime') and time('$endtime')";
                    $result = $this->db->query($query);
                    $rows = $result->getResultArray();
                    if (count($rows) > 0) {
                        $pbxextn = $rows[0]['calledparty'];
                    }
                }
            }

            $query = "update calldetails set `type` = '$type', pbxextn = '$pbxextn', isprocessed=1  where callidpk = $callid";
            $this->db->query($query);
        }
    }
}

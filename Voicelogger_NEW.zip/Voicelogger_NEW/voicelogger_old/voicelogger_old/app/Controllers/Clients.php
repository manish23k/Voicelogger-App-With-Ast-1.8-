<?php

namespace App\Controllers;

class Clients extends BaseController
{
    function Clients()
    {
        // parent::Controller();
    }

    function add()
    {
        $data = array();
        if ($_POST) {
            $row = array(
                'custid' => $_POST['custid'],
                'custname' => $_POST['custname'],
                'company' => $_POST['company'],
                'address' => $_POST['address'],
                'phonenumber' => $_POST['phonenumber'],
                'mobilenumber' => $_POST['mobilenumber'],
                'alternatephonenumber' => $_POST['alternatephonenumber'],
                'alternatemobilenumber' => $_POST['alternatemobilenumber']
            );

            # insert $row into contacts table
            $builder = $this->db->table('contacts');
            $builder->insert($row);
            return redirect('clients');
        } else {
            $data['main'] = 'phonebookadd_view';

            return view('template', $data);
        }
    }

    function index()
    {
        $data = array();

        $query = "select * from contacts";
        $result = $this->db->query($query);
        $data['result'] = $result;

        $data['main'] = "phonebook_view";
        return view('template', $data);
    }

    function edit($id)
    {
        $data = array();
        if ($_POST) {
            $row = array(
                'custid' => $_POST['custid'],
                'custname' => $_POST['custname'],
                'company' => $_POST['company'],
                'address' => $_POST['address'],
                'phonenumber' => $_POST['phonenumber'],
                'mobilenumber' => $_POST['mobilenumber'],
                'alternatephonenumber' => $_POST['alternatephonenumber'],
                'alternatemobilenumber' => $_POST['alternatemobilenumber']
            );

            # insert $row into contacts table
            $builder = $this->db->table('contacts');
            $builder->where('contactid', $id);
            $builder->update($row);
            return redirect('clients');
        } else {
            $query = "select * from contacts where contactid = ?";
            $result = $this->db->query($query, array($id));
            $data['result'] = $result->getRow();
            $data['id'] = $id;
            $data['main'] = "phonebookedit_view";
            return view('template', $data);
        }
    }
    function delete($id)
    {
        $row = array('contactid' => $id);
        $builder = $this->db->table('contacts');
        $builder->delete($row);
        return redirect('clients');
    }

    function upload()
    {
        $data = array();
        if ($this->request->is('post')) {
            $file = $this->request->getFile('userfile');
            $fh = fopen($file, 'r');
            $i = 0;
            while (($line = fgetcsv($fh)) !== false) {
                if ($i == 0) {
                    $i++;
                    continue;
                }
                $row = array(
                    'custid' => $line[0],
                    'custname' => $line[1],
                    'company' => $line[2],
                    'address' => $line[3],
                    'phonenumber' => $line[4],
                    'mobilenumber' => $line[5],
                    'alternatephonenumber' => $line[6],
                    'alternatemobilenumber' => $line[7]
                );
                $builder = $this->db->table('contacts');
                $builder->insert($row);
            }
            $data['main'] = 'phonebookuploadsuccess_view';
            return view('template', $data);
        } else {
            $data['main'] = 'phonebookupload_view';
            return view('template', $data);
        }
    }
}

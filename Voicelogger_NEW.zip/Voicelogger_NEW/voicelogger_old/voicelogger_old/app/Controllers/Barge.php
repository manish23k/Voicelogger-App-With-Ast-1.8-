<?php

namespace App\Controllers;

class Barge extends BaseController
{
    function Barge()
    {
        // parent::Controller();
    }

    function index()
    {
        $data = array();
        $data['main'] = 'zaplist';
        return view('zaplist', $data);
    }

    function listen($channel)
    {
    }
}

<?php

namespace App\Controllers;

class Agents extends BaseController
{
	function __construct()
	{
		// parent::__construct();
	}

	function index()
	{
		$query = "select * from avayaagents order by exten";
		$result = $this->db->query($query);
		$data = array();
		$data['main'] = 'agents_view';
		$data['result'] = $result;
		return view('template', $data);
	}

	function edit($exten)
	{
		if ($_POST) {
			$firstname = $_POST['firstname'];
			$lastname = $_POST['lastname'];
			$query = "update avayaagents set exten = ?, firstname=? , lastname = ? where exten = ?";

			$this->db->query($query, array($exten, $firstname, $lastname, $exten));
			return redirect('agents', 'get');
		} else {
			$query = "select * from avayaagents where exten='$exten'";
			$result = $this->db->query($query);
			$data = array();
			$data['result'] = $result;
			$data['main'] = "agents_edit";
			return view('template', $data);
		}
	}

	function delete($exten)
	{
		$query = "delete from avayaagents where exten='$exten'";
		$this->db->query($query);
		return redirect('agents', 'get');
	}

	function add()
	{
		if ($_POST) {
			$exten = $_POST['exten'];
			$firstname = $_POST['firstname'];
			$lastname = $_POST['lastname'];

			$query  = "insert into avayaagents(exten, firstname, lastname) values(?,?,?)";
			$this->db->query($query, array($exten, $firstname, $lastname));
			return redirect('agents', 'get');
		} else {
			$data = array();
			$data['main'] = 'agents_add';
			return view('template', $data);
		}
	}
}

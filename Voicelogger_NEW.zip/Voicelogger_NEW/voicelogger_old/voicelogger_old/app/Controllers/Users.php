<?php

namespace App\Controllers;

class Users extends BaseController
{
    function Users()
    {
        // parent::Controller();
    }

    function index()
    {
        $db = \Config\Database::connect();

        $data = array();
        $query = "select * from userdetails left outer join groups on userdetails.groupid=groups.id order by userid";
        $result = $db->query($query);
        $data['result'] = $result;
        $data['main'] = "users_view";
        return view('template', $data);
    }

    function add()
    {
        $data = array();

        if ($_POST) {

            $row = array(
                'userid' => $_POST['userid'],
                'name' => $_POST['name'],
                'password' => base64_encode($_POST['password']),
                'extension' => $_POST['extension'],
                'groupid' => $_POST['groupid'] == 'S' ? -1 : $_POST['groupid'],
                'playright' => isset($_POST['playright']) ? '1' : '0',
                'deleteright' => isset($_POST['deleteright']) ? '1' : '0',
                'downloadright' => isset($_POST['downloadright']) ? '1' : '0',
                'commentright' => isset($_POST['commentright']) ? '1' : '0',
                'callsdownload' => isset($_POST['callsdownload']) ? '1' : '0',
                'callsdelete' => isset($_POST['callsdelete']) ? '1' : '0'
            );

            if (isset($_POST['ouserid'])) {
                $builder = $this->db->table('userdetails');
                $builder->update($row, array('userid' => $_POST['ouserid']));

                //$this->db->update('userdetails', $row, array('userid' => $_POST['ouserid']));
            } else {
                $builder = $this->db->table('userdetails');
                $builder->insert($row);

                //$this->db->insert('userdetails', $row);
            }

            return redirect('users');
        } else {

            $query = "select * from groups order by groupname";
            $result = $this->db->query($query);

            $data['main'] = 'useradd_view';
            $data['result'] = $result;

            return view('template', $data);
        }
    }

    function delete($id)
    {
        $builder = $this->db->table('userdetails');
        $builder->where('userid', $id);
        $builder->delete();

        return redirect('users');
    }

    function edit($id)
    {
        $data = array();

        $query = "select * from groups order by groupname";
        $result = $this->db->query($query);

        $builder = $this->db->table('userdetails');
        $builder->where('userid', $id);
        $result_user = $builder->get();

        $data['main'] = 'useradd_view';
        $data['result'] = $result;
        $data['result_user'] = $result_user;
        return view('template', $data);
    }
}

<?php

/**
 * @author kinjal dixit
 * @date 26-Sep-2023
 */

namespace App\Controllers;
use DateTime;  

class CronJobs extends BaseController
{

    /**
     * Summary of processCalls
     * @return void
     */
    function processCalls()
    {
        $this->db = \Config\Database::connect();
        $query = "select * from calldetails where isprocessed = 0 and EndTime <> '0000-00-00 00:00:00'";
        $result = $this->db->query($query);
        $rows = $result->getResultArray();
        foreach ($rows as $row) {
            $callid = $row['callidpk'];
            $type = $row['Type'];
            $filename = $row['Filename'];

            $starttime = $row['StartTime'];
            $endtime = $row['EndTime'];
            $phonenumber = $row['PhoneNumber'];
            $pbxextn = NULL;

            $updateFlag = false;
            // updated missed/no answer
            // replace from here
            if ($type == 'incoming') {
                if (!file_exists(config(App::class)->recording_path . $filename)) {
                    $type = 'missed';
                } {
                    $query = "select calledparty, time, sec from invoip where locate('$phonenumber',callingparty)>0 and time(time) between time('$starttime') and time('$endtime') and calltype in ('N','U','I','G','Q','C','F','D','DU')";
                    $result = $this->db->query($query);
                    $rows = $result->getResultArray();
                    if (count($rows) > 0) {
                        $pbxextn = $rows[0]['calledparty'];
                        while (true) {
                            $time = $rows[0]['time'];
                            $sec = $rows[0]['sec'];
                            $sec = +$sec + 10;
                            $query = "SELECT * from invoip WHERE `time` < ADDTIME('$time', '$sec') and locate('$phonenumber', calledno)>0 and calltype='T' limit 1";
                            $result = $this->db->query($query);
                            $rows = $result->getResultArray();
                            if (count($rows) > 0) {
                                $pbxextn = $pbxextn . ',' . $rows[0]['calledparty'];
                            } else {
                                break;
                            }
                        }
                    }
                }
            } else {
                if (!file_exists(config(App::class)->recording_path . $filename)) {
                    $type = 'noanswer';
                } {
                    $query = "select calledparty, time, sec from ogvoip where locate('$phonenumber',calledno)>0 and time(time) between time('$starttime') and time('$endtime') and calltype in ('I','U','D','C','R')"; //  //calltype='I'";
                    $result = $this->db->query($query);
                    $rows = $result->getResultArray();
                    if (count($rows) > 0) {
                        $pbxextn = $rows[0]['calledparty'];
                        while (true) {
                            $time = $rows[0]['time'];
                            $sec = $rows[0]['sec'];
                            $sec = +$sec + 10;
                            $query = "SELECT * from ogvoip WHERE `time` < ADDTIME('$time', '$sec') and locate('$phonenumber', calledno)>0 and calltype='TI' limit 1";
                            $result = $this->db->query($query);
                            $rows = $result->getResultArray();
                            if (count($rows) > 0) {
                                $pbxextn = $pbxextn . ',' . $rows[0]['calledparty'];
                            } else {
                                break;
                            }
                        }
                    }
                }
            }
            // till here
            $query = "update calldetails set `type` = '$type', pbxextn = '$pbxextn', isprocessed=1  where callidpk = $callid";
            $this->db->query($query);
	//echo "$query";
        }
    }
}

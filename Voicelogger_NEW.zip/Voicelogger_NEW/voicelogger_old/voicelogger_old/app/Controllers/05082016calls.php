<?php
class Calls extends Controller {
    function Calls() {
        parent::Controller();
    }


    function index() {
        $showResults = TRUE;
        $data = array();
        $disp = $this->uri->segment(3);

        $page=0;
        if($disp=='download') {
            $showResults = FALSE;
        } else {
            $page = $disp;
            if(empty($page) || $page=='-1') {
                $page=0;
            }
        }
        $current = $page * 100;
        $previous = ($page-1);
        $next = ($page+1);

        $groupid=$this->session->userdata('groupid');

        $whereclause = "";
        if($groupid > 0) {
            $whereclause = " where right(calldetails.Extension,8) in (select groupextensions.extension from groupextensions where groupid = $groupid) ";
        }
        if($groupid < 0) {
            $ext = $this->session->userdata('extension');
            $whereclause = " where right(calldetails.Extension,8) = '$ext' ";
        }

        $parameter = $this->session->userdata('csstartdate');
        if(!empty($parameter)) {
            $clause = "date(starttime) >= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->userdata('csenddate');
        if(!empty($parameter)) {
            $clause = "date(starttime) <= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->userdata('csstarttime');
        if(!empty($parameter)) {
            $clause = "time(starttime) >= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->userdata('csendtime');
        if(!empty($parameter)) {
            $clause = "time(starttime) <= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->userdata('csstartduration');
        if(!empty($parameter)) {
            $clause = "timediff(endtime,starttime) >= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->userdata('csendduration');
        if(!empty($parameter)) {
            $clause = "timediff(endtime,starttime) <= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->userdata('cscalltype');
        if(!empty($parameter) && $parameter != 'xx') {
            if($parameter == 'mi') {
                $parameter = 'incoming';
            }

            if($parameter == 'na') {
                $parameter = 'outgoing';
            }
	     
            $clause = "type = '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->userdata('csclientid');
        if(!empty($parameter)) {
            $clause = "contacts.custid = '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->userdata('csclientname');
        if(!empty($parameter)) {
            $clause = "contacts.custname = '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->userdata('csphonenumber');
        if(!empty($parameter)) {
            //$clause = "calldetails.phonenumber = '$parameter'";
            $clause = "calldetails.phonenumber like '%$parameter%'";
	     $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->userdata('csextension');
        if(!empty($parameter)) {
            //$clause = "right(calldetails.extension, 8) = '$parameter'";
			$clause = "calldetails.extension like '%$parameter%'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->userdata('cscomments');
        if(!empty($parameter)) {
            $clause = "Comments like '%$parameter%'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $query = "select phonenumber from logrules order by phonenumber";
        $res = $this->db->query($query);
        if($res->num_rows()>0) {
            $clause = " right(calldetails.extension,8) not in (select logrules.phonenumber from logrules) ";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }
        $res->free_result();

        $query = "select calldetails.Extension, calldetails.PhoneNumber, Date(StartTime) as StartDate, Time(StartTime) as StartTimeTime, " .
                "TimeDiff(EndTime, StartTime) as Duration, Type, calldetails.FileName, calldetails.callidpk,contacts.custname, comments from " .
                "calldetails left outer join contacts on calldetails.phonenumber=contacts.phonenumber left outer join commentsmaster on " .
                "calldetails.FileName = commentsmaster.FileName $whereclause order by StartTime desc ";
        if($showResults) {
            $query = $query. " limit $current,100";
        } else {
            $query = str_replace('calldetails.FileName, ', '', $query);
        }

        //echo $query;

        $result = $this->db->query($query);
        if(!$showResults) {
            $this->load->dbutil();
            $csv = $this->dbutil->csv_from_result($result);
            $this->load->helper('download');
            force_download('searchresults.csv', $csv);
            redirect("/calls/index/$page");
        }
        $data['previous']=$previous;
        $data['next']=$next;
        $data['result']=$result;
        $data['main']="calls_view";
        $this->load->view('template', $data);
    }

    function search() {

        $this->session->unset_userdata('csstartdate');
        $this->session->unset_userdata('csenddate');
        $this->session->unset_userdata('csstarttime');
        $this->session->unset_userdata('csendtime');
        $this->session->unset_userdata('csstartduration');
        $this->session->unset_userdata('csendduration');
        $this->session->unset_userdata('cscalltype');
        $this->session->unset_userdata('csclientid');
        $this->session->unset_userdata('csclientname');
        $this->session->unset_userdata('csphonenumber');
        $this->session->unset_userdata('csextension');
        $this->session->unset_userdata('cscomments');
        if(!empty($_POST['startdate'])) {
            $this->session->set_userdata('csstartdate', $_POST['startdate']);
        }
        if(!empty($_POST['enddate'])) {
            $this->session->set_userdata('csenddate', $_POST['enddate']);
        }
        if(!empty($_POST['starttime'])) {
            $this->session->set_userdata('csstarttime', $_POST['starttime']);
        }

        if(!empty($_POST['endtime'])) {
            $this->session->set_userdata('csendtime', $_POST['endtime']);
        }
        if(!empty($_POST['startduration'])) {
            $this->session->set_userdata('csstartduration', $_POST['startduration']);
        }

        if(!empty($_POST['endduration'])) {
            $this->session->set_userdata('csendduration', $_POST['endduration']);
        }
        if(!empty($_POST['calltype'])) {
            $this->session->set_userdata('cscalltype', $_POST['calltype']);
        }

        if(!empty($_POST['clientid'])) {
            $this->session->set_userdata('csclientid', $_POST['clientid']);
        }

        if(!empty($_POST['clientname'])) {
            $this->session->set_userdata('csclientname', $_POST['clientname']);
        }

        if(!empty($_POST['phonenumber'])) {
            $this->session->set_userdata('csphonenumber', $_POST['phonenumber']);
        }

        if(!empty($_POST['extension'])) {
            $this->session->set_userdata('csextension', $_POST['extension']);
        }

        if(!empty($_POST['comments'])) {
            $this->session->set_userdata('cscomments', $_POST['comments']);
        }

        redirect('/calls/');
    }

    function comments() {
        $data = array();
       $filename = $this->uri->segment(3)."/".$this->uri->segment(4)."/".$this->uri->segment(5)."/".$this->uri->segment(6);
	// $filename = $this->uri->segment(3);
        if($_POST) {
            $query = "delete from commentsmaster where filename='$filename'";
            $this->db->query($query);
            $this->db->insert('commentsmaster', array(
                    'comments' => $_POST['comments'],
                    'filename' => $filename
            ));
            redirect('/calls');
        } else {
            $query = "select * from commentsmaster where filename='$filename'";
            $result = $this->db->query($query);
            $comments = '';
            if($result->num_rows()>0) {
                $row = $result->row();
                $comments = $row->Comments;
            }
            $data['comments']=$comments;
            $data['filename'] = $filename;
            $data['main'] = 'comments';
            $this->load->view('template', $data);
        }
    }

    function multiselect() {         
        $b = $this->input->post('submit');

        if($b == 'Download Selected'){
            $down = "";
            $filenames = $this->input->post('filenames');
            if ( $filenames == ""){
            echo "NO File selected";
            }else{
                foreach ($filenames as $filename){              
                $filename = addcslashes($filename,' ');                
                $down .= "/var/www/recordings/files/".$filename." ";
                }               
                shell_exec("rm -rf /var/www/html/download/recording/*.* 2>&1");
                shell_exec("cp $down /var/www/html/download/recording/");               
                $output = shell_exec("tar -cjf /var/www/html/download/recording.tar.gz /var/www/html/download/recording/*.wav");
                //cpszf
                // $output = shell_exec("zip -r /var/www/html/download/recording.zip /var/www/html/download/recording/*.wav");
                echo "<pre>$output</pre>";
                echo "<a href='/download/recording.tar.gz'>download</a> ||";
         ///usr/bin/sudo /bin/cp /var/www/recordings/files/2011/07/15/PBX-9913387000-2000-20110715-145747-1310722067.2.wav /var/www/recordings/files/2011/07/15/PBX-9227231501-2000-20110715-144246-1310721166.0.wav /var/www/html/download/recording/
            }

        }elseif($b == 'Delete Selected'){
         
            $down = "";
            $filenames = $this->input->post('filenames');
            if ( $filenames == ""){
                echo "NO File selected";
            }else{    
                
                $data = array('main' => 'multidelete_2');
                $data['filenames'] = $filenames;
                $this->load->view('template', $data);
               // $c = $this->input->post('submit');
                  
            }

        }elseif($b == 'OKAY'){
                $filenames = $this->input->post('filenames');
                foreach ($filenames as $filename){
                $query = "delete from calldetails where FileName='$filename'";
                $this->db->query($query);
                @unlink($this->config->item('recording_path').$filename);
                //echo $filename;
                echo "<script language='javascript' type='text/javascript'>window.close();if (window.opener && !window.opener.closed) {window.opener.location.reload();} </script>";
                }            
         redirect('/calls');
        }elseif($b == 'CANCEL'){
            redirect('/calls');
        }  
   
  }
    
}

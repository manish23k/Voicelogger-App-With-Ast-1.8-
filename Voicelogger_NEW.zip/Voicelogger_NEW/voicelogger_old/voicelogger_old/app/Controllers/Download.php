<?php
class Download extends Controller
{
	function Download()
	{
		parent::Controller();
	}

	function index()
	{
		$data['main'] = "download_view";
		return view('template', $data);
	}

	function createdl()
	{
		set_time_limit(0);
		$startdate = $_POST['startdate'];
		$enddate = $_POST['enddate'];
		$zipfile = "voicefiles-$startdate-$enddate.zip";
		//$this->load->library("pclzip", array('p_zipname' => "/var/www/voicelogger/$zipfile"));

		require_once("pclzip.php");
		$archive = new PclZip("/var/www/voicelogger/$zipfile");
		$query = "select * from calldetails where starttime>=? and endtime<=?";
		$result = $this->db->query($query, array($startdate, $enddate));
		//$this->load->library('zip');
		if ($result->num_rows() > 0) {
			$plist = array();
			foreach ($result->getResult() as $row) {
				$filename = config(App::class)->recording_path . $row->Filename;
				echo "<br/>$filename:";
				if (file_exists($filename)) {
					$plist[] = $filename;
					echo "added";
				} else {
					echo "skipped!!";
				}
				//echo "$filename<br/>";
			}
			$v = $archive->create($plist);
			if ($v == 0) {
				echo "error" . $archive->errorInfo(true);
			}

			//$this->zip->download("voicefiles-$startdate-$enddate.zip");
			//$this->load->helper('download');
			//********echo "<a href='/var/www/voicelogger/$zipfile'>download</a> ||";
			echo "<a href='/recordings/$zipfile'>download</a> ||";
			echo anchor("/download/deletedl/$zipfile", "delete");
		} else {
			$this->session->set_flashdata('dlmess', "no files/records in that date range");
			redirect("/download");
		}
	}

	function deletedl($zip)
	{
		unlink("/var/www/voicelogger/$zip");
		echo "deleted";
		echo anchor("/", "home");
	}
}

<?php

namespace App\Controllers;

class Groups extends BaseController
{
    function Groups()
    {
        // parent::Controller();
    }

    function index()
    {
        $data = array();

        $query = "select id, groupname from groups order by groupname";
        $result = $this->db->query($query);
        $data['result'] = $result;
        $data['main'] = "groups_view";
        return view('template', $data);
    }

    function add()
    {
        $data = array();
        if ($_POST) {
            $record = array('groupname' => $_POST['groupname']);
            if (isset($_POST['id'])) {
                $builder = $this->db->table('groups');
                $builder->update($record, array('id' => $_POST['id']));
                //$this->db->update('groups', $record, array('id' => $_POST['id']));
            } else {
                $builder = $this->db->table('groups');
                $builder->insert($record);
                //$this->db->insert('groups', $record);
                $_SESSION['status'] = 'added successfully';
                $this->session->markAsFlashdata('status');
            }
            return redirect('groups', 'refresh');
        }
        $data['main'] = 'groupadd_view';
        return view('template', $data);
    }

    function edit($id)
    {
        $data = array();
        if ($_POST) {
            $record = array('groupname' => $_POST['groupname']);
            $this->db->update('groups', $record, array('id' => $_POST['id']));
            return redirect('groups', 'refresh');
        }
        $result = $this->db->query("select * from groups where id=$id");

        $data['main'] = 'groupadd_view';
        $data['result'] = $result;
        return view('template', $data);
    }

    function delete($id)
    {
        $builder = $this->db->table('groups');
        $builder->delete(array('id' => $id));
        return redirect('groups');
    }

    function extensions($groupid)
    {
        $query = "select * from groupextensions where groupid=$groupid order by extension";
        $result = $this->db->query($query);
        $query = "select distinct right(calldetails.extension,13) as extension from calldetails order by extension";
        $result_ext = $this->db->query($query);

        $data['main'] = 'groupextensions_view';
        $data['result'] = $result;
        $data['result_ext'] = $result_ext;
        $data['groupid'] = $groupid;
        return view('template', $data);
    }

    function exdelete($id, $groupid)
    {
        $query = "delete from groupextensions where id = $id";
        $this->db->query($query);
        return redirect("groups");
    }

    function exadd()
    {
        $groupid = $_POST['groupid'];
        $extension = $_POST['extension'];
        $query = "delete from groupextensions where groupid=$groupid";
        $this->db->query($query);

        foreach ($extension as $e) {
            $query = "insert into groupextensions (groupid, extension) values ($groupid, '$e')";
            $this->db->query($query);
        }

        return redirect("groups");
    }
}

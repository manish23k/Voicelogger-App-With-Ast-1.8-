<?php

namespace App\Controllers;

class View extends BaseController
{
    function View()
    {
        //parent::Controller();
    }

    function index($page = '0')
    {
        $Calldetails_model = model('Calldetails_model');
        //$this->Calldetails_model->loadCalldetails();
        $calls = $Calldetails_model->fetchCallDetails($page);
        $pager = \Config\Services::pager();


        $config['base_url'] = "http://manishk.dyndns.org/voicelogger/index.php/view/index/";
        $config['total_rows'] = $calls['num_rows'];
        $config['per_page'] = '20';
        // [todo] $this->pagination->initialize($config);
        $data['query'] = $calls;
        $data['main'] = 'calldetails';
        return view('template', $data);
    }
}

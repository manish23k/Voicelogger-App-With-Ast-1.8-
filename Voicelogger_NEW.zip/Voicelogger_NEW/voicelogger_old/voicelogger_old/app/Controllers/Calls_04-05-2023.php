<?php

namespace App\Controllers;

class Calls extends BaseController
{
    // function Calls()
    // {
    //     parent::Controller();
    // }


    function index($disp = '')
    {


        $showResults = TRUE;
        $data = array();

        $page = 0;
        if ($disp == 'download') {
            $showResults = FALSE;
        } else {
            $page = $disp;
            if (empty($page) || $page == '-1') {
                $page = 0;
            }
        }
        $current = $page * 100;
        $previous = $page - 1;
        $next = ($page + 1);

        $groupid = $this->session->get('groupid');

        $whereclause = "";
        if ($groupid > 0) {
            $whereclause = " where right(calldetails.Extension,8) in (select groupextensions.extension from groupextensions where groupid = $groupid) ";
        }
        if ($groupid < 0) {
            $ext = $this->session->get('extension');
            $whereclause = " where right(calldetails.Extension,8) = '$ext' ";
        }

        $parameter = $this->session->get('csstartdate');
        if (!empty($parameter)) {
            $clause = "date(starttime) >= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->get('csenddate');
        if (!empty($parameter)) {
            $clause = "date(starttime) <= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->get('csstarttime');
        if (!empty($parameter)) {
            $clause = "time(starttime) >= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->get('csendtime');
        if (!empty($parameter)) {
            $clause = "time(starttime) <= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->get('csstartduration');
        if (!empty($parameter)) {
            $clause = "timediff(endtime,starttime) >= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->get('csendduration');
        if (!empty($parameter)) {
            $clause = "timediff(endtime,starttime) <= '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->get('cscalltype');
        if (!empty($parameter) && $parameter != 'xx') {
            if ($parameter == 'mi') {
                $parameter = 'incoming';
            }

            if ($parameter == 'na') {
                $parameter = 'outgoing';
            }

            $clause = "type = '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->get('csclientid');
        if (!empty($parameter)) {
            $clause = "contacts.custid = '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->get('csclientname');
        if (!empty($parameter)) {
            $clause = "contacts.custname = '$parameter'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->get('csphonenumber');
        if (!empty($parameter)) {
            //$clause = "calldetails.phonenumber = '$parameter'";
            $clause = "calldetails.phonenumber like '%$parameter%'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->get('csextension');
        if (!empty($parameter)) {
            //$clause = "right(calldetails.extension, 8) = '$parameter'";
            $clause = "calldetails.extension like '%$parameter%'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $parameter = $this->session->get('cscomments');
        if (!empty($parameter)) {
            $clause = "Comments like '%$parameter%'";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }

        $query = "select phonenumber from logrules order by phonenumber";
        $res = $this->db->query($query);
        if ($res->getNumRows() > 0) {
            $clause = " right(calldetails.extension,8) not in (select logrules.phonenumber from logrules) ";
            $whereclause .= empty($whereclause) ? ' where ' : ' and ';
            $whereclause .= $clause;
        }
        $res->freeResult();

        $query = "select calldetails.Extension, calldetails.PhoneNumber, Date(StartTime) as StartDate, Time(StartTime) as StartTimeTime, " .
            "TimeDiff(EndTime, StartTime) as Duration, Type, calldetails.FileName FileName, calldetails.callidpk,contacts.custname, comments from " .
            "calldetails left outer join contacts on calldetails.phonenumber=contacts.phonenumber left outer join commentsmaster on " .
            "calldetails.FileName = commentsmaster.FileName $whereclause order by StartTime desc ";
        if ($showResults) {
            $query = $query . " limit $current,100";
        } else {
            $query = str_replace('calldetails.FileName, ', '', $query);
        }

        //echo $query;

        $result = $this->db->query($query);
        if (!$showResults) {
            $filename = 'searchresults.csv';

            // download query as csv
            header("Content-type: text/csv");
            header("Content-Disposition: attachment; filename=$filename");
            header("Pragma: no-cache");
            header("Expires: 0");
            header('Content-Description: File Transfer');

            $file = fopen('php://output', 'w');
            fputcsv($file, ['Extension', 'PhoneNumber', 'StartDate', 'StartTime', 'Duration', 'Type', 'FileName', 'CallID', 'Customer', 'Comments']);
            foreach ($result->getResultArray() as $row) {
                fputcsv($file, $row);
            }
            fflush($file);
            fclose($file);
            // $this->load->this->dbutil();
            // $csv = $this->this->dbutil->csv_from_result($result, ",", "\n", '"', $this->session->get('cscalltype'), config(App::class)->recording_path);
            // $this->load->helper('download');
            // force_download('searchresults.csv', $csv);
            //return redirect("calls");
            exit;
        }
        $data['previous'] = $previous;
        $data['next'] = $next;
        $data['result'] = $result;
        $data['main'] = "calls_view";
        return view('template', $data);
    }

    function search()
    {
        $this->session->remove('csstartdate');
        $this->session->remove('csenddate');
        $this->session->remove('csstarttime');
        $this->session->remove('csendtime');
        $this->session->remove('csstartduration');
        $this->session->remove('csendduration');
        $this->session->remove('cscalltype');
        $this->session->remove('csclientid');
        $this->session->remove('csclientname');
        $this->session->remove('csphonenumber');
        $this->session->remove('csextension');
        $this->session->remove('cscomments');
        if (!empty($_POST['startdate'])) {
            $this->session->set('csstartdate', $_POST['startdate']);
        }
        if (!empty($_POST['enddate'])) {
            $this->session->set('csenddate', $_POST['enddate']);
        }
        if (!empty($_POST['starttime'])) {
            $this->session->set('csstarttime', $_POST['starttime']);
        }

        if (!empty($_POST['endtime'])) {
            $this->session->set('csendtime', $_POST['endtime']);
        }
        if (!empty($_POST['startduration'])) {
            $this->session->set('csstartduration', $_POST['startduration']);
        }

        if (!empty($_POST['endduration'])) {
            $this->session->set('csendduration', $_POST['endduration']);
        }
        if (!empty($_POST['calltype'])) {
            $this->session->set('cscalltype', $_POST['calltype']);
        }

        if (!empty($_POST['clientid'])) {
            $this->session->set('csclientid', $_POST['clientid']);
        }

        if (!empty($_POST['clientname'])) {
            $this->session->set('csclientname', $_POST['clientname']);
        }

        if (!empty($_POST['phonenumber'])) {
            $this->session->set('csphonenumber', $_POST['phonenumber']);
        }

        if (!empty($_POST['extension'])) {
            $this->session->set('csextension', $_POST['extension']);
        }

        if (!empty($_POST['comments'])) {
            $this->session->set('cscomments', $_POST['comments']);
        }

        return redirect('calls');
    }

    function comments($yy, $mm, $dd, $fn)
    {
        $this->db = \Config\Database::connect();
        $data = array();
        $filename = $yy . "/" . $mm . "/" . $dd . "/" . $fn;
        // $filename = $yy;
        if ($_POST) {
            $query = "delete from commentsmaster where filename='$filename'";
            $this->db->query($query);

            # insert the comments
            $builder = $this->db->table('commentsmaster');
            $builder->insert([
                'comments' => $_POST['comments'],
                'filename' => $filename
            ]);
            return redirect('calls');
        } else {
            $query = "select * from commentsmaster where filename='$filename'";
            $result = $this->db->query($query);
            $comments = '';
            if ($result->getNumRows() > 0) {
                $row = $result->getRow();
                $comments = $row->Comments;
            }
            $data['comments'] = $comments;
            $data['filename'] = $filename;
            $data['main'] = 'comments';
            return view('template', $data);
        }
    }

    function multiselect()
    {
        $b = $this->request->getVar('submit');

        if ($b == 'Download Selected') {
            $down = "";
            $filenames = $this->request->getVar('filenames');
            if ($filenames == "") {
                echo "NO File selected";
            } else {
                foreach ($filenames as $filename) {
                    $filename = addcslashes($filename, ' ');
                    $down .=  config(App::class)->recording_path . $filename . " ";
                }
                # MANISH TODO
                shell_exec("rm -rf /var/www/html/download/recording/*.* 2>&1");
                shell_exec("cp $down /var/www/html/download/recording/");
                $output = shell_exec("tar -cjf /var/www/html/download/recording.tar.gz /var/www/html/download/recording/*.wav");
                //cpszf
                // $output = shell_exec("zip -r /var/www/html/download/recording.zip /var/www/html/download/recording/*.wav");
                echo "<pre>$output</pre>";
                echo "<a href='/download/recording.tar.gz'>download</a> ||";
                ///usr/bin/sudo /bin/cp /var/www/recordings/files/2011/07/15/PBX-9913387000-2000-20110715-145747-1310722067.2.wav /var/www/recordings/files/2011/07/15/PBX-9227231501-2000-20110715-144246-1310721166.0.wav /var/www/html/download/recording/
            }
        } elseif ($b == 'Delete Selected') {

            $down = "";
            $filenames = $this->request->getVar('filenames');
            if ($filenames == "") {
                echo "NO File selected";
            } else {

                $data = array('main' => 'multidelete_2');
                $data['filenames'] = $filenames;
                $this->request->getVar('template', $data);
                // $c = $this->request->getVar('submit');

            }
        } elseif ($b == 'OKAY') {
            $filenames = $this->request->getVar('filenames');
            foreach ($filenames as $filename) {
                $query = "delete from calldetails where FileName='$filename'";
                $this->db->query($query);
                @unlink(config(App::class)->recording_path . $filename);
                //echo $filename;
                echo "<script language='javascript' type='text/javascript'>window.close();if (window.opener && !window.opener.closed) {window.opener.location.reload();} </script>";
            }
            return redirect('calls');
        } elseif ($b == 'CANCEL') {
            return redirect('calls');
        }
    }
}

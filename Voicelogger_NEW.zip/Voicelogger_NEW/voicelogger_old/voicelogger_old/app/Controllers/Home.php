<?php

namespace App\Controllers;


// class Home extends BaseController
// {
//     public function index()
//     {
//         return view('welcome_message');
//     }
// }

class Home extends BaseController
{

    // public function Home() {
    //     parent::Controller();
    // }
    

    public function index()
    {
        $date=$_GET['date'];
        if ($date == '') {
            $date=date('Y-m-d');
        }
        helper('form');
        $session = \Config\Services::session();
        $data = array();
        $data['date']=$date;
        $val = $session->get('userid');
        if (!$val) {
            $data['main'] = 'login_view';
        } else {
            $data['main'] = 'home_view';
            $today = date('Y-m-d');
            $yesterday = date('Y-m-d', strtotime('-1 day'));
            $data['today'] = $today;
            $data['yesterday'] = $yesterday;
            $data['incoming'] = $this->countIncomingCalls($date);
            $data['outgoing'] = $this->countOutgoingCalls($date);
            $data['missed'] = $this->countMissedCalls($date);
            $data['noanswer'] = $this->countNoAnswerCalls($date);
        }
        return view('template', $data);
    }

    

    public function checklogin()
    {
        $db = \Config\Database::connect();
        $session = \Config\Services::session();

        $username = $_POST['username'];
        $password = base64_encode($_POST['password']);

        $query = "select * from userdetails where userid = '{$username}' and password='{$password}'";
        // echo $query;
        // exit;
        $result = $db->query($query);
        if ($result->getNumRows() > 0) {
            $row = $result->getRow();
            $data = array(
                "userid" => $row->UserID,
                "username" => $row->Name,
                "groupid" => $row->groupid,
                "extension" => $row->Extension,
                "playright" => $row->playright,
                "deleteright" => $row->deleteright,
                "downloadright" => $row->downloadright,
                "callsdownload" => $row->callsdownload,
                "callsdelete" => $row->callsdelete,
                "commentright" => $row->commentright

            );
            $session->set($data);
        }
        return redirect("/");
    }

    public function logout()
    {
        $session = \Config\Services::session();
        $session->destroy();
        return redirect("/");
    }

    
function countIncomingCalls($date)
{
    $query = "SELECT COUNT(*) AS count FROM calldetails WHERE Type = 'incoming' and date(StartTime) = ?";
    $result = $this->db->query($query, array($date));
    $row = $result->getRow();
    return $row->count;
}

function countOutgoingCalls($date)
{
    $query = "SELECT COUNT(*) AS count FROM calldetails WHERE Type = 'outgoing' and date(StartTime)=?";
    $result = $this->db->query($query, array($date));
    $row = $result->getRow();
    return $row->count;
}

function countMissedCalls($date)
{
    $query = "SELECT COUNT(*) AS count FROM calldetails WHERE Type = 'missed' and date(StartTime)=?";
    $result = $this->db->query($query, array($date));
    $row = $result->getRow();
    return $row->count;
}

function countNoAnswerCalls($date)
{
    $query = "SELECT COUNT(*) AS count FROM calldetails WHERE Type = 'noanswer' and date(StartTime)=?";
    $result = $this->db->query($query, array($date));
    $row = $result->getRow();
    return $row->count;
}


    // function import() {
    // 	// 7 = date, time, x, direction, exten, phone, x
    // 	// 9 = date, time, x, direction, x, x, phone, exten, x
    // 	$line = $_POST['line'];
    // 	$hb = trim($line);
    // 	$hb = preg_split('/\s/', $hb, -1, PREG_SPLIT_NO_EMPTY);
    // 	$c = count($hb);
    // 	if($c == 7) {
    // 		//print_r($hb);
    // 		$date = $this->parseDateTime($hb[0], $hb[1]);
    // 		$dir = $hb[3];
    // 		$exten = $hb[4];
    // 		$phone = $hb[5];
    // 	} else if($c == 9) {
    // 		//print_r($hb);
    // 		$date = $this->parseDateTime($hb[0], $hb[1]);
    // 		$dir = $hb[3];
    // 		$exten = $hb[7];
    // 		$phone = $hb[6];
    // 	} else {
    // 		//echo $c;
    // 		exit;
    // 	}
    // 	if(substr($phone, strlen($phone)-1)=='#') {
    // 		$phone = substr($phone, 0, strlen($phone)-1);
    // 	}

    // 	$this->db->insert('avayacdr', array(
    // 		'calldate'=>$date,
    // 		'direction'=>$dir,
    // 		'exten'=>$exten,
    // 		'phone'=>$phone));
    // }

    // function parseDateTime($d, $t) {
    // 	$mm = substr($d, 0, 2);
    // 	$dd = substr($d, 2, 2);
    // 	$yy = "20" . substr($d, 4, 2);
    // 	$hh = substr($t, 0, 2);
    // 	$mi = substr($t, 2, 2);

    // 	$dt = date("$yy-$mm-$dd $hh:$mi:00");
    // 	$utc = new DateTimeZone("UTC");
    // 	$isttz = new DateTimeZone("Asia/Kolkata");
    // 	//$tt= new DateTime($dt, $isttz);
    // 	//$tt->setTimeZone($utc);
    // 	//return $tt->format('Y-m-d H:i');
    // 	return $dt;
    // }


    // function wavtomp3() {
    // 	$recorddir="/var/www/recordings/files/";

    // 	$sql = "select * from calldetails where endtime is not null and cstatus is null and right(filename,3)='wav' limit 500";
    // 	$result = $this->db->query($sql);

    // 	foreach($result->getResult() as $row) {
    // 		$orignal = $row->Filename;
    // 		$filename = $recorddir.$row->Filename;

    // 		echo $filename;
    // 		$endtime = $row->EndTime;

    // 		$len = strlen($filename);
    // 		$mp3name = substr($filename, 0, $len-3)."mp3";

    // 		$cmd = 'lame -b 16 -m m -q 9-resample "'.$filename.'" "'.$mp3name.'" 2>&1';

    // 		$output = array();
    // 		$result = -1;
    // 		exec($cmd, $output, $result);
    // 		echo ":".$result."<br>";
    // 		//var_dump($output, $result);
    // 		if($result == 0) {
    // 			//echo "cstatus = 1";
    // 			$sql = "update calldetails set cstatus = 1, filename = ? where filename = ? and endtime = ?";
    // 			$this->db->query($sql, array($mp3name, $orignal, $endtime));

    // 			$cmd = 'rm -f '.$filename;
    // 			$result = -1;
    // 			$output = array();
    // 			exec($cmd, $output, $result);
    // 			//var_dump($output, $result);
    // 		} else {
    // 			//echo "cstatus = 2";
    // 			$sql = "update calldetails set cstatus = 2 where filename = ? and endtime = ?";
    // 			$this->db->query($sql, array($orignal, $endtime));
    // 		}
    // 	}
    // }
}

/* End of file welcome.php */
/* Location: ./system/application/controllers/welcome.php */

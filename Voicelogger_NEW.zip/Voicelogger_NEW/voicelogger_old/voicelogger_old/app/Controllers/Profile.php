<?php

namespace App\Controllers;

class Profile extends Controller
{
    function Profile()
    {
        parent::Controller();
    }

    function index()
    {
        $data = array();
        $data['main'] = "profile_view";
        return view('template', $data);
    }
}

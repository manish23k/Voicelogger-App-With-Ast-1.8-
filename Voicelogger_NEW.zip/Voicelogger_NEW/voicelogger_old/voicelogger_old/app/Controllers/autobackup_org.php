<?php
class Autobackup extends Controller {
        function __construct() {
                parent::__construct();
        }

        function index() {              
                echo "Daily BackUp Time Saved";
        }
         function editcrontab(){

             //crontab /tmp/crontab.txt
             $today = date("H:i:s");
             echo "today = $today";
                $currenttime = time();
           
             echo "current time  = $currenttime";



             $fth = $_POST['time-hh'];
             
             /*  $fth = $this->input->post('time-hh');
       $ftm = $this->input->post('time-mm');
       $fts = $this->input->post('time-ss');*/
       echo $fth;
       if(!empty($fth)) {
           $query = "update autobackup set backuptime = '$fth:$ftm:$fts'";
	  echo $query;
           $result = $this->db->query($query);
	}

        $string =  ("17 13 * * * /var/www/html/download/recordings/autobackup_script2.php > /var/www/html/download/recordings/abuphp.log".PHP_EOL);
        //$fw = fopen("/var/spool/cron/root", "w");
        $fw = fopen("/tmp/crontab.txt", "w");
        $fb = fwrite($fw,$string) or die('Could not write to file');
        fclose($fw);


       // echo exec('crontab /tmp/crontab.txt');
        // $output = shell_exec("crontab /tmp/crontab.txt");
      //  echo $output;
        /* $output = shell_exec('crontab -l');

     *
     *
     *    $fw = fopen("/tmp/crontab.txt", "w");
        while($buf = fgets($fp)){
        if(preg_match("/up/", $buf)){
        fwrite($fp, "55 15 * * * /var/www/html/download/recordings/autobackup_script2.php > /var/www/html/download/recordings/abuphp.log\n");
        
        fclose($fp);
        }
        }*/
   //echo"hi..";
    /*       $output = shell_exec('crontab -l');
            file_put_contents('/tmp/crontab.txt', $output.'55 15 * * * /var/www/html/download/recordings/autobackup_script2.php > /var/www/html/download/recordings/abuphp.log'.PHP_EOL);
            echo exec('crontab /tmp/crontab.txt');

            echo"hi..";*/


           
         /*       $filename = "";
                $down = "";
                $budown = "";
                $result = $this->db->query("SELECT callidpk,filename FROM calldetails WHERE isbackedup = 'NULL'");
             
                foreach( $result->result_array() as $row ) :              
                        $this->db->query("UPDATE calldetails
                                  SET isbackedup = 'NULL'
                                  WHERE (filename = ? )", array($row['filename']));

                       $filename = addcslashes($row[filename],' ');                       
                       $down .= "/var/www/recordings/files/".$filename." ";                      
                       $budown .= $row[callidpk].",";                      
                endforeach;
                $budown .= "0";
                 echo "$budown";
               
          $today = date("dmy_Gis"); // 03.10.01
          echo $today;
       shell_exec("rm -rf /var/www/html/download/recording/*.* 2>&1");
       shell_exec("cp $down /var/www/html/download/recording/");
       shell_exec("mysql -e 'select * from calldetails where callidpk in ($budown) ' -u root -pvicidialnow voicecatch > /var/www/html/download/recording/mydumptest$today.sql");
  // shell_exec("tar -cjf /var/www/html/download/recording/Autobackup.tar.gz /var/www/html/download/recording/*.wav");      
       shell_exec("/var/www/html/download/recordings/bu.sh > /var/www/html/download/recordings/bu.log");       
       // redirect('/calls');

          */
       // redirect('/delete');
          }



}
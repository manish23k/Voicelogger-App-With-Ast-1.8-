<?php

namespace App\Controllers;

class Disable extends BaseController
{
    function Disable()
    {
        // parent::Controller();
    }
    function index()
    {
        $db = \Config\Database::connect();

        $data = array();

        $query = "select * from logrules order by phonenumber";
        $result = $db->query($query);
        $data['result'] = $result;

        $data['main'] = "logging_view";
        return view('template', $data);
    }

    function add()
    {
        $data = array();
        if ($_POST) {
            $extension = $_POST['extension'];
            $row = array(
                'phonenumber' => "$extension",
                'numbertype' => 'E'
            );
            $builder = $this->db->table('logrules');
            $builder->insert($row);
            return redirect('disable');
        } else {
            $data['main'] = 'logrulesadd_view';
            return view('template', $data);
        }
    }

    function delete($id)
    {
        $row = array('id' => $id);
        $builder = $this->db->table('logrules');
        $builder->delete($row);
        return redirect('disable');
    }
}

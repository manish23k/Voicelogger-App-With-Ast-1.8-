<?php
$down="/var/www/recordings/files/2011/05/05/PBX-9227231501-9227231501-20110505-102950-1304571590.10.wav ";
//shell_exec("/usr/bin/sudo /bin/rm -rf /var/www/html/download/recording/*.*");
shell_exec("/usr/bin/sudo /bin/cp $down /var/www/html/download/recording/");	 
//shell_exec("cd /var/www/html/download/");
//shell_exec("/usr/bin/sudo /bin/tar -cvzf recording.tar.gz recording/");
?>
<?php

namespace App\Controllers;

class Wave extends BaseController
{
    function Wave()
    {
        //parent::Controller();
    }

    function play($yy, $mm, $dd, $fn)
    {
        $filename = $yy . "/" . $mm . "/" . $dd . "/" . $fn;
        header("Content-type: audio/wav");
        header('Content-Disposition: inline; filename="' . $filename . '"');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize(config(App::class)->recording_path . $filename));

        readfile(config(App::class)->recording_path . $filename);
        // $data = read_file(config(App::class)->recording_path . $filename);
        // //echo $filename;
        // force_download($filename, $data);
    }

    function download($yy, $mm, $dd, $fn)
    {
        $filename = $yy . "/" . $mm . "/" . $dd . "/" . $fn;

        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        //header('Content-Disposition: attachment; filename="' . $filename . '"');
	header('Content-Disposition: inline; filename="' . $filename . '"');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize(config(App::class)->recording_path . $filename));
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        readfile(config(App::class)->recording_path . $filename);
    }


    function delete($yy, $mm, $dd, $fn)
    {
        $filename = $yy . "/" . $mm . "/" . $dd . "/" . $fn;

        $query = "delete from calldetails where FileName='$filename'";
        $this->db->query($query);
        @unlink(config(App::class)->recording_path . $filename);
        //echo $filename;	
        echo "<script language='javascript' type='text/javascript'>window.close();if (window.opener && !window.opener.closed) {window.opener.location.reload();} </script>";
    }

    function multidownload()
    {
        $filename = '/var/www/html/download/recording.tar.gz';
        //$filename = $this->uri->segment(3);
        $this->load->helper('file');
        $this->load->helper('download');
        // $data = read_file($this->config->item('\var\www\html\download\recording.tar.gz');
        //echo $filename;
        force_download($filename, $data);
    }
}

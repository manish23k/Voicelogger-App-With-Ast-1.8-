#!/usr/bin/php

<?php
                set_time_limit(0);

               // date_default_timezone_set('Asia/Kolkata');
                
                //$script_tz= date_default_timezone_get();
                $now = date("H:i:s");
				//echo "now = $now";
				//date('m-d-Y',strtotime('+1 month', '1301413787')); 
				//$hoafter = time() + (7 * 24 * 60 * 60) ;
				$afterho_buff = time() + 30*60; 
				$afterho = date("H:i:s",$afterho_buff);
				//echo "hotoday = $afterho";
                $filename = "";
                $down = "";
                $budown = "";
                $con = mysql_connect("localhost","root","vicidialnow");
                    if (!$con)
                    {
                        die('Could not connect: ' . mysql_error());
                   }
                mysql_select_db("voicecatch", $con);

                //"time(starttime) >= '$parameter'";

                
				/*
				$results = mysql_query($query, $connection);
$numResults = mysql_num_rows($results);
if ($numResults > 0) {
   // there are some results, retrieve them normally (e.g. with mysql_fetch_assoc())
} else {
   // no data from query, react accordingly
}
				*/
				$result = mysql_query("SELECT * from autobackup where backuptime >= '$now' and backuptime < '$afterho' ");
				//$result = mysql_query("SELECT * from autobackup");
				$numResults = mysql_num_rows($result);
				if ($numResults > 0) {				
				
                $result = mysql_query("SELECT callidpk,filename FROM calldetails WHERE isbackedup = 'NULL'");

                while( $row = mysql_fetch_array($result) )
                {
                        mysql_query("UPDATE calldetails
                                  SET isbackedup = 'NULL'
                                  WHERE (filename = ? )", $row['filename']);
                       $filename = addcslashes($row[filename],' ');
                       $down .= "/var/www/recordings/files/".$filename." ";
                       $budown .= $row[callidpk].",";
                }
                mysql_close($con);

                $budown .= "0";
                // echo "$budown";
				 print("$budown");

                $today = date("dmy_Gis"); // 03.10.01
              //  echo $today;
                //shell_exec("rm -rf /var/www/html/download/recording/*.* 2>&1");
                shell_exec("cp $down /var/www/html/download/recording/");
                shell_exec("mysql -e 'select * from calldetails where callidpk in ($budown) ' -u root -pvicidialnow voicecatch > /var/www/html/download/recording/mydumptest$today.sql");
  // shell_exec("tar -cjf /var/www/html/download/recording/Autobackup.tar.gz /var/www/html/download/recording/*.wav");
                shell_exec("/var/www/html/download/recordings/bu.sh > /var/www/html/download/recordings/bu.log");
       // redirect('/calls');

                } else {
                //                echo 'Script timezone and ini-set doesn't timezone match.';
                 }
			
				 
?>

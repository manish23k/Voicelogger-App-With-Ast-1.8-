<?php

namespace App\Controllers;

class Shutdown extends BaseController
{
	function __construct()
	{
		//parent::__construct();
	}

	function index()
	{
		$data = array('main' => 'shutdown_view');
		return view('template', $data);
	}

	function confirm()
	{
		//$data = array('main' => 'shutdown_view2');
		//return view('template', $data);
		//$d1 = $this->input->post('datefrom');
		//$d2 = $this->input->post('dateto');

		//$query = "select count(*) as c from calldetails where ";

		//$where = "date(StartTime)>='$d1' and date(StartTime)<='$d2'";


		//$fth = $this->input->post('timefrom-hh');
		//$ftm = $this->input->post('timefrom-mm');
		//$fts = $this->input->post('timefrom-ss');

		//$tth = $this->input->post('timeto-hh');
		//$ttm = $this->input->post('timeto-mm');
		//$tts = $this->input->post('timeto-ss');

		//if(!empty($fth)) {
		//$where = $where . " and time(StartTime) >= '$fth:$ftm:$fts' and time(StartTime) <= '$tth:$ttm:$tts'";
		//}

		//$query = $query . $where;

		//$result = $this->db->query($query);
		//$row = $result->row();

		$data = array('main' => 'shutdown_view2');

		//$data['count'] =  $row->c;
		//$data['where'] = $where;
		//$data['datefrom'] = $d1;
		//$data['dateto'] = $d2;

		//$data['timefrom'] = "$fth:$ftm:$fts";
		//$data['timeto'] = "$tth:$ttm:$tts";

		return view('template', $data);
	}

	function process()
	{
		$b = $this->request->getVar('submit');
		if ($b == 'Shutdown') {
			shell_exec("sudo -u root /usr/sbin/shutdown -h now");
			echo "System Going For Shutdown........";
		}
		if ($b == 'Reboot') {
			shell_exec("sudo -u root /usr/sbin/shutdown -r now");
			echo "System Going For Reboot.......";
		}
	}
}

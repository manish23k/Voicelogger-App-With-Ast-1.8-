<?php

namespace App\Controllers;

class Delete extends BaseController
{
	function __construct()
	{
		//parent::__construct();
	}

	function index()
	{
		$data = array('main' => 'delete_1');
		return view('template', $data);
	}

	function confirm()
	{

		$d1 = $this->request->getVar('datefrom');
		$d2 = $this->request->getVar('dateto');

		$query = "select count(*) as c from calldetails where ";

		$where = "date(StartTime)>='$d1' and date(StartTime)<='$d2'";


		$fth = $this->request->getVar('timefrom-hh');
		$ftm = $this->request->getVar('timefrom-mm');
		$fts = $this->request->getVar('timefrom-ss');

		$tth = $this->request->getVar('timeto-hh');
		$ttm = $this->request->getVar('timeto-mm');
		$tts = $this->request->getVar('timeto-ss');

		if (!empty($fth)) {
			$where = $where . " and time(StartTime) >= '$fth:$ftm:$fts' and time(StartTime) <= '$tth:$ttm:$tts'";
		}

		$query = $query . $where;

		$result = $this->db->query($query);
		$row = $result->getRow();

		$data = array('main' => 'delete_2');

		$data['count'] =  $row->c;
		$data['where'] = $where;
		$data['datefrom'] = $d1;
		$data['dateto'] = $d2;

		$data['timefrom'] = "$fth:$ftm:$fts";
		$data['timeto'] = "$tth:$ttm:$tts";

		return view('template', $data);
	}

	function process()
	{
		$b = $this->request->getVar('submit');
		if ($b == 'OKAY') {
			$query = "select * from calldetails where " . $this->request->getVar('where');
			$result = $this->db->query($query);
			$location = config(App::class)->recording_path;
			foreach ($result->getResult() as $row) {

				$file = $location . "/" . $row->Filename;

				if (!file_exists($file)) {
					//	echo "file not found";
					//	exit;	
				}

				@unlink($file);
			}
			$query = "delete from calldetails where " . $this->request->getVar('where');
			$this->db->query($query);
			//exit;
		}

		return redirect('/');
	}
}

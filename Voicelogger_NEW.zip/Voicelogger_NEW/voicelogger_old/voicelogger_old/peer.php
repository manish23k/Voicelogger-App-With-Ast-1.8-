<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            font-size: 16px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e0e0e0;
        }
    </style>
     
</head>
<body>
<h1> Trunk Status</h1>

<?php
// Function to execute commands via Asterisk Manager Interface
function AMI_exec($cmd)
{
    $am_login = 'cron';
    $am_pass = '1234';

    // Connect to AMI
    $socket = fsockopen("127.0.0.1", "5038", $errno, $errstr, 10);
    if (!$socket) {
        echo "Failed $errstr ($errno)\n";
        return false;
    }

    // Login to AMI
    fputs($socket, "Action: Login\r\n");
    fputs($socket, "Username: {$am_login}\r\n");
    fputs($socket, "Secret: {$am_pass}\r\n\r\n");
    usleep(500);

    // Execute the specified command
    fputs($socket, "Action: Command\r\n");
    fputs($socket, "Command: {$cmd}\r\n\r\n");
    usleep(500);

    // Logoff from AMI
    fputs($socket, "Action: Logoff\r\n\r\n");
    usleep(500);

    // Read and return the response
    $result = '';
    $isData = false;
    $lines = [];

    echo '<pre>';
    while (!feof($socket)) {
        $line = (fgets($socket, 128));

        if ($isData && !empty($line)) {
            $lines = $lines . $line;
        }

        if (strpos($line, 'Name/username') !== false) {
            $isData = true;
        }
    }
    fclose($socket);

    $lines = preg_split("/\n/", $lines);
    //echo "<pre>".var_dump($lines)."</pre>";
    //exit;
    echo '<table style="font-size: 30px; ">'; // Increase the table text size
    echo '<tr>'; // Add table row for the heading
    echo '<th>Name/username</th>';
    echo '<th>Host</th>';
    echo '<th>Status</th>';
    echo '</tr>'; // Close the heading row
    foreach ($lines as $line) {
        $parts = preg_split("/[\s,]+/", $line, -1, PREG_SPLIT_NO_EMPTY);
        // Display only rows 1, 2, and 7
        if ($parts[0] == 'Output:') {
            //echo var_dump( $parts);
            echo "\n";
            $style = 'green';
            $status = 7;
            if (strstr($parts[1], 'server')) { // this is for host=static change value "server" to trunk usernamename
                $status = 6;
            }

            if ($parts[$status] != 'OK') {
                $style = 'red';
            }

            echo "<tr style='background-color: $style'>";
            echo "<td>" . $parts[1] . "</td>";
            echo "<td>" . $parts[2] . "</td>";
            echo "<td>" . $parts[$status] . "</td>";
            echo "</tr>";
        }
    }
    echo "</table>";
}

// Execute the SIP show peers command
$peersCommand = 'sip show peers';
AMI_exec($peersCommand);
?>
   
   </body>
</html>

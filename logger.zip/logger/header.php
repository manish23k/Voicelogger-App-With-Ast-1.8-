<!-- Navigation Header -->
<nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-hover) 100%);">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="calls.php">
            <img src="/logger/assets/img/voicecatch_vl.png" alt="Voice Catch" height="100" class="me-4">
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'calls.php' ? 'active' : ''; ?>" href="calls.php">
                        <i class="mdi mdi-phone-classic me-1"></i>Calls
                    </a>
                </li>
                <?php if (has_permission('view_reports')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>" href="reports.php">
                        <i class="mdi mdi-chart-line me-1"></i>Reports
                    </a>
                </li>
                <?php endif; ?>
                <?php if (has_permission('manage_users')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>" href="users.php">
                        <i class="mdi mdi-account-group me-1"></i>Users
                    </a>
                </li>
                <?php endif; ?>
                <?php if (has_permission('system_settings')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>" href="settings.php">
                        <i class="mdi mdi-cog me-1"></i>Settings
                    </a>
                </li>
                <?php endif; ?>
            </ul>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="mdi mdi-account-circle me-1"></i>
                        <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <span class="dropdown-item-text">
                                <small class="text-muted">Role: <?php echo htmlspecialchars($_SESSION['role_name'] ?? 'Unknown'); ?></small>
                            </span>
                        </li>
                        <!-- <li><hr class="dropdown-divider"></li> -->
                        <!-- <li>
                            <a class="dropdown-item" href="profile.php">
                                <i class="mdi mdi-account me-2"></i>Profile
                            </a>
                        </li> -->
                        <!-- <li>
                            <a class="dropdown-item" href="change_password.php">
                                <i class="mdi mdi-lock me-2"></i>Change Password
                            </a>
                        </li> -->
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item text-danger" href="logout.php">
                                <i class="mdi mdi-logout me-2"></i>Logout
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Breadcrumb -->
<div class="container mt-3">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="calls.php" class="text-decoration-none">
                    <i class="mdi mdi-home me-1"></i>Home
                </a>
            </li>
            <?php if (basename($_SERVER['PHP_SELF']) != 'calls.php'): ?>
            <li class="breadcrumb-item active" aria-current="page">
                <?php echo ucfirst(str_replace('.php', '', basename($_SERVER['PHP_SELF']))); ?>
            </li>
            <?php endif; ?>
        </ol>
    </nav>
</div> 
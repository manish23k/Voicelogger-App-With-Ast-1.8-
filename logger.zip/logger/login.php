<?php
include 'config.php';
include 'head.php'; // Include CSS and JS files

session_start(); // Ensure session is started

$login_error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Prepare SQL statement to fetch user details including role and extension group
    $stmt = $dbConnection->prepare('
        SELECT users.user_id, users.password, users.role_id, roles.role_name, users.extension_group, users.extension, users.group_id
        FROM users
        LEFT JOIN roles ON users.role_id = roles.role_id
        WHERE users.username = ? AND users.status = "active"
    ');

    if ($stmt) {
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Bind the results to variables
            $stmt->bind_result($user_id, $stored_password, $role_id, $role_name, $extension_group, $extension, $group_id);
            $stmt->fetch();

            // Verify the entered password against the hashed password in the database
            if (password_verify($password, $stored_password)) {
                // Password is correct: set up session variables and redirect to dashboard
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $username;
                $_SESSION['user_id'] = $user_id;
                $_SESSION['role_id'] = $role_id;
                $_SESSION['role_name'] = $role_name; // Store the role name

                // Store the extension group details in the session
                $_SESSION['extension_group'] = $extension_group;

                // If 'SELF', store the user's own extension
                if ($extension_group === 'SELF') {
                    $_SESSION['user_extension'] = $extension;

                // If 'GROUP', store the group ID and fetch associated extensions for the group
                } elseif ($extension_group === 'GROUP') {
                    $_SESSION['user_group_id'] = $group_id;

                    // Fetch all extensions for the group and store them in the session
                    $group_stmt = $dbConnection->prepare('
                        SELECT extension FROM groupextensions WHERE groupid = ?
                    ');
                    $group_stmt->bind_param('i', $group_id);
                    $group_stmt->execute();
                    $group_result = $group_stmt->get_result();

                    $group_extensions = [];
                    while ($row = $group_result->fetch_assoc()) {
                        $group_extensions[] = $row['extension'];
                    }
                    $_SESSION['group_extensions'] = $group_extensions; // Store group extensions in session
                    $group_stmt->close();

                } else {
                    // If 'ALL', allow access to all calls
                    $_SESSION['user_extension'] = 'ALL';
                }

                // Fetch and store permissions for this role
                $_SESSION['permissions'] = fetch_user_permissions($role_id, $dbConnection);

                // Redirect to the dashboard
                header('Location: calls.php');
                exit();
            } else {
                $login_error = 'Incorrect password!';
            }
        } else {
            $login_error = 'Incorrect username or inactive account!';
        }
        $stmt->close();
    } else {
        // Output detailed error if statement preparation fails
        $login_error = 'Database error: unable to prepare statement. ' . $dbConnection->error;
    }
    $dbConnection->close();
}
?>

<div class="authentication-wrapper">
    <div class="authentication-inner">
        <!-- Login -->
        <div class="authentication-card">
            <!-- Logo -->
            <div class="app-brand justify-content-center mt-5">
                <a href="index.php" class="app-brand-link gap-2">
                    <span class="app-brand-logo demo">
                        <img src="/logger/assets/img/voicecatch_vl.png" alt="Voice Catch Logo" style="width: 400px; height: auto;">
                    </span>
                    <span class="app-brand-text demo text-heading fw-semibold"></span>
                </a>
            </div>
            <!-- /Logo -->
            <div class="card-body mt-2">
                <div class="text-center mb-4">
                    <div class="welcome-icon mb-3">
                        <i class="mdi mdi-account-circle" style="font-size: 3rem; color: var(--primary-color);"></i>
                    </div>
                    <h4 class="mb-2 slide-up">Welcome Back! 👋</h4>
                    <p class="mb-4 text-muted">Please sign-in to your account</p>
                </div>
                <form id="formAuthentication" class="mb-3" method="post" action="">
                    <div class="form-floating form-floating-outline mb-3">
                        <input type="text" class="form-control" id="email" name="username" placeholder="Username" required autofocus />
                        <label for="email">Username</label>
                    </div>
                    <div class="mb-3">
                        <div class="form-password-toggle">
                            <div class="input-group input-group-merge">
                                <div class="form-floating form-floating-outline">
                                    <input type="password" id="password" class="form-control" name="password" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" required aria-describedby="password" />
                                    <label for="password">Password</label>
                                </div>
                                <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3 d-flex justify-content-between">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="remember-me" />
                            <label class="form-check-label" for="remember-me"> Remember Me </label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <button class="btn btn-primary d-grid w-100" type="submit">Sign in</button>
                    </div>
                    <?php
                    if (!empty($login_error)) {
                        echo '<div class="alert alert-danger mt-3">' . $login_error . '</div>';
                    }
                    ?>
                </form>
            </div>
        </div>
        <!-- /Login -->
    </div>
</div>

<?php include 'footer.php'; ?> 
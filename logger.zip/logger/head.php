<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voice Catch - Call Management System</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Material Design Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.2.96/css/materialdesignicons.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/logger/assets/css/style.css?v=<?php echo time(); ?>">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/logger/assets/img/favicon.ico">
    
    <!-- Meta tags for better SEO -->
    <meta name="description" content="Voice Catch - Advanced Call Management System">
    <meta name="keywords" content="call management, voice recording, PBX, telephony">
    <meta name="author" content="Voice Catch">
    
    <!-- Open Graph tags -->
    <meta property="og:title" content="Voice Catch - Call Management System">
    <meta property="og:description" content="Advanced call management and recording system">
    <meta property="og:type" content="website">
    
    <!-- Preload critical resources -->
    <link rel="preload" href="/logger/assets/css/style.css" as="style">
    <link rel="preload" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" as="style">
</head>
<body>
    <!-- Loading Spinner -->
    <div id="loading-spinner" class="spinner" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999;"></div>
    
    <!-- Main Content Container -->
    <div id="main-content" class="fade-in"> 
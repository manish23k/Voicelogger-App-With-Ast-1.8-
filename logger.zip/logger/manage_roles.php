<?php
include 'config.php';
include 'header.php';
include 'head.php';

// Fetch roles
$roles_result = $dbConnection->query('SELECT * FROM roles');

// Fetch all permissions dynamically from the `permissions` table
$permissions_result = $dbConnection->query('SELECT * FROM permissions');

// Initialize an array to store the current permissions of the selected role
$role_permissions = [];

// Check if a role is selected (via GET or POST), and fetch its permissions
$selected_role_id = $_POST['role_id'] ?? $_GET['role_id'] ?? null;

if ($selected_role_id) {
    // Fetch the permissions for the selected role
    $role_permissions_result = $dbConnection->query("SELECT permission_id FROM role_permissions WHERE role_id = $selected_role_id");
    while ($row = $role_permissions_result->fetch_assoc()) {
        $role_permissions[] = $row['permission_id']; // Store the permission_id for later use
    }
}

// Handle form submission to update role permissions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['role_id'])) {
    $role_id = $_POST['role_id'];
    $selected_permissions = $_POST['permissions'] ?? [];

    // First, delete existing permissions for this role
    $dbConnection->query("DELETE FROM role_permissions WHERE role_id = $role_id");

    // Insert selected permissions into the role_permissions table
    foreach ($selected_permissions as $permission_id) {
        $dbConnection->query("INSERT INTO role_permissions (role_id, permission_id) VALUES ($role_id, $permission_id)");
    }

    $success_message = "Permissions updated successfully!";
}
?>

<div class="container mt-5">
    <div class="card">
        <div class="card-header">
            <h2 class="mb-0"><i class="mdi mdi-shield-account me-2"></i>Manage Role Permissions</h2>
        </div>
        <div class="card-body">
            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success fade-in">
                    <i class="mdi mdi-check-circle me-2"></i><?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            
            <!-- Select Role Form -->
            <form method="get" action="manage_roles.php">
                <div class="row">
                    <div class="col-md-6">
                        <label for="role_id" class="form-label">
                            <i class="mdi mdi-shield me-1"></i>Select Role
                        </label>
                        <select name="role_id" class="form-control focus-ring" id="role_id" onchange="this.form.submit()" required>
                            <option value="">Select a role</option> <!-- Default option -->
                            <?php while ($role = $roles_result->fetch_assoc()): ?>
                                <option value="<?php echo $role['role_id']; ?>" 
                                    <?php echo ($selected_role_id == $role['role_id']) ? 'selected' : ''; ?>>
                                    <?php echo $role['role_name']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
            </form>

            <?php if ($selected_role_id): ?>
            <!-- Only show permissions if a role is selected -->
            <form method="post" action="manage_roles.php">
                <input type="hidden" name="role_id" value="<?php echo $selected_role_id; ?>"> <!-- Carry over the selected role -->

                <div class="mt-4">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0"><i class="mdi mdi-checkbox-multiple-marked me-2"></i>Select Permissions</h4>
                        </div>
                        <div class="card-body">
                            <!-- Select All for Menus -->
                            <div class="form-check mb-3">
                                <input type="checkbox" class="form-check-input" id="select_all_menus">
                                <label class="form-check-label" for="select_all_menus">
                                    <i class="mdi mdi-menu me-1"></i>Select All/Unselect All (Menus)
                                </label>
                            </div>

                            <!-- Menus Section -->
                            <div class="row">
                                <div class="col-md-12">
                                    <h5><i class="mdi mdi-menu me-2"></i>Menus</h5>
                                    <div class="permission-grid">
                                        <?php
                                        $menu_permissions_query = "SELECT * FROM permissions WHERE permission_type = 'menu'";
                                        $menu_permissions_result = $dbConnection->query($menu_permissions_query);
                                        
                                        while ($permission = $menu_permissions_result->fetch_assoc()) {
                                            ?>
                                            <div class="form-check form-check-inline permission-item">
                                                <input type="checkbox" class="form-check-input menu-checkbox" 
                                                       name="permissions[]" 
                                                       value="<?php echo $permission['permission_id']; ?>" 
                                                       id="permission_<?php echo $permission['permission_id']; ?>"
                                                       <?php echo in_array($permission['permission_id'], $role_permissions) ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="permission_<?php echo $permission['permission_id']; ?>">
                                                    <?php echo $permission['permission_name']; ?> - <?php echo $permission['description']; ?>
                                                </label>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Select All for Buttons -->
                            <div class="form-check mb-3 mt-4">
                                <input type="checkbox" class="form-check-input" id="select_all_buttons">
                                <label class="form-check-label" for="select_all_buttons">
                                    <i class="mdi mdi-button-cursor me-1"></i>Select All/Unselect All (Buttons)
                                </label>
                            </div>

                            <!-- Buttons Section -->
                            <div class="row">
                                <div class="col-md-12">
                                    <h5><i class="mdi mdi-button-cursor me-2"></i>Buttons</h5>
                                    <div class="permission-grid">
                                        <?php
                                        $button_permissions_query = "SELECT * FROM permissions WHERE permission_type = 'button'";
                                        $button_permissions_result = $dbConnection->query($button_permissions_query);
                                        
                                        while ($permission = $button_permissions_result->fetch_assoc()) {
                                            ?>
                                            <div class="form-check form-check-inline permission-item">
                                                <input type="checkbox" class="form-check-input button-checkbox" 
                                                       name="permissions[]" 
                                                       value="<?php echo $permission['permission_id']; ?>" 
                                                       id="permission_<?php echo $permission['permission_id']; ?>"
                                                       <?php echo in_array($permission['permission_id'], $role_permissions) ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="permission_<?php echo $permission['permission_id']; ?>">
                                                    <?php echo $permission['permission_name']; ?> - <?php echo $permission['description']; ?>
                                                </label>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary mt-3">
                    <i class="mdi mdi-content-save me-1"></i>Save Permissions
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    // Select/Unselect All for Menus
    document.getElementById('select_all_menus').addEventListener('change', function() {
        let checkboxes = document.querySelectorAll('.menu-checkbox');
        for (let checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    });

    // Select/Unselect All for Buttons
    document.getElementById('select_all_buttons').addEventListener('change', function() {
        let checkboxes = document.querySelectorAll('.button-checkbox');
        for (let checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    });
</script>

<?php include 'footer.php'; ?> 
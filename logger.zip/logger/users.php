<?php
include 'config.php';
include 'header.php';
include 'head.php';

// Handle adding or editing users
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['username'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $role_id = (int)$_POST['role'];
    $status = $_POST['status'];
    $extension_group = $_POST['extension_group'];
    $extension = ($_POST['extension_group'] == 'SELF') ? trim($_POST['extension']) : null;
    $group_id = ($_POST['extension_group'] == 'GROUP') ? (int)$_POST['group_id'] : null;

    $user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;

    if ($user_id == 0) {
        // Add new user
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $stmt = $dbConnection->prepare("INSERT INTO users (username, email, password, role_id, status, extension_group, extension, group_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('sssisssi', $username, $email, $password, $role_id, $status, $extension_group, $extension, $group_id);
    } else {
        // Edit existing user
        if (!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
            $stmt = $dbConnection->prepare("UPDATE users SET username=?, email=?, password=?, role_id=?, status=?, extension_group=?, extension=?, group_id=? WHERE user_id=?");
            $stmt->bind_param('sssisssii', $username, $email, $password, $role_id, $status, $extension_group, $extension, $group_id, $user_id);
        } else {
            $stmt = $dbConnection->prepare("UPDATE users SET username=?, email=?, role_id=?, status=?, extension_group=?, extension=?, group_id=? WHERE user_id=?");
            $stmt->bind_param('ssisssii', $username, $email, $role_id, $status, $extension_group, $extension, $group_id, $user_id);
        }
    }

    if ($stmt->execute()) {
        echo "User saved successfully!";
    } else {
        echo "Error saving user: " . $stmt->error;
    }
}

// Handle deleting a user
if (isset($_GET['delete'])) {
    $user_id = (int)$_GET['delete'];
    $stmt = $dbConnection->prepare("DELETE FROM users WHERE user_id = ?");
    $stmt->bind_param('i', $user_id);
    if ($stmt->execute()) {
        echo "User deleted successfully!";
    } else {
        echo "Error deleting user: " . $dbConnection->error;
    }
    $stmt->close();
}

// Handle adding, editing, and deleting roles
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['role_name'])) {
    $role_name = trim($_POST['role_name']);
    $role_id = isset($_POST['role_id']) ? (int)$_POST['role_id'] : 0;
    $action = $_POST['action'];

    if ($action == 'add') {
        // Add new role
        if (!empty($role_name)) {
            $stmt = $dbConnection->prepare("INSERT INTO roles (role_name) VALUES (?)");
            $stmt->bind_param('s', $role_name);
            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>Role added successfully!</div>";
            } else {
                echo "<div class='alert alert-danger'>Error adding role: " . $stmt->error . "</div>";
            }
            $stmt->close();
        }
    } elseif ($action == 'edit' && $role_id > 0) {
        // Edit existing role
        if (!empty($role_name)) {
            $stmt = $dbConnection->prepare("UPDATE roles SET role_name=? WHERE role_id=?");
            $stmt->bind_param('si', $role_name, $role_id);
            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>Role updated successfully!</div>";
            } else {
                echo "<div class='alert alert-danger'>Error updating role: " . $stmt->error . "</div>";
            }
            $stmt->close();
        }
    }
}


// Handle deleting a role
if (isset($_GET['delete_role'])) {
    $role_id = (int)$_GET['delete_role'];
    $stmt = $dbConnection->prepare("DELETE FROM roles WHERE role_id = ?");
    $stmt->bind_param('i', $role_id);
    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Role deleted successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error deleting role: " . $dbConnection->error . "</div>";
    }
    $stmt->close();
}

// Fetch roles
$roles = [];
$roles_result = $dbConnection->query("SELECT * FROM roles");
if ($roles_result->num_rows > 0) {
    while ($row = $roles_result->fetch_assoc()) {
        $roles[] = $row;
    }
}

// Fetch users
$users_result = $dbConnection->query("
    SELECT users.*, roles.role_name, 
           CASE 
               WHEN users.extension_group = 'GROUP' THEN users.group_id
               WHEN users.extension_group = 'SELF' THEN users.extension
               ELSE NULL 
           END AS extension_or_group_id 
    FROM users 
    LEFT JOIN roles 
    ON users.role_id = roles.role_id
");

// Fetch all permissions dynamically
$permissions_result = $dbConnection->query('SELECT * FROM permissions');

// Initialize permissions of the selected role
$role_permissions = [];
$selected_role_id = $_POST['role_id'] ?? $_GET['role_id'] ?? null;

if ($selected_role_id) {
    $role_permissions_result = $dbConnection->query("SELECT permission_id FROM role_permissions WHERE role_id = $selected_role_id");
    if ($role_permissions_result) {
        while ($row = $role_permissions_result->fetch_assoc()) {
            $role_permissions[] = $row['permission_id'];
        }
    }
}


// Handle permissions form submission separately
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['permissions'])) {
    $role_id = $_POST['role_id'];
    $selected_permissions = $_POST['permissions'] ?? [];

    // Delete existing permissions for the role
    $dbConnection->query("DELETE FROM role_permissions WHERE role_id = $role_id");

    // Insert new permissions
    foreach ($selected_permissions as $permission_id) {
        $dbConnection->query("INSERT INTO role_permissions (role_id, permission_id) VALUES ($role_id, $permission_id)");
    }

    // Fetch updated permissions and return them as JSON
    $updated_permissions = [];
    $role_permissions_result = $dbConnection->query("SELECT permission_id FROM role_permissions WHERE role_id = $role_id");
    while ($row = $role_permissions_result->fetch_assoc()) {
        $updated_permissions[] = $row['permission_id'];
    }

    // Return the updated permissions in JSON format
    //echo json_encode(['success' => true, 'updated_permissions' => $updated_permissions]);
   // exit;
}

?>

<div class="container mt-5">
    <div class="card">
        <div class="card-header">
            <h2 class="mb-0"><i class="mdi mdi-account-group me-2"></i>User Management</h2>
        </div>
        <div class="card-body">
            <!-- Tabs for Users and Roles -->
            <ul class="nav nav-pills mb-4" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link <?php echo (!isset($_GET['active_tab']) || $_GET['active_tab'] == 'users') ? 'active' : ''; ?>" id="users-tab" data-bs-toggle="tab" href="#users" role="tab" aria-controls="users" aria-selected="<?php echo (!isset($_GET['active_tab']) || $_GET['active_tab'] == 'users') ? 'true' : 'false'; ?>">
                        <i class="mdi mdi-account me-1"></i>Users
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (isset($_GET['active_tab']) && $_GET['active_tab'] == 'roles') ? 'active' : ''; ?>" id="roles-tab" data-bs-toggle="tab" href="#roles" role="tab" aria-controls="roles" aria-selected="<?php echo (isset($_GET['active_tab']) && $_GET['active_tab'] == 'roles') ? 'true' : 'false'; ?>">
                        <i class="mdi mdi-shield-account me-1"></i>User Roles
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (isset($_GET['active_tab']) && $_GET['active_tab'] == 'permissions') ? 'active' : ''; ?>" id="permissions-tab" data-bs-toggle="tab" href="#permissions" role="tab" aria-controls="permissions" aria-selected="<?php echo (isset($_GET['active_tab']) && $_GET['active_tab'] == 'permissions') ? 'true' : 'false'; ?>">
                        <i class="mdi mdi-key me-1"></i>Manage Permissions
                    </a>
                </li>
            </ul>

    <div class="tab-content" id="myTabContent">
        <!-- Users Tab -->
        <div class="tab-pane fade <?php echo (!isset($_GET['active_tab']) || $_GET['active_tab'] == 'users') ? 'show active' : ''; ?>" id="users" role="tabpanel" aria-labelledby="users-tab">
            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0"><i class="mdi mdi-account me-2"></i>Manage Users</h3>
                </div>
                <div class="card-body">
                    <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#userModal">
                        <i class="mdi mdi-plus me-1"></i>Add User
                    </button>
                    <!-- Users Table -->
                    <div class="table-responsive">
                        <table class="table table-hover table-striped">
                            <thead class="table-dark">
                                <tr>
                                    <th><i class="mdi mdi-account me-1"></i>Username</th>
                                    <th><i class="mdi mdi-email me-1"></i>Email</th>
                                    <th><i class="mdi mdi-shield me-1"></i>Role</th>
                                    <th><i class="mdi mdi-check-circle me-1"></i>Status</th>
                                    <th><i class="mdi mdi-phone me-1"></i>Extension Group</th>
                                    <th><i class="mdi mdi-cog me-1"></i>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $users_result->fetch_assoc()) { ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><?php echo htmlspecialchars($row['role_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                                        <td><?php echo htmlspecialchars($row['extension_group']); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button class="btn btn-sm btn-warning" title="Edit User"
                                                    onclick="editUser(
                                                <?php echo $row['user_id']; ?>, 
                                                '<?php echo htmlspecialchars($row['username']); ?>', 
                                                '<?php echo htmlspecialchars($row['email']); ?>', 
                                                <?php echo $row['role_id']; ?>, 
                                                '<?php echo htmlspecialchars($row['status']); ?>', 
                                                '<?php echo htmlspecialchars($row['extension_group']); ?>', 
                                                '<?php echo htmlspecialchars($row['extension_or_group_id']); ?>'
                                            )">
                                                    <i class="mdi mdi-pencil me-1"></i>Edit
                                                </button>
                                                <a href="users.php?delete=<?php echo $row['user_id']; ?>&active_tab=users"
                                                    class="btn btn-sm btn-danger" title="Delete User"
                                                    onclick="return confirm('Are you sure you want to delete this user?');">
                                                    <i class="mdi mdi-delete me-1"></i>Delete
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Roles Tab (User Group Management) -->
        <div class="tab-pane fade <?php echo (isset($_GET['active_tab']) && $_GET['active_tab'] == 'roles') ? 'show active' : ''; ?>" id="roles" role="tabpanel" aria-labelledby="roles-tab">
            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0"><i class="mdi mdi-shield-account me-2"></i>Manage User Roles</h3>
                </div>
                <div class="card-body">
                    <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#roleModal">
                        <i class="mdi mdi-plus me-1"></i>Add Role
                    </button>

                    <!-- Roles Table -->
                    <div class="table-responsive">
                        <table class="table table-hover table-striped">
                            <thead class="table-dark">
                                <tr>
                                    <th><i class="mdi mdi-shield me-1"></i>User Role</th>
                                    <th><i class="mdi mdi-cog me-1"></i>Actions</th>
                                </tr>
                            </thead>
                <tbody>
                    <?php if (count($roles) > 0): ?>
                        <?php foreach ($roles as $role): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($role['role_name']); ?></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-warning" title="Edit Role" onclick="editRole(<?php echo $role['role_id']; ?>, '<?php echo htmlspecialchars($role['role_name']); ?>')">
                                            <i class="mdi mdi-pencil me-1"></i>Edit
                                        </button>
                                        <a href="users.php?delete_role=<?php echo $role['role_id']; ?>&active_tab=roles" class="btn btn-sm btn-danger" title="Delete Role" onclick="return confirm('Are you sure you want to delete this role?');">
                                            <i class="mdi mdi-delete me-1"></i>Delete
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2" class="text-center text-muted">
                                <i class="mdi mdi-information-outline me-2"></i>No roles found
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
                </div>
            </div>
        </div>

        <!-- Permissions Tab -->
        <div class="tab-pane fade <?php echo (isset($_GET['active_tab']) && $_GET['active_tab'] == 'permissions') ? 'show active' : ''; ?>" id="permissions" role="tabpanel" aria-labelledby="permissions-tab">
            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0"><i class="mdi mdi-key me-2"></i>Manage Role Permissions</h3>
                </div>
                <div class="card-body">
                    <form method="get" action="users.php">
                        <input type="hidden" name="active_tab" value="permissions"> <!-- Keeps the active tab after form submit -->
                        <div class="row">
                            <div class="col-md-6">
                                <label for="role_id" class="form-label">
                                    <i class="mdi mdi-shield me-1"></i>Select Role
                                </label>
                                <select name="role_id" class="form-control focus-ring" id="role_id" onchange="submitRoleForm()" onclick="console.log('Dropdown clicked')" required>
                                    <option value="">Select a role</option>
                                    <?php foreach ($roles as $role): ?>
                                        <option value="<?php echo htmlspecialchars($role['role_id']); ?>"
                                            <?php echo ($selected_role_id == $role['role_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($role['role_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                            </div>
                        </div>
                    </form>

    <?php if ($selected_role_id): ?>
        <form method="post" action="users.php?active_tab=permissions" id="permissions_form">
        <input type="hidden" name="role_id" value="<?php echo $selected_role_id; ?>"> <!-- Retain selected role -->
        <div class="mt-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0"><i class="mdi mdi-checkbox-multiple-marked me-2"></i>Select Permissions</h4>
                </div>
                <div class="card-body">
                    <div class="form-check mb-3">
                        <input type="checkbox" class="form-check-input" id="select_all_menus">
                        <label class="form-check-label" for="select_all_menus">
                            <i class="mdi mdi-menu me-1"></i>Select All/Unselect All (Menus)
                        </label>
                    </div>

                    <!-- Menus Section -->
                    <div class="row">
                        <div class="col-md-12">
                            <h5><i class="mdi mdi-menu me-2"></i>Menus</h5>
                            <div class="permission-grid">
                                <?php
                                $menu_permissions_query = "SELECT * FROM permissions WHERE permission_type = 'menu'";
                                $menu_permissions_result = $dbConnection->query($menu_permissions_query);
                                $menu_count = 0;

                                while ($permission = $menu_permissions_result->fetch_assoc()) {
                                    $menu_count++;
                                ?>
                                    <div class="form-check form-check-inline permission-item">
                                        <input type="checkbox" class="form-check-input menu-checkbox"
                                            name="permissions[]"
                                            value="<?php echo $permission['permission_id']; ?>"
                                            id="permission_<?php echo $permission['permission_id']; ?>"
                                            <?php echo in_array($permission['permission_id'], $role_permissions) ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="permission_<?php echo $permission['permission_id']; ?>">
                                            <?php echo $permission['permission_name']; ?> - <?php echo $permission['description']; ?>
                                        </label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>

                    <!-- Select All for Buttons -->
                    <div class="form-check mb-3 mt-4">
                        <input type="checkbox" class="form-check-input" id="select_all_buttons">
                        <label class="form-check-label" for="select_all_buttons">
                            <i class="mdi mdi-button-cursor me-1"></i>Select All/Unselect All (Buttons)
                        </label>
                    </div>

                    <!-- Buttons Section -->
                    <div class="row">
                        <div class="col-md-12">
                            <h5><i class="mdi mdi-button-cursor me-2"></i>Buttons</h5>
                            <div class="permission-grid">
                                <?php
                                $button_permissions_query = "SELECT * FROM permissions WHERE permission_type = 'button'";
                                $button_permissions_result = $dbConnection->query($button_permissions_query);

                                while ($permission = $button_permissions_result->fetch_assoc()) {
                                ?>
                                    <div class="form-check form-check-inline permission-item">
                                        <input type="checkbox" class="form-check-input button-checkbox"
                                            name="permissions[]"
                                            value="<?php echo $permission['permission_id']; ?>"
                                            id="permission_<?php echo $permission['permission_id']; ?>"
                                            <?php echo in_array($permission['permission_id'], $role_permissions) ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="permission_<?php echo $permission['permission_id']; ?>">
                                            <?php echo $permission['permission_name']; ?> - <?php echo $permission['description']; ?>
                                        </label>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary mt-3">
            <i class="mdi mdi-content-save me-1"></i>Save Permissions
        </button>
    </form>
    <?php else: ?>
        <!-- Show this when no role is selected -->
        <div class="alert alert-info mt-3">
            <i class="mdi mdi-information-outline me-2"></i>
            <strong>No Role Selected</strong><br>
            Please select a role from the dropdown above to manage its permissions.
    <?php endif; ?>
        </div>
        </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modals for Adding/Editing -->
<div class="modal fade" id="userModal" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="userForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="userModalLabel">
                        <i class="mdi mdi-account-plus me-2"></i>Add/Edit User
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="user_id" name="user_id">
                    <div class="mb-3">
                        <label for="username" class="form-label">
                            <i class="mdi mdi-account me-1"></i>Username
                        </label>
                        <input type="text" class="form-control focus-ring" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">
                            <i class="mdi mdi-email me-1"></i>Email
                        </label>
                        <input type="email" class="form-control focus-ring" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">
                            <i class="mdi mdi-lock me-1"></i>Password
                        </label>
                        <input type="password" class="form-control focus-ring" id="password" name="password">
                        <small class="form-text text-muted">
                            <i class="mdi mdi-information-outline me-1"></i>Leave blank to keep the current password when editing.
                        </small>
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">
                            <i class="mdi mdi-shield me-1"></i>Role
                        </label>
                        <select class="form-control focus-ring" id="role" name="role" required>
                            <?php foreach ($roles as $role_row): ?>
                                <option value="<?php echo $role_row['role_id']; ?>"><?php echo htmlspecialchars($role_row['role_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="extension_group" class="form-label">
                            <i class="mdi mdi-phone me-1"></i>Extension Group
                        </label>
                        <select class="form-control focus-ring" id="extension_group" name="extension_group" onchange="toggleExtensionInput()" required>
                            <option value="ALL">All Extensions</option>
                            <option value="GROUP">Specific Group</option>
                            <option value="SELF">Self</option>
                        </select>
                    </div>
                    <div class="mb-3" id="group_select" style="display: none;">
                        <label for="group_id" class="form-label">
                            <i class="mdi mdi-account-group me-1"></i>Select Group
                        </label>
                        <select class="form-control focus-ring" id="group_id" name="group_id">
                            <?php
                            $group_result = $dbConnection->query("SELECT id, groupname FROM groups");
                            while ($group_row = $group_result->fetch_assoc()) { ?>
                                <option value="<?php echo $group_row['id']; ?>"><?php echo htmlspecialchars($group_row['groupname']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="mb-3" id="extension_input" style="display: none;">
                        <label for="extension" class="form-label">
                            <i class="mdi mdi-phone me-1"></i>Extension Number
                        </label>
                        <input type="text" class="form-control focus-ring" id="extension" name="extension" placeholder="Enter extension number if Self is selected">
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">
                            <i class="mdi mdi-check-circle me-1"></i>Status
                        </label>
                        <select class="form-control focus-ring" id="status" name="status" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="mdi mdi-close me-1"></i>Close
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="mdi mdi-content-save me-1"></i>Save User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal for Adding/Editing Role -->
<div class="modal fade" id="roleModal" tabindex="-1" aria-labelledby="roleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="users.php?active_tab=roles">
                <input type="hidden" name="role_id" id="role_hidden"> <!-- Hidden field for role ID -->
                <input type="hidden" name="action" id="role_action" value="add"> <!-- Default to add -->
                <div class="modal-header">
                    <h5 class="modal-title" id="roleModalLabel">
                        <i class="mdi mdi-shield-plus me-2"></i>Add/Edit Role
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="role_name" class="form-label">
                            <i class="mdi mdi-shield me-1"></i>Role Name
                        </label>
                        <input type="text" class="form-control focus-ring" id="role_name" name="role_name" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="mdi mdi-close me-1"></i>Close
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="mdi mdi-content-save me-1"></i>Save Role
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<script>
    function toggleExtensionInput() {
        var extensionGroup = document.getElementById('extension_group').value;
        var groupSelect = document.getElementById('group_select');
        var extensionInput = document.getElementById('extension_input');

        if (extensionGroup === 'GROUP') {
            groupSelect.style.display = 'block';
            extensionInput.style.display = 'none';
        } else if (extensionGroup === 'SELF') {
            groupSelect.style.display = 'none';
            extensionInput.style.display = 'block';
        } else {
            groupSelect.style.display = 'none';
            extensionInput.style.display = 'none';
        }
    }

    // Open modal and pre-fill form when editing a role
    function editRole(role_id, role_name) {
        document.getElementById('role_hidden').value = role_id; // Set role ID in the hidden field
        document.getElementById('role_name').value = role_name; // Set role name
        document.getElementById('role_action').value = 'edit'; // Set the form action to edit
        var roleModal = new bootstrap.Modal(document.getElementById('roleModal'));
        roleModal.show();
    }

    // Clear the form when adding a new role
    document.addEventListener('DOMContentLoaded', function() {
        var modalButton = document.querySelector('.btn-primary[data-bs-target="#roleModal"]');
        if (modalButton) {
            modalButton.addEventListener('click', function() {
                document.getElementById('role_hidden').value = ''; // Clear role ID
                document.getElementById('role_name').value = ''; // Clear role name
                document.getElementById('role_action').value = 'add'; // Set form action to add
            });
        }
    });


    // Open modal and pre-fill form when editing a user
    function editUser(user_id, username, email, role_id, status, extension_group, extension_or_group_id) {
        document.getElementById('user_id').value = user_id;
        document.getElementById('username').value = username;
        document.getElementById('email').value = email;
        document.getElementById('role').value = role_id;
        document.getElementById('status').value = status;
        document.getElementById('extension_group').value = extension_group;

        toggleExtensionInput();

        if (extension_group === 'SELF') {
            document.getElementById('extension').value = extension_or_group_id || '';
        } else if (extension_group === 'GROUP') {
            document.getElementById('group_id').value = extension_or_group_id || '';
        } else {
            document.getElementById('extension').value = '';
            document.getElementById('group_id').value = '';
        }

        var userModal = new bootstrap.Modal(document.getElementById('userModal'));
        userModal.show();
    }

    //Permission
// Handle form submission for permissions
document.addEventListener('DOMContentLoaded', function() {
    const permissionsForm = document.querySelector('#permissions_form');
    if (permissionsForm) {
        permissionsForm.addEventListener('submit', function (event) {
            event.preventDefault(); // Prevent default form submission

            let formData = new FormData(this); // Prepare form data for AJAX submission

            // Send the form data to the server using fetch
            fetch('users.php?active_tab=permissions', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())  // Parse the JSON response
            .then(data => {
                if (data.success) {
                    // Success message
                    alert('Permissions updated successfully!');

                    // Uncheck all permissions first to reset the view
                    document.querySelectorAll('input[name="permissions[]"]').forEach(checkbox => {
                        checkbox.checked = false;
                    });

                    // Check the updated permissions from the server response
                    data.updated_permissions.forEach(permission_id => {
                        let checkbox = document.getElementById(`permission_${permission_id}`);
                        if (checkbox) {
                            checkbox.checked = true;
                        }
                    });
                } else {
                    alert('Failed to update permissions');
                }
            })
            .catch(error => {
                console.error('Error updating permissions:', error);
                alert('An error occurred while updating permissions.');
            });
        });
    }
});




    // Select All for Menus
    document.getElementById('select_all_menus').addEventListener('change', function() {
        let checkboxes = document.querySelectorAll('.menu-checkbox');
        for (let checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    });

    // Select All for Buttons
    document.getElementById('select_all_buttons').addEventListener('change', function() {
        let checkboxes = document.querySelectorAll('.button-checkbox');
        for (let checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    });

    // Function to submit the role selection form
    function submitRoleForm() {
        console.log('submitRoleForm called');
        const roleSelect = document.getElementById('role_id');
        console.log('Role select element:', roleSelect);
        
        if (roleSelect) {
            console.log('Current role value:', roleSelect.value);
            if (roleSelect.value) {
                console.log('Submitting role form with role_id:', roleSelect.value);
                roleSelect.form.submit();
            } else {
                console.log('No role selected');
                alert('Please select a role first');
            }
        } else {
            console.log('Role select element not found');
        }
    }

    // Add event listener for role selection dropdown
    document.addEventListener('DOMContentLoaded', function() {
        const roleSelect = document.getElementById('role_id');
        if (roleSelect) {
            roleSelect.addEventListener('change', function() {
                console.log('Role selected:', this.value);
                if (this.value) {
                    submitRoleForm();
                }
            });
        }
    });



    // Function to initialize select all functionality
    function initializeSelectAll() {
        // Select All for Menus
        const selectAllMenus = document.getElementById('select_all_menus');
        const menuCheckboxes = document.querySelectorAll('.menu-checkbox');
        
        if (selectAllMenus) {
            selectAllMenus.addEventListener('change', function() {
                menuCheckboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
            });
        }
        
        // Select All for Buttons
        const selectAllButtons = document.getElementById('select_all_buttons');
        const buttonCheckboxes = document.querySelectorAll('.button-checkbox');
        
        if (selectAllButtons) {
            selectAllButtons.addEventListener('change', function() {
                buttonCheckboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
            });
        }
    }

    // Function to set the correct active tab based on the URL parameter
    function setActiveTab() {
        const urlParams = new URLSearchParams(window.location.search);
        const activeTab = urlParams.get('active_tab');

        // Remove active class from all tabs and panes
        document.querySelectorAll('.nav-link').forEach(tab => tab.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.remove('show', 'active');
        });

        // Set default tab if none specified
        const defaultTab = activeTab || 'users';
        
        // Add active class to the correct tab and pane
        const targetTab = document.getElementById(defaultTab + '-tab');
        const targetPane = document.getElementById(defaultTab);
        
        if (targetTab) targetTab.classList.add('active');
        if (targetPane) {
            targetPane.classList.add('show', 'active');
        }
    }

    // Call the function on page load
    document.addEventListener('DOMContentLoaded', function() {
        setActiveTab();
        
        // Initialize select all functionality for permissions tab
        const urlParams = new URLSearchParams(window.location.search);
        const activeTab = urlParams.get('active_tab');
        
        if (activeTab === 'permissions') {
            initializeSelectAll();
        }
        
        // Handle tab clicks with Bootstrap's built-in functionality
        document.querySelectorAll('.nav-link[data-bs-toggle="tab"]').forEach(tab => {
            tab.addEventListener('click', function(e) {
                // Let Bootstrap handle the tab switching
                console.log('Tab clicked:', this.id);
                
                // Force hide permissions content when switching to other tabs
                const targetId = this.getAttribute('href').substring(1);
                if (targetId !== 'permissions') {
                    const permissionsPane = document.getElementById('permissions');
                    if (permissionsPane) {
                        permissionsPane.style.display = 'none';
                        permissionsPane.style.opacity = '0';
                        permissionsPane.style.visibility = 'hidden';
                        permissionsPane.style.position = 'absolute';
                        permissionsPane.style.left = '-9999px';
                        permissionsPane.style.height = '0';
                        permissionsPane.style.width = '0';
                        permissionsPane.style.overflow = 'hidden';
                        permissionsPane.style.pointerEvents = 'none';
                    }
                }
            });
        });
    });
</script>

<?php include 'footer.php'; ?> 
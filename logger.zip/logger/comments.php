<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

include 'config.php';

// Set content type to JSON
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get form data
$call_id = $_POST['call_id'] ?? '';
$tag = $_POST['tag'] ?? '';
$comment = $_POST['comment'] ?? '';

if (empty($call_id)) {
    echo json_encode(['success' => false, 'message' => 'Call ID is required']);
    exit();
}

try {
    // Check if a record already exists for this call
    $check_query = "SELECT * FROM call_tags WHERE call_id = ?";
    $check_stmt = $dbConnection->prepare($check_query);
    $check_stmt->bind_param("s", $call_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Update existing record
        $update_query = "UPDATE call_tags SET tag = ?, comment = ? WHERE call_id = ?";
        $update_stmt = $dbConnection->prepare($update_query);
        $update_stmt->bind_param("sss", $tag, $comment, $call_id);
        
        if ($update_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Tag and comment updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update tag and comment']);
        }
    } else {
        // Insert new record
        $insert_query = "INSERT INTO call_tags (call_id, tag, comment) VALUES (?, ?, ?)";
        $insert_stmt = $dbConnection->prepare($insert_query);
        $insert_stmt->bind_param("sss", $call_id, $tag, $comment);
        
        if ($insert_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Tag and comment saved successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to save tag and comment']);
        }
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?> 
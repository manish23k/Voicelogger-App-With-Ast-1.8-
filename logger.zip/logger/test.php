<?php
include 'head.php';
?>
<div class="container mt-5">
    <div class="card">
        <div class="card-header">
            <h2>CSS Test Page</h2>
        </div>
        <div class="card-body">
            <p>If you can see this styled with a modern design, the CSS is working!</p>
            <button class="btn btn-primary">Test Button</button>
            <button class="btn btn-secondary">Secondary Button</button>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?> 
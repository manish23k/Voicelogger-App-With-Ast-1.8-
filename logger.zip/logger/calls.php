<?php
// Start session if not already started
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}
include 'config.php'; // Include your database configuration

// Turn off error reporting during CSV export to prevent output
if (!isset($_POST['export_csv'])) {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(E_ALL);
} else {
    error_reporting(0); // Disable output when exporting CSV
}

// Initialize variables
$call_type = $start_date = $end_date = $start_time = $end_time = $client_id = $client_name = $comments = $extensions = $phone = $call_tag = '';
// $pbx_ext = ''; // Commented out as not currently used
$filter_query = '';
$manage_call_error = '';
$manage_call_success = '';
$limit = 10; // Number of records per page
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1; // Current page number
$offset = ($page - 1) * $limit; // Calculate the offset for SQL query

// Fetch user extension group from session
$extension_group = $_SESSION['extension_group'] ?? 'ALL';
$user_extensions = []; // To store extensions based on the group

// Check user's extension group and modify the query accordingly
if ($extension_group === 'SELF') {
    // If 'SELF', the user can only view calls of their own extension
    $user_extension = $_SESSION['user_extension'] ?? ''; 
    $filter_query .= " AND calldetails.Extension = '$user_extension'";
} elseif ($extension_group === 'GROUP') {
    // If 'GROUP', the user can view calls of extensions in the group
    $group_extensions = $_SESSION['group_extensions'] ?? [];
    if (!empty($group_extensions)) {
        $extensions_list = implode("','", $group_extensions); // Sanitize for SQL
        $filter_query .= " AND calldetails.Extension IN ('$extensions_list')";
    } else {
        // If no group extensions are found, return no results
        $filter_query .= " AND 1=0"; // Return no results
    }
} elseif ($extension_group === 'ALL') {
    // If 'ALL', no need to filter by extension
    $filter_query .= ""; // No additional filter for extensions
}

// Handle form submissions for filtering
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Initialize variables
    $call_type = isset($_POST['call_type']) ? trim($_POST['call_type']) : '';
    $start_date = isset($_POST['start_date']) ? trim($_POST['start_date']) : '';
    $end_date = isset($_POST['end_date']) ? trim($_POST['end_date']) : '';
    $start_time = isset($_POST['start_time']) ? trim($_POST['start_time']) : '';
    $end_time = isset($_POST['end_time']) ? trim($_POST['end_time']) : '';
    // $client_id = isset($_POST['client_id']) ? trim($_POST['client_id']) : '';
    // $client_name = isset($_POST['client_name']) ? trim($_POST['client_name']) : '';
    $comments = isset($_POST['comments']) ? trim($_POST['comments']) : '';
    $extensions = isset($_POST['extensions']) ? trim($_POST['extensions']) : '';
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    // $pbx_ext = isset($_POST['pbx_ext']) ? trim($_POST['pbx_ext']) : ''; // Commented out as not currently used
    $call_tag = isset($_POST['call_tag']) ? trim($_POST['call_tag']) : '';

    // Build filter query
    if (!empty($call_type)) {
        $filter_query .= " AND calldetails.Type = '$call_type'";
    }
    if (!empty($start_date) && !empty($end_date)) {
        $filter_query .= " AND calldetails.Date BETWEEN '$start_date' AND '$end_date'";
    }
    if (!empty($start_time) && !empty($end_time)) {
        $filter_query .= " AND calldetails.StartTime BETWEEN '$start_time' AND '$end_time'";
    }
    // if (!empty($client_id)) {
    //     $filter_query .= " AND contacts.CustId = '$client_id'";
    // }
    // if (!empty($client_name)) {
    //     $filter_query .= " AND contacts.CustName = '$client_name'";
    // }
    if (!empty($comments)) {
        $filter_query .= " AND call_tags.comment LIKE '%$comments%'";
    }
    if (!empty($extensions)) {
        $filter_query .= " AND calldetails.Extension LIKE '%$extensions%'";
    }
    if (!empty($phone)) {
        $filter_query .= " AND calldetails.PhoneNumber LIKE '%$phone%'";
    }
    // if (!empty($pbx_ext)) {
    //     $filter_query .= " AND calldetails.pbxextn LIKE '%$pbx_ext%'";
    // }
    if (!empty($call_tag)) {
        $filter_query .= " AND call_tags.tag LIKE '%$call_tag%'";
    }
}

// Build the total count query with all filters
$total_count_query = "
SELECT COUNT(*) as total
FROM calldetails
-- LEFT JOIN contacts ON (
--     SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.PhoneNumber, -10)
--     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.MobileNumber, -10)
--     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternatePhoneNumber, -10)
--     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternateMobileNumber, -10)
-- )
" . (!empty($call_tag) || !empty($comments) ? " LEFT JOIN call_tags ON calldetails.callidpk = call_tags.call_id" : "") . "
WHERE 1=1 $filter_query";

$total_count_result = $dbConnection->query($total_count_query);

// Check if the query executed successfully
if (!$total_count_result) {
    die('SQL Error (total count): ' . $dbConnection->error . " | Query: " . $total_count_query);
}

$total_count_row = $total_count_result->fetch_assoc();
$total_count = $total_count_row['total'];


// Fetch call details with pagination
$query = "
    SELECT calldetails.*, 
           DATE(calldetails.StartTime) AS Date, 
           TIME(calldetails.StartTime) AS Time,
           -- CASE 
           --     WHEN LENGTH(calldetails.PhoneNumber) >= 10 
           --     AND (
           --         SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.PhoneNumber, -10)
           --         OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.MobileNumber, -10)
           --         OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternatePhoneNumber, -10)
           --         OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternateMobileNumber, -10)
           --     )
           --     THEN contacts.CustName
           --     ELSE ''  -- Empty if no match or not a valid phone number
           -- END AS ClientName,
           -- contacts.CustId AS ClientID,
           call_tags.tag AS CallTag,
           call_tags.comment AS CallComment
    FROM calldetails
    -- LEFT JOIN contacts
    -- ON LENGTH(calldetails.PhoneNumber) >= 10
    -- AND (
    --     SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.PhoneNumber, -10)
    --     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.MobileNumber, -10)
    --     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternatePhoneNumber, -10)
    --     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternateMobileNumber, -10)
    -- )
    LEFT JOIN call_tags
    ON calldetails.callidpk = call_tags.call_id
    WHERE 1=1 $filter_query
    ORDER BY calldetails.StartTime DESC 
    LIMIT $limit OFFSET $offset
";

// Check if the query executed successfully
$result = $dbConnection->query($query);
if (!$result) {
    // If the query failed, print the error
    die('SQL Error (fetch call details): ' . $dbConnection->error . " | Query: " . $query);
}


// Fetch call summary counts
$summary_query = "
SELECT 
    SUM(CASE WHEN calldetails.Type = 'Incoming' THEN 1 ELSE 0 END) AS Incoming,
    SUM(CASE WHEN calldetails.Type = 'Outgoing' THEN 1 ELSE 0 END) AS Outgoing,
    SUM(CASE WHEN calldetails.Type = 'Missed' THEN 1 ELSE 0 END) AS Missed,
    SUM(CASE WHEN calldetails.Type = 'NoAnswer' THEN 1 ELSE 0 END) AS NoAnswer,
    COUNT(*) AS TotalCalls
FROM calldetails
-- LEFT JOIN contacts ON (
--     SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.PhoneNumber, -10)
--     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.MobileNumber, -10)
--     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternatePhoneNumber, -10)
--     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternateMobileNumber, -10)
-- )
" . (!empty($call_tag) || !empty($comments) ? " LEFT JOIN call_tags ON calldetails.callidpk = call_tags.call_id" : "") . "
WHERE 1=1 $filter_query";

// Execute the query
$summary_result = $dbConnection->query($summary_query);

if (!$summary_result) {
    die('SQL Error (call summary): ' . $dbConnection->error . " | Query: " . $summary_query);
}

$counts = $summary_result->fetch_assoc();


// CSV Export
if (isset($_POST['export_csv']) && $_POST['export_csv'] == 1) {

    // Turn off error reporting to avoid any output before CSV headers
    error_reporting(0);

    // Get the current date and time in the desired format
    $timestamp = date('Ymd_His');
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="call_logs_' . $timestamp . '.csv"');

    // Output CSV header
    $output = fopen('php://output', 'w');
    fputcsv($output, ["Extension", "Phone Number", "Date", "Time", "Duration", "Call Type", "Tag", "Comment", "Recording Link"]);

    // Fetch call details for CSV without limit
    $csv_query = "
        SELECT calldetails.*, 
               DATE(calldetails.StartTime) AS Date, 
               TIME(calldetails.StartTime) AS Time,
               -- contacts.CustName AS ClientName,
               -- contacts.CustId AS ClientID,
               call_tags.tag AS CallTag,
               call_tags.comment AS CallComment
        FROM calldetails
        -- LEFT JOIN contacts
        -- ON (
        --     SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.PhoneNumber, -10)
        --     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.MobileNumber, -10)
        --     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternatePhoneNumber, -10)
        --     OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternateMobileNumber, -10)
        -- )
        LEFT JOIN call_tags
        ON calldetails.callidpk = call_tags.call_id
        WHERE 1=1 $filter_query
        ORDER BY calldetails.StartTime DESC
    ";

    $csv_result = $dbConnection->query($csv_query);

    while ($row = $csv_result->fetch_assoc()) {
        $filename = $row['Filename'];
        $recording_url = "https://192.168.0.201/RECORDINGS/$filename";
        fputcsv($output, [
            $row['Extension'],
            $row['PhoneNumber'],
            $row['Date'],
            $row['Time'],
            gmdate('H:i:s', strtotime($row['EndTime']) - strtotime($row['StartTime'])),
            $row['Type'],
            $row['CallTag'],
            $row['CallComment'],
            $recording_url
        ]);
    }
    fclose($output);
    exit;
}


include 'header.php'; // Move this after the CSV logic to avoid sending HTML before headers

// Include head.php for CSS and JavaScript
include 'head.php';
?>

<div class="container mt-5">
    <div class="card">
        <div class="card-header">
            <h2 class="mb-0"><i class="mdi mdi-phone-classic me-2"></i>Manage Call Records</h2>
        </div>
        <div class="card-body">
            <?php if ($manage_call_success) { ?>
                <div class="alert alert-success fade-in"><?php echo $manage_call_success; ?></div>
            <?php } elseif ($manage_call_error) { ?>
                <div class="alert alert-danger fade-in"><?php echo $manage_call_error; ?></div>
            <?php } ?>

            <!-- Filter Section -->
            <div class="card mb-4 filter-card">
                <div class="card-header filter-header">
                    <h4 class="mb-0"><i class="mdi mdi-filter-variant me-2"></i>Filter Calls</h4>
                </div>
                <div class="card-body filter-body">
                    <form method="post" action="calls.php" class="filter-form">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="call_type" class="form-label">
                                        <i class="mdi mdi-phone-classic me-1"></i>Call Type
                                    </label>
                                    <select class="form-control focus-ring" id="call_type" name="call_type">
                                        <option value="">All Calls</option>
                                        <option value="incoming" <?php if ($call_type == 'incoming') echo 'selected'; ?>>Incoming</option>
                                        <option value="outgoing" <?php if ($call_type == 'outgoing') echo 'selected'; ?>>Outgoing</option>
                                        <option value="missed" <?php if ($call_type == 'missed') echo 'selected'; ?>>Missed</option>
                                        <option value="no answer" <?php if ($call_type == 'no answer') echo 'selected'; ?>>No Answer</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="start_date" class="form-label">
                                        <i class="mdi mdi-calendar-start me-1"></i>Date From
                                    </label>
                                    <input type="date" class="form-control focus-ring" id="start_date" name="start_date"
                                        value="<?php echo htmlspecialchars($start_date); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="end_date" class="form-label">
                                        <i class="mdi mdi-calendar-end me-1"></i>Date To
                                    </label>
                                    <input type="date" class="form-control focus-ring" id="end_date" name="end_date"
                                        value="<?php echo htmlspecialchars($end_date); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="start_time" class="form-label">
                                        <i class="mdi mdi-clock-start me-1"></i>Time From
                                    </label>
                                    <input type="time" class="form-control focus-ring" id="start_time" name="start_time"
                                        value="<?php echo htmlspecialchars($start_time); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="end_time" class="form-label">
                                        <i class="mdi mdi-clock-end me-1"></i>Time To
                                    </label>
                                    <input type="time" class="form-control focus-ring" id="end_time" name="end_time"
                                        value="<?php echo htmlspecialchars($end_time); ?>">
                                </div>
                            </div>
                            <!-- <div class="col-md-3">
                                <div class="form-group">
                                    <label for="client_id" class="form-label">
                                        <i class="mdi mdi-identifier me-1"></i>Client ID
                                    </label>
                                    <input type="text" class="form-control focus-ring" id="client_id" name="client_id"
                                        placeholder="Enter Client ID" value="<?php echo htmlspecialchars($client_id); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="client_name" class="form-label">
                                        <i class="mdi mdi-account me-1"></i>Client Name
                                    </label>
                                    <input type="text" class="form-control focus-ring" id="client_name" name="client_name"
                                        placeholder="Enter Client Name" value="<?php echo htmlspecialchars($client_name); ?>">
                                </div>
                            </div> -->
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="call_tag" class="form-label">
                                        <i class="mdi mdi-tag me-1"></i>Call Tag
                                    </label>
                                    <input type="text" class="form-control focus-ring" id="call_tag" name="call_tag"
                                        placeholder="Enter Call Tag" value="<?php echo htmlspecialchars($call_tag); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="comments" class="form-label">
                                        <i class="mdi mdi-comment-text me-1"></i>Comments
                                    </label>
                                    <input type="text" class="form-control focus-ring" id="comments" name="comments"
                                        placeholder="Search in comments" value="<?php echo htmlspecialchars($comments); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="extensions" class="form-label">
                                        <i class="mdi mdi-phone-in-talk me-1"></i>Extensions
                                    </label>
                                    <input type="text" class="form-control focus-ring" id="extensions" name="extensions"
                                        placeholder="Enter Extension" value="<?php echo htmlspecialchars($extensions); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="phone" class="form-label">
                                        <i class="mdi mdi-phone me-1"></i>Phone Number
                                    </label>
                                    <input type="text" class="form-control focus-ring" id="phone" name="phone"
                                        placeholder="Enter Phone Number" value="<?php echo htmlspecialchars($phone); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="filter-actions">
                            <button type="submit" class="btn btn-primary filter-btn">
                                <i class="mdi mdi-magnify me-1"></i>Search Calls
                            </button>
                            <button type="button" class="btn btn-outline-secondary filter-btn" id="clear-filters-btn">
                                <i class="mdi mdi-refresh me-1"></i>Clear Filters
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        <!-- Calls Summary Section -->
        <div class="card mb-4 summary-card">
            <div class="card-header summary-header">
                <h5 class="mb-0"><i class="mdi mdi-chart-line me-2"></i>Calls Summary</h5>
            </div>
            <div class="card-body summary-body">
                <div class="row g-1 justify-content-center">
                    <!-- Incoming Calls -->
                    <div class="col-lg-2 col-md-2 col-sm-2 col-2">
                        <div class="summary-item incoming-calls">
                            <div class="summary-icon">
                                <i class="mdi mdi-phone-incoming"></i>
                            </div>
                            <div class="summary-content">
                                <div class="summary-number"><?php echo htmlspecialchars($counts['Incoming'] ?? 0); ?></div>
                                <div class="summary-label">Incoming</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Outgoing Calls -->
                    <div class="col-lg-2 col-md-2 col-sm-2 col-2">
                        <div class="summary-item outgoing-calls">
                            <div class="summary-icon">
                                <i class="mdi mdi-phone-outgoing"></i>
                            </div>
                            <div class="summary-content">
                                <div class="summary-number"><?php echo htmlspecialchars($counts['Outgoing'] ?? 0); ?></div>
                                <div class="summary-label">Outgoing</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Missed Calls -->
                    <div class="col-lg-2 col-md-2 col-sm-2 col-2">
                        <div class="summary-item missed-calls">
                            <div class="summary-icon">
                                <i class="mdi mdi-phone-missed"></i>
                            </div>
                            <div class="summary-content">
                                <div class="summary-number"><?php echo htmlspecialchars($counts['Missed'] ?? 0); ?></div>
                                <div class="summary-label">Missed</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- No Answer Calls -->
                    <div class="col-lg-2 col-md-2 col-sm-2 col-2">
                        <div class="summary-item noanswer-calls">
                            <div class="summary-icon">
                                <i class="mdi mdi-phone-cancel"></i>
                            </div>
                            <div class="summary-content">
                                <div class="summary-number"><?php echo htmlspecialchars($counts['NoAnswer'] ?? 0); ?></div>
                                <div class="summary-label">No Answer</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Total Calls -->
                    <div class="col-lg-2 col-md-2 col-sm-2 col-2">
                        <div class="summary-item total-calls">
                            <div class="summary-icon">
                                <i class="mdi mdi-phone"></i>
                            </div>
                            <div class="summary-content">
                                <div class="summary-number"><?php echo htmlspecialchars($counts['TotalCalls'] ?? 0); ?></div>
                                <div class="summary-label">Total Calls</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center gap-3">
                        <div class="form-check">
                            <input type="checkbox" id="select-all" class="form-check-input" title="Select All">
                            <label class="form-check-label" for="select-all">Select All</label>
                        </div>
                        <?php if (has_permission('batch_download_recordings')): ?>
                        <button type="button" class="btn btn-outline-primary btn-sm" id="download-selected" title="Bulk Download Selected">
                            <i class="mdi mdi-download-multiple me-1"></i>Download Selected
                        </button>
                        <?php endif; ?>
                        <?php if (has_permission('batch_delete_recordings')): ?>
                        <button type="button" class="btn btn-outline-danger btn-sm" id="delete-selected" title="Bulk Delete Selected">
                            <i class="mdi mdi-delete me-1"></i>Delete Selected
                        </button>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (has_permission('export_csv')): ?>
                    <div>
                        <button type="button" class="btn btn-outline-success" id="export-csv-btn" title="Export to CSV">
                            <i class="mdi mdi-download me-1"></i>Export CSV
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Records Table -->
        <div class="card">
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead class="table-dark">
                    <tr>
                        <th>Select</th>
                        <!-- <th>PBX Ext</th> -->
                        <th>Extension</th>
                        <th>Phone Number</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Duration</th>
                        <th>Call Type</th>
                        <th>Tag</th>
                        <th>Comment</th>
                        <th>Recording</th>
                        <th>Actions</th>
                        <!-- <th>Client</th> -->
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) {
                        $filename = $row['Filename'];
                        $recording_file_path = "/var/www/recordings/files/$filename";
                        $file_exists = file_exists($recording_file_path);
                        $recording_url = "https://192.168.0.201/RECORDINGS/$filename";
                        ?>
                        <tr>
                            <td><input type="checkbox" class="select-row" data-call-id="<?php echo $row['callidpk']; ?>"
                                    data-file-name="<?php echo urlencode($filename); ?>"></td>
                            <!-- <td><?php echo htmlspecialchars($row['pbxextn'] ?? 'NA'); ?></td> -->
                            <td><?php echo htmlspecialchars($row['Extension'] ?? 'NA'); ?></td>
                            <td><?php echo htmlspecialchars($row['PhoneNumber'] ?? 'NA'); ?></td>
                            <td><?php echo htmlspecialchars($row['Date']); ?></td>
                            <td><?php echo htmlspecialchars($row['Time']); ?></td>
                            <td><?php echo htmlspecialchars(gmdate('H:i:s', strtotime($row['EndTime']) - strtotime($row['StartTime']))); ?>
                            </td>
                            <td><?php echo htmlspecialchars($row['Type']); ?></td>
                            <td><?php echo htmlspecialchars($row['CallTag'] ?? ''); ?></td>
                            <td>
                                <!-- The pencil icon to edit the comment -->
                                <?php if (has_permission('comments')): ?>
                                <a href="javascript:void(0);" class="btn btn-sm btn-warning edit-comment-btn"
                                    data-call-id="<?php echo $row['callidpk']; ?>"
                                    data-tag="<?php echo htmlspecialchars($row['CallTag']); ?>"
                                    data-comment="<?php echo htmlspecialchars($row['CallComment']); ?>">
                                    <i class="mdi mdi-pencil"></i>
                                    
                                </a>

                                <!-- Display the comment below the pencil icon -->
                                <?php if (!empty($row['CallComment'])) { ?>
                                    <div class="comment-text mt-1">
                                        <?php echo htmlspecialchars($row['CallComment']); ?>
                                    </div>
                                <?php } ?>
                                <?php endif; ?>
                            </td>

                            <td>
                            <?php if (has_permission('play_rec')): ?>
                                <?php if (!empty($row['Filename']) && $file_exists) { ?>
                                    <audio class="audio-player" controls>
                                        <source src="<?php echo $recording_url; ?>" type="audio/wav">
                                        Your browser does not support the audio tag.
                                    </audio>
                                <?php } else { ?>
                                    No Recording Found
                                <?php } ?>
                                <?php endif; ?>
                            </td>
                            <td>
                            <?php if (has_permission('download_rec')): ?>
                                <?php if (!empty($row['Filename']) && $file_exists) { ?>
                                    <a href="download.php?file=<?php echo urlencode($row['Filename']); ?>"
                                        title="Download Recording">
                                        <i class="mdi mdi-download mdi-24px"></i>
                                    </a>
                                <?php } ?>
                                <?php endif; ?>
                                <?php if (has_permission('delete')): ?>
                                <a href="delete_recording.php?call_id=<?php echo urlencode($row['callidpk']); ?>"
                                    title="Delete Recording"
                                    onclick="return confirm('Are you sure you want to delete this recording?');">
                                    <i class="mdi mdi-delete mdi-24px"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                            <!-- <td><?php echo !empty($row['ClientName']) ? htmlspecialchars($row['ClientName']) : ''; ?></td> -->
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <!-- Pagination -->
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <?php
                    $query_string = http_build_query(array_merge($_GET, [
                        'call_type' => $call_type,
                        'start_date' => $start_date,
                        'end_date' => $end_date,
                        'start_time' => $start_time,
                        'end_time' => $end_time,
                        // 'client_id' => $client_id,
                        // 'client_name' => $client_name,
                        'comments' => $comments,
                        'extensions' => $extensions,
                        'phone' => $phone,
                        // 'pbx_ext' => $pbx_ext, // Commented out as not currently used
                        'call_tag' => $call_tag,

                    ]));
                    $total_pages = ceil($total_count / $limit);
                    for ($i = 1; $i <= $total_pages; $i++) {
                        $active = ($i == $page) ? 'active' : '';
                        echo "<li class='page-item $active'><a class='page-link' href='calls.php?page=$i&$query_string'>$i</a></li>";
                    }
                    ?>
                </ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Tagging and Commenting -->
<div class="modal fade" id="tagCommentModal" tabindex="-1" aria-labelledby="tagCommentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tagCommentModalLabel">
                    <i class="mdi mdi-tag-text me-2"></i>Add Tag and Comment
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="tagCommentForm">
                    <input type="hidden" id="callId" name="call_id">
                    <div class="mb-3">
                        <label for="tag" class="form-label">Tag</label>
                        <input type="text" class="form-control focus-ring" id="tag" name="tag" placeholder="Enter tag here..." required>
                    </div>
                    <div class="mb-3">
                        <label for="comment" class="form-label">Comment</label>
                        <textarea class="form-control focus-ring" id="comment" name="comment" rows="3" placeholder="Enter comment here..." required></textarea>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="mdi mdi-content-save me-1"></i>Save
                        </button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="mdi mdi-close me-1"></i>Cancel
                        </button>
                        <button type="button" class="btn btn-info" onclick="testModalInputs()">
                            <i class="mdi mdi-test-tube me-1"></i>Test Inputs
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Include WaveSurfer.js library -->
<script src="https://unpkg.com/wavesurfer.js"></script>
<script>
    // Logic for WaveSurfer and handling modal for tagging/commenting
    document.addEventListener('DOMContentLoaded', function () {
        <?php while ($row = $result->fetch_assoc()) { ?>
            var wavesurfer_<?php echo $row['Filename']; ?> = WaveSurfer.create({
                container: '#waveform-<?php echo $row['Filename']; ?>',
                waveColor: '#00f',
                progressColor: '#0f0',
                height: 60
            });
            wavesurfer_<?php echo $row['Filename']; ?>.load('https://192.168.0.201/RECORDINGS/<?php echo $row['Filename']; ?>.wav');
        <?php } ?>
    });

    document.addEventListener('click', function (event) {
        if (event.target.closest('.edit-comment-btn')) {
            var button = event.target.closest('.edit-comment-btn');
            var callId = button.getAttribute('data-call-id');
            var tag = button.getAttribute('data-tag');
            var comment = button.getAttribute('data-comment');

            // Set values in the modal form
            document.getElementById('callId').value = callId;
            document.getElementById('tag').value = tag;
            document.getElementById('comment').value = comment;

            // Open the modal
            var modal = new bootstrap.Modal(document.getElementById('tagCommentModal'));
            modal.show();
            
            // Ensure inputs are interactive after modal opens
            setTimeout(function() {
                var tagInput = document.getElementById('tag');
                var commentInput = document.getElementById('comment');
                
                // Force enable inputs
                if (tagInput) {
                    tagInput.disabled = false;
                    tagInput.readOnly = false;
                    tagInput.style.pointerEvents = 'auto';
                    tagInput.style.cursor = 'text';
                    tagInput.focus();
                }
                
                if (commentInput) {
                    commentInput.disabled = false;
                    commentInput.readOnly = false;
                    commentInput.style.pointerEvents = 'auto';
                    commentInput.style.cursor = 'text';
                }
                
                console.log('Modal inputs enabled and focused');
            }, 100);
        }
    });

    // Handle the form submission
    document.getElementById('tagCommentForm').addEventListener('submit', function (event) {
        event.preventDefault();
        var formData = new FormData(this);

        fetch('comments.php', {
            method: 'POST',
            body: formData
        }).then(response => response.json()).then(data => {
            if (data.success) {
                alert('Tag and comment saved successfully');
                location.reload();
            } else {
                alert('Failed to save tag and comment');
            }
        });
    });

    // Add event listeners to modal inputs for debugging
    document.addEventListener('DOMContentLoaded', function() {
        var tagInput = document.getElementById('tag');
        var commentInput = document.getElementById('comment');
        
        if (tagInput) {
            tagInput.addEventListener('focus', function() {
                console.log('Tag input focused');
            });
            tagInput.addEventListener('input', function() {
                console.log('Tag input changed:', this.value);
            });
        }
        
        if (commentInput) {
            commentInput.addEventListener('focus', function() {
                console.log('Comment input focused');
            });
            commentInput.addEventListener('input', function() {
                console.log('Comment input changed:', this.value);
            });
        }
    });

    // Test function for modal inputs
    function testModalInputs() {
        var tagInput = document.getElementById('tag');
        var commentInput = document.getElementById('comment');
        
        console.log('Testing modal inputs...');
        console.log('Tag input:', tagInput);
        console.log('Comment input:', commentInput);
        
        if (tagInput) {
            console.log('Tag input properties:');
            console.log('- disabled:', tagInput.disabled);
            console.log('- readOnly:', tagInput.readOnly);
            console.log('- pointerEvents:', tagInput.style.pointerEvents);
            console.log('- cursor:', tagInput.style.cursor);
            console.log('- zIndex:', tagInput.style.zIndex);
            
            // Try to enable and focus
            tagInput.disabled = false;
            tagInput.readOnly = false;
            tagInput.style.pointerEvents = 'auto';
            tagInput.style.cursor = 'text';
            tagInput.style.zIndex = '9999';
            tagInput.focus();
            
            alert('Tag input should now be enabled and focused. Check console for details.');
        } else {
            alert('Tag input not found!');
        }
        
        if (commentInput) {
            console.log('Comment input properties:');
            console.log('- disabled:', commentInput.disabled);
            console.log('- readOnly:', commentInput.readOnly);
            console.log('- pointerEvents:', commentInput.style.pointerEvents);
            console.log('- cursor:', commentInput.style.cursor);
            console.log('- zIndex:', commentInput.style.zIndex);
            
            // Try to enable
            commentInput.disabled = false;
            commentInput.readOnly = false;
            commentInput.style.pointerEvents = 'auto';
            commentInput.style.cursor = 'text';
            commentInput.style.zIndex = '9999';
        } else {
            alert('Comment input not found!');
        }
    }

</script>

<script>
    // Add event listeners to all audio elements
    document.querySelectorAll('.audio-player').forEach(function (audioPlayer) {
        // Expand player when clicked
        audioPlayer.addEventListener('play', function () {
            audioPlayer.classList.add('expanded');
        });

        // Shrink player when paused or ended
        audioPlayer.addEventListener('pause', function () {
            audioPlayer.classList.remove('expanded');
        });
        audioPlayer.addEventListener('ended', function () {
            audioPlayer.classList.remove('expanded');
        });
    });


    // Select All functionality
    document.getElementById('select-all').addEventListener('change', function () {
        const isChecked = this.checked;
        document.querySelectorAll('.select-row').forEach(function (checkbox) {
            checkbox.checked = isChecked;
        });
    });

    // Batch Download Selected
    document.getElementById('download-selected').addEventListener('click', function () {
        const selectedRows = document.querySelectorAll('.select-row:checked');
        if (selectedRows.length === 0) {
            alert('No recordings selected for download.');
            return;
        }

        const selectedFiles = [];
        selectedRows.forEach(function (row) {
            selectedFiles.push(row.dataset.fileName);
        });

        // Trigger batch download via form
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'download.php';  // Use existing download.php for batch download

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_files';
        input.value = JSON.stringify(selectedFiles);
        form.appendChild(input);

        document.body.appendChild(form);
        form.submit();
    });

    document.getElementById('delete-selected').addEventListener('click', function () {
        const selectedRows = document.querySelectorAll('.select-row:checked');
        if (selectedRows.length === 0) {
            alert('No recordings selected for deletion.');
            return;
        }

        if (!confirm('Are you sure you want to delete selected recordings?')) {
            return;
        }

        const selectedCallIds = [];
        selectedRows.forEach(function (row) {
            selectedCallIds.push(row.dataset.callId);
        });

        // Trigger batch delete via form
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'delete_recording.php';  // Make sure it's pointing to the correct PHP file

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_call_ids';
        input.value = JSON.stringify(selectedCallIds);
        form.appendChild(input);

        document.body.appendChild(form);
        form.submit();
    });

    // Handle CSV Export
    document.getElementById('export-csv-btn').addEventListener('click', function () {
        // Show loading state
        this.disabled = true;
        this.innerHTML = '<i class="mdi mdi-loading mdi-spin me-1"></i>Exporting...';
        
        // Create form for CSV export
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'calls.php';
        
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'export_csv';
        input.value = '1';
        form.appendChild(input);
        
        // Add current filter values to maintain state
        const currentForm = document.querySelector('form[method="post"]');
        if (currentForm) {
            const formData = new FormData(currentForm);
            for (let [key, value] of formData.entries()) {
                if (key !== 'export_csv') {
                    const hiddenInput = document.createElement('input');
                    hiddenInput.type = 'hidden';
                    hiddenInput.name = key;
                    hiddenInput.value = value;
                    form.appendChild(hiddenInput);
                }
            }
        }
        
        // Submit form
        document.body.appendChild(form);
        form.submit();
        
        // Reset button after a delay (in case of error)
        setTimeout(() => {
            this.disabled = false;
            this.innerHTML = '<i class="mdi mdi-download me-1"></i>Export CSV';
        }, 5000);
    });

    // Handle Clear Filters
    document.getElementById('clear-filters-btn').addEventListener('click', function () {
        // Show loading state
        this.disabled = true;
        this.innerHTML = '<i class="mdi mdi-loading mdi-spin me-1"></i>Clearing...';
        
        // Clear all form fields
        const form = document.querySelector('form[method="post"]');
        if (form) {
            const inputs = form.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                if (input.type === 'checkbox' || input.type === 'radio') {
                    input.checked = false;
                } else {
                    input.value = '';
                }
            });
        }
        
        // Redirect to base page without any parameters
        window.location.href = 'calls.php';
    });


</script>

<?php include 'footer.php'; ?> 
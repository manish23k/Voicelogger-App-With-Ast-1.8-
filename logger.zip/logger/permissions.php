<?php
include 'config.php';
include 'header.php';
include 'head.php';

// Handle form submissions (add, edit, delete)
$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $permission_name = trim($_POST['permission_name']);
    $description = trim($_POST['description']);
    $permission_type = $_POST['permission_type'];  // Added permission_type field

    if ($action == 'add') {
        // Insert a new permission
        $stmt = $dbConnection->prepare('INSERT INTO permissions (permission_name, description, permission_type) VALUES (?, ?, ?)');
        $stmt->bind_param('sss', $permission_name, $description, $permission_type);
        if ($stmt->execute()) {
            $success_message = 'Permission added successfully.';
        } else {
            $error_message = 'Failed to add permission.';
        }
        $stmt->close();
    } elseif ($action == 'edit') {
        // Update an existing permission
        $permission_id = $_POST['permission_id'];
        $stmt = $dbConnection->prepare('UPDATE permissions SET permission_name = ?, description = ?, permission_type = ? WHERE permission_id = ?');
        $stmt->bind_param('sssi', $permission_name, $description, $permission_type, $permission_id);
        if ($stmt->execute()) {
            $success_message = 'Permission updated successfully.';
        } else {
            $error_message = 'Failed to update permission.';
        }
        $stmt->close();
    }
} elseif ($action == 'delete') {
    // Delete a permission
    $permission_id = $_GET['permission_id'];
    $stmt = $dbConnection->prepare('DELETE FROM permissions WHERE permission_id = ?');
    $stmt->bind_param('i', $permission_id);
    if ($stmt->execute()) {
        $success_message = 'Permission deleted successfully.';
    } else {
        $error_message = 'Failed to delete permission.';
    }
    $stmt->close();
}

// Fetch all permissions from the database
$result = $dbConnection->query('SELECT * FROM permissions ORDER BY permission_id');
$permissions = $result->fetch_all(MYSQLI_ASSOC);
?>

<div class="container mt-5">
    <div class="card">
        <div class="card-header">
            <h2 class="mb-0"><i class="mdi mdi-key me-2"></i>Manage Permissions</h2>
        </div>
        <div class="card-body">
            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success fade-in">
                    <i class="mdi mdi-check-circle me-2"></i><?php echo $success_message; ?>
                </div>
            <?php elseif (!empty($error_message)): ?>
                <div class="alert alert-danger fade-in">
                    <i class="mdi mdi-alert-circle me-2"></i><?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <!-- Add New Permission Button -->
            <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addPermissionModal">
                <i class="mdi mdi-plus me-1"></i>Add Permission
            </button>

            <style>
            .blink {
                color: red;
                animation: blink-animation 1s steps(5, start) infinite;
            }

            @keyframes blink-animation {
                to {
                    visibility: hidden;
                }
            }
            </style>

            <h4 class="mt-5">
                <i class="mdi mdi-list me-2"></i>Existing Permissions
                <span class="blink">(Do not Change / Delete Unless you know what are you Doing.)</span>
            </h4>
            
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th><i class="mdi mdi-numeric me-1"></i>ID</th>
                            <th><i class="mdi mdi-key me-1"></i>Permission Name</th>
                            <th><i class="mdi mdi-text me-1"></i>Description</th>
                            <th><i class="mdi mdi-tag me-1"></i>Permission Type</th>
                            <th><i class="mdi mdi-cog me-1"></i>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($permissions as $permission): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($permission['permission_id']); ?></td>
                                <td><?php echo htmlspecialchars($permission['permission_name']); ?></td>
                                <td><?php echo htmlspecialchars($permission['description']); ?></td>
                                <td>
                                    <span class="badge <?php echo $permission['permission_type'] == 'menu' ? 'bg-primary' : 'bg-success'; ?>">
                                        <?php echo htmlspecialchars($permission['permission_type']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-warning editPermissionBtn" 
                                            data-permission-id="<?php echo $permission['permission_id']; ?>" 
                                            data-permission-name="<?php echo htmlspecialchars($permission['permission_name']); ?>" 
                                            data-description="<?php echo htmlspecialchars($permission['description']); ?>"
                                            data-permission-type="<?php echo htmlspecialchars($permission['permission_type']); ?>"
                                            title="Edit Permission">
                                            <i class="mdi mdi-pencil me-1"></i>Edit
                                        </button>
                                        <a href="permissions.php?action=delete&permission_id=<?php echo $permission['permission_id']; ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('Are you sure you want to delete this permission?');"
                                           title="Delete Permission">
                                            <i class="mdi mdi-delete me-1"></i>Delete
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add New Permission Modal -->
<div class="modal fade" id="addPermissionModal" tabindex="-1" aria-labelledby="addPermissionModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="permissions.php?action=add" method="post">
                <div class="modal-header">
                    <h5 class="modal-title" id="addPermissionModalLabel">
                        <i class="mdi mdi-plus me-2"></i>Add New Permission
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="permission_name" class="form-label">
                            <i class="mdi mdi-key me-1"></i>Permission Name
                        </label>
                        <input type="text" class="form-control focus-ring" id="permission_name" name="permission_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">
                            <i class="mdi mdi-text me-1"></i>Description
                        </label>
                        <input type="text" class="form-control focus-ring" id="description" name="description" required>
                    </div>
                    <div class="mb-3">
                        <label for="permission_type" class="form-label">
                            <i class="mdi mdi-tag me-1"></i>Permission Type
                        </label>
                        <select class="form-control focus-ring" id="permission_type" name="permission_type" required>
                            <option value="menu">Menu</option>
                            <option value="button">Button</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="mdi mdi-close me-1"></i>Close
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="mdi mdi-content-save me-1"></i>Add Permission
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Permission Modal -->
<div class="modal fade" id="editPermissionModal" tabindex="-1" aria-labelledby="editPermissionModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="permissions.php?action=edit" method="post">
                <div class="modal-header">
                    <h5 class="modal-title" id="editPermissionModalLabel">
                        <i class="mdi mdi-pencil me-2"></i>Edit Permission
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_permission_name" class="form-label">
                            <i class="mdi mdi-key me-1"></i>Permission Name
                        </label>
                        <input type="text" class="form-control focus-ring" id="edit_permission_name" name="permission_name" required>
                        <input type="hidden" name="permission_id" id="edit_permission_id">
                    </div>
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">
                            <i class="mdi mdi-text me-1"></i>Description
                        </label>
                        <input type="text" class="form-control focus-ring" id="edit_description" name="description" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_permission_type" class="form-label">
                            <i class="mdi mdi-tag me-1"></i>Permission Type
                        </label>
                        <select class="form-control focus-ring" id="edit_permission_type" name="permission_type" required>
                            <option value="menu">Menu</option>
                            <option value="button">Button</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="mdi mdi-close me-1"></i>Close
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="mdi mdi-content-save me-1"></i>Update Permission
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Handle the edit button click event
    document.querySelectorAll('.editPermissionBtn').forEach(function(button) {
        button.addEventListener('click', function() {
            var permissionId = this.getAttribute('data-permission-id');
            var permissionName = this.getAttribute('data-permission-name');
            var description = this.getAttribute('data-description');
            var permissionType = this.getAttribute('data-permission-type');

            // Set the values in the edit form
            document.getElementById('edit_permission_id').value = permissionId;
            document.getElementById('edit_permission_name').value = permissionName;
            document.getElementById('edit_description').value = description;
            document.getElementById('edit_permission_type').value = permissionType;

            // Show the modal
            var editModal = new bootstrap.Modal(document.getElementById('editPermissionModal'));
            editModal.show();
        });
    });
</script>

<?php include 'footer.php'; ?> 
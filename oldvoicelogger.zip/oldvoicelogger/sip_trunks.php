<?php
session_start();
include 'config.php';
include 'header.php'; // Include your header with CSS and JS

$action_message = '';

// Handle Add/Edit/Delete actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    
    if ($action == 'add') {
        // Add new trunk
        $trunk_name = $_POST['trunk_name'];
        $registration_string = $_POST['registration_string'];
        $template_id = $_POST['template_id'];
        $account_entry = $_POST['account_entry'];
        $dialplan = $_POST['dialplan'];
        $active = $_POST['active'];
        $carrier_description = $_POST['carrier_description'];

        $stmt = $dbConnection->prepare("INSERT INTO sip_trunk_configurations (trunk_name, registration_string, template_id, account_entry, dialplan, active, carrier_description) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisss", $trunk_name, $registration_string, $template_id, $account_entry, $dialplan, $active, $carrier_description);

        if ($stmt->execute()) {
            $action_message = 'Trunk added successfully.';
        } else {
            $action_message = 'Error adding trunk: ' . $stmt->error;
        }
        $stmt->close();
    }

    if ($action == 'edit') {
        // Edit existing trunk
        $trunk_id = $_POST['trunk_id'];
        $trunk_name = $_POST['trunk_name'];
        $registration_string = $_POST['registration_string'];
        $template_id = $_POST['template_id'];
        $account_entry = $_POST['account_entry'];
        $dialplan = $_POST['dialplan'];
        $active = $_POST['active'];
        $carrier_description = $_POST['carrier_description'];

        $stmt = $dbConnection->prepare("UPDATE sip_trunk_configurations SET trunk_name = ?, registration_string = ?, template_id = ?, account_entry = ?, dialplan = ?, active = ?, carrier_description = ? WHERE trunk_id = ?");
        $stmt->bind_param("ssisssi", $trunk_name, $registration_string, $template_id, $account_entry, $dialplan, $active, $carrier_description, $trunk_id);

        if ($stmt->execute()) {
            $action_message = 'Trunk updated successfully.';
        } else {
            $action_message = 'Error updating trunk: ' . $stmt->error;
        }
        $stmt->close();
    }

    if ($action == 'delete') {
        // Delete trunk
        $trunk_id = $_POST['trunk_id'];
        $stmt = $dbConnection->prepare("DELETE FROM sip_trunk_configurations WHERE trunk_id = ?");
        $stmt->bind_param("i", $trunk_id);

        if ($stmt->execute()) {
            $action_message = 'Trunk deleted successfully.';
        } else {
            $action_message = 'Error deleting trunk: ' . $stmt->error;
        }
        $stmt->close();
    }
}

// Fetch all trunks and templates
$trunks = $dbConnection->query("SELECT * FROM sip_trunk_configurations");
$templates = $dbConnection->query("SELECT * FROM sip_trunk_templates");

?>

<div class="container mt-5">
    <h2>SIP Trunk Configurations</h2>
    <?php if ($action_message) { ?>
        <div class="alert alert-success"><?php echo $action_message; ?></div>
    <?php } ?>

    <!-- Add New Trunk Button -->
    <button class="btn btn-primary mb-4" data-bs-toggle="modal" data-bs-target="#addTrunkModal">Add New Trunk</button>

    <!-- SIP Trunks Table -->
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Trunk Name</th>
                <th>Registration String</th>
                <th>Account Entry</th>
                <th>Dialplan</th>
                <th>Active</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $trunks->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['trunk_name']); ?></td>
                <td><?php echo htmlspecialchars($row['registration_string']); ?></td>
                <td><?php echo htmlspecialchars($row['account_entry']); ?></td>
                <td><?php echo htmlspecialchars($row['dialplan']); ?></td>
                <td><?php echo htmlspecialchars($row['active']); ?></td>
                <td><?php echo htmlspecialchars($row['carrier_description']); ?></td>
                <td>
                    <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editTrunkModal<?php echo $row['trunk_id']; ?>">Edit</button>
                    <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteTrunkModal<?php echo $row['trunk_id']; ?>">Delete</button>
                </td>
            </tr>

            <!-- Edit Trunk Modal -->
            <div class="modal fade" id="editTrunkModal<?php echo $row['trunk_id']; ?>" tabindex="-1" aria-labelledby="editTrunkModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="POST">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editTrunkModalLabel">Edit Trunk</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="action" value="edit">
                                <input type="hidden" name="trunk_id" value="<?php echo $row['trunk_id']; ?>">
                                <div class="form-group">
                                    <label>Trunk Name</label>
                                    <input type="text" name="trunk_name" class="form-control" value="<?php echo $row['trunk_name']; ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Registration String</label>
                                    <input type="text" name="registration_string" class="form-control" value="<?php echo $row['registration_string']; ?>">
                                </div>
                                <div class="form-group">
                                    <label>Template</label>
                                    <select name="template_id" class="form-control">
                                        <option value="">Select Template</option>
                                        <?php while ($template = $templates->fetch_assoc()) { ?>
                                        <option value="<?php echo $template['template_id']; ?>" <?php echo $template['template_id'] == $row['template_id'] ? 'selected' : ''; ?>><?php echo $template['template_name']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Account Entry</label>
                                    <textarea name="account_entry" class="form-control"><?php echo $row['account_entry']; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label>Dialplan Entry</label>
                                    <textarea name="dialplan" class="form-control"><?php echo $row['dialplan']; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label>Active</label>
                                    <select name="active" class="form-control">
                                        <option value="Y" <?php echo $row['active'] == 'Y' ? 'selected' : ''; ?>>Yes</option>
                                        <option value="N" <?php echo $row['active'] == 'N' ? 'selected' : ''; ?>>No</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Carrier Description</label>
                                    <textarea name="carrier_description" class="form-control"><?php echo $row['carrier_description']; ?></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Delete Trunk Modal -->
            <div class="modal fade" id="deleteTrunkModal<?php echo $row['trunk_id']; ?>" tabindex="-1" aria-labelledby="deleteTrunkModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="POST">
                            <div class="modal-header">
                                <h5 class="modal-title" id="deleteTrunkModalLabel">Delete Trunk</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                Are you sure you want to delete this trunk?
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="trunk_id" value="<?php echo $row['trunk_id']; ?>">
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-danger">Delete</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <?php } ?>
        </tbody>
    </table>
</div>

<!-- Add New Trunk Modal -->
<div class="modal fade" id="addTrunkModal" tabindex="-1" aria-labelledby="addTrunkModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="addTrunkModalLabel">Add New Trunk</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label>Trunk Name</label>
                        <input type="text" name="trunk_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Registration String</label>
                        <input type="text" name="registration_string" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Template</label>
                        <select name="template_id" class="form-control">
                            <option value="">Select Template</option>
                            <?php while ($template = $templates->fetch_assoc()) { ?>
                            <option value="<?php echo $template['template_id']; ?>"><?php echo $template['template_name']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Account Entry</label>
                        <textarea name="account_entry" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Dialplan</label>
                        <textarea name="dialplan" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Active</label>
                        <select name="active" class="form-control">
                            <option value="Y">Yes</option>
                            <option value="N">No</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Carrier Description</label>
                        <textarea name="carrier_description" class="form-control"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Add Trunk</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

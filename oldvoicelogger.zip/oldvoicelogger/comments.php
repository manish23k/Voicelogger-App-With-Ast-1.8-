<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $call_id = $_POST['call_id'];
    $tag = $_POST['tag'];
    $comment = $_POST['comment'];

    $stmt = $dbConnection->prepare("INSERT INTO call_tags (call_id, tag, comment) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE tag = ?, comment = ?");
    $stmt->bind_param('issss', $call_id, $tag, $comment, $tag, $comment);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }

    $stmt->close();
}
?>

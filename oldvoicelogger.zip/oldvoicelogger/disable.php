<?php
include 'config.php'; // Include your database configuration
include 'header.php'; // Include header for menus and other common elements

// Initialize variables
$manage_logrules_error = '';
$manage_logrules_success = '';
$id = '';
$phonenumber = '';

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action == 'add') {
            // Add log rule
            $phonenumber = trim($_POST['phonenumber']);

            if ($stmt = $dbConnection->prepare('INSERT INTO logrules (phonenumber) VALUES (?)')) {
                $stmt->bind_param('s', $phonenumber);

                if ($stmt->execute()) {
                    $manage_logrules_success = 'Log rule added successfully!';
                } else {
                    $manage_logrules_error = 'Error adding log rule: ' . $dbConnection->error;
                }

                $stmt->close();
            } else {
                $manage_logrules_error = 'Database error: unable to prepare statement. ' . $dbConnection->error;
            }

        } elseif ($action == 'edit') {
            // Edit log rule
            $id = (int)$_POST['id'];
            $phonenumber = trim($_POST['phonenumber']);

            if ($stmt = $dbConnection->prepare('UPDATE logrules SET phonenumber = ? WHERE id = ?')) {
                $stmt->bind_param('si', $phonenumber, $id);

                if ($stmt->execute()) {
                    $manage_logrules_success = 'Rec. Disable rule updated successfully!';
                } else {
                    $manage_logrules_error = 'Error updating Rec. Disable: ' . $dbConnection->error;
                }

                $stmt->close();
            } else {
                $manage_logrules_error = 'Database error: unable to prepare statement. ' . $dbConnection->error;
            }

        } elseif ($action == 'delete') {
            // Delete log rule
            $id = (int)$_POST['id'];

            if ($stmt = $dbConnection->prepare('DELETE FROM logrules WHERE id = ?')) {
                $stmt->bind_param('i', $id);

                if ($stmt->execute()) {
                    $manage_logrules_success = 'Rec. Disable deleted successfully!';
                } else {
                    $manage_logrules_error = 'Error deleting Rec. Disable: ' . $dbConnection->error;
                }

                $stmt->close();
            } else {
                $manage_logrules_error = 'Database error: unable to prepare statement. ' . $dbConnection->error;
            }
        }
    }
}

// Fetch log rules for displaying in the list
$result = $dbConnection->query('SELECT * FROM logrules');

if (!$result) {
    die('Error fetching log rule details: ' . $dbConnection->error); // Specific error message
}
?>

<div class="container mt-5">
    <h2>Manage Rec. Disable</h2>
    <?php if ($manage_logrules_success) { ?>
        <div class="alert alert-success"><?php echo $manage_logrules_success; ?></div>
    <?php } elseif ($manage_logrules_error) { ?>
        <div class="alert alert-danger"><?php echo $manage_logrules_error; ?></div>
    <?php } ?>

    <!-- Add Log Rule Button -->
    <button class="btn btn-primary mb-4" data-bs-toggle="modal" data-bs-target="#addLogRuleModal">Add Rec. Disable</button>

    <!-- Add Log Rule Modal -->
    <div class="modal fade" id="addLogRuleModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post" action="disable.php">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Rec. Disable</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3">
                            <label for="phonenumber" class="form-label">Phone Number</label>
                            <input type="text" class="form-control" id="phonenumber" name="phonenumber">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add Rec. Disable</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Log Rules Table -->
    <h4 class="mt-5">Edit or Delete Rec. Disable</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Phone Number</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['phonenumber']); ?></td>
                    <td>
                        <!-- Edit Button -->
                        <button class="btn btn-warning btn-sm" style="background-color: #ffab00; border-color: #ffab00;" data-bs-toggle="modal" data-bs-target="#editLogRuleModal<?php echo $row['id']; ?>">Edit</button>
                        <!-- Delete Form -->
                        <form method="post" action="disable.php" style="display:inline-block;">
                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
                            <input type="hidden" name="action" value="delete">
                            <button type="submit" class="btn btn-danger btn-sm" style="background-color: #ea5455; border-color: #ea5455;">Delete</button>
                        </form>
                    </td>
                </tr>

                <!-- Edit Log Rule Modal -->
                <div class="modal fade" id="editLogRuleModal<?php echo $row['id']; ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="post" action="disable.php">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Rec. Disable</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="action" value="edit">
                                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                    <div class="mb-3">
                                        <label for="phonenumber<?php echo $row['id']; ?>" class="form-label">Phone Number</label>
                                        <input type="text" class="form-control" id="phonenumber<?php echo $row['id']; ?>" name="phonenumber" value="<?php echo htmlspecialchars($row['phonenumber']); ?>">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-warning" style="background-color: #ffab00; border-color: #ffab00;">Update Log Rule</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>

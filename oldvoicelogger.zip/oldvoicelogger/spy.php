<?php
// Start session if not already started
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    echo "Unauthorized access.";
    exit();
}

$manager_extension = isset($_SESSION['manager_extension']) ? $_SESSION['manager_extension'] : null;

if (!$manager_extension) {
    echo "Error: Manager extension not set.";
    exit();
}

// Connect to Asterisk AMI (modify details as per your setup)
$host = '127.0.0.1';
$port = 5038;
$username = 'cron'; // Replace with actual username
$password = '1234'; // Replace with actual password

$channel = $_GET['channel']; // Pass the live call's channel via GET parameter

// Connect to Asterisk AMI
$socket = @fsockopen($host, $port, $errno, $errstr, 5);

if ($socket) {
    fwrite($socket, "Action: Login\r\nUsername: $username\r\nSecret: $password\r\nEvents: Off\r\n\r\n");

    // Wait for authentication response
    while (!feof($socket)) {
        $line = fgets($socket, 128);
        if (strpos($line, 'Message: Authentication accepted') !== false) {
            break;
        }
    }

    // Originate a call to the manager's extension for ChanSpy or Barge
    if ($channel) {
        if (isset($_GET['action']) && $_GET['action'] === 'spy') {
            // Spy (Listen)
            fputs($socket, "Action: Originate\r\n");
            fputs($socket, "Channel: SIP/$manager_extension\r\n");  // Dynamic extension
            fputs($socket, "Context: from-pbx\r\n");
            fputs($socket, "Exten: *555" . $channel . "\r\n");  // *555 to invoke ChanSpy
            fputs($socket, "Priority: 1\r\n");
            fputs($socket, "CallerID: Spy\r\n\r\n");
        } elseif (isset($_GET['action']) && $_GET['action'] === 'barge') {
            // Barge
            fputs($socket, "Action: Originate\r\n");
            fputs($socket, "Channel: SIP/$manager_extension\r\n");  // Dynamic extension
            fputs($socket, "Context: from-pbx\r\n");
            fputs($socket, "Exten: *556" . $channel . "\r\n");  // *556 to invoke Barge
            fputs($socket, "Priority: 1\r\n");
            fputs($socket, "CallerID: Barge\r\n\r\n");
        }
    }

    fclose($socket);
} else {
    echo "Error connecting to Asterisk AMI: $errstr ($errno)";
}
?>

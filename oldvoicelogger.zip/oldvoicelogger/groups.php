<?php
include 'config.php';
include 'header.php'; // Include header for menus and other common elements

session_start();


error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}

// Initialize variables
$manage_group_error = '';
$manage_group_success = '';
$groupID = '';
$groupName = '';
$extensions = [];

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action == 'add') {
            // Add Group
            $groupName = trim($_POST['groupname']);

            if ($stmt = $dbConnection->prepare('INSERT INTO groups (groupname) VALUES (?)')) {
                $stmt->bind_param('s', $groupName);

                if ($stmt->execute()) {
                    $manage_group_success = 'Group added successfully!';
                } else {
                    $manage_group_error = 'Error adding group: ' . $dbConnection->error;
                }

                $stmt->close();
            } else {
                $manage_group_error = 'Database error: unable to prepare statement. ' . $dbConnection->error;
            }
        } elseif ($action == 'edit') {
            // Edit Group
            $groupID = (int) $_POST['groupID'];
            $groupName = trim($_POST['groupname']);

            if ($stmt = $dbConnection->prepare('UPDATE groups SET groupname = ? WHERE id = ?')) {
                $stmt->bind_param('si', $groupName, $groupID);

                if ($stmt->execute()) {
                    $manage_group_success = 'Group updated successfully!';
                } else {
                    $manage_group_error = 'Error updating group: ' . $dbConnection->error;
                }

                $stmt->close();
            } else {
                $manage_group_error = 'Database error: unable to prepare statement. ' . $dbConnection->error;
            }
        } elseif ($action == 'delete') {
            // Delete Group
            $groupID = (int) $_POST['groupID'];

            if ($stmt = $dbConnection->prepare('DELETE FROM groups WHERE id = ?')) {
                $stmt->bind_param('i', $groupID);

                if ($stmt->execute()) {
                    $manage_group_success = 'Group deleted successfully!';
                } else {
                    $manage_group_error = 'Error deleting group: ' . $dbConnection->error;
                }

                $stmt->close();
            } else {
                $manage_group_error = 'Database error: unable to prepare statement. ' . $dbConnection->error;
            }
        } elseif ($action == 'add_extensions') {
            // Add Extensions to Group
            $groupID = (int) $_POST['groupID'];
            $selected_extensions = $_POST['selected_extensions'] ?? [];

            // Delete existing extensions for the group
            $dbConnection->query("DELETE FROM groupextensions WHERE groupid = $groupID");

            // Insert the selected extensions
            foreach ($selected_extensions as $extension) {
                $stmt = $dbConnection->prepare("INSERT INTO groupextensions (groupid, extension) VALUES (?, ?)");
                $stmt->bind_param('is', $groupID, $extension);
                $stmt->execute();
            }

            $manage_group_success = 'Extensions added to group successfully!';
        }
    }
}

// Fetch groups for displaying in the list
$result = $dbConnection->query('SELECT * FROM groups');
if (!$result) {
    die('Error fetching groups: ' . $dbConnection->error);
}

// Fetch all extensions from calldetails for selection
$extensions_result = $dbConnection->query('SELECT DISTINCT Extension FROM calldetails');
while ($ext_row = $extensions_result->fetch_assoc()) {
    $extensions[] = $ext_row['Extension'];
}
?>

<div class="container mt-5">
    <h2>Manage Groups</h2>
    <?php if ($manage_group_success) { ?>
        <div class="alert alert-success"><?php echo $manage_group_success; ?></div>
    <?php } elseif ($manage_group_error) { ?>
        <div class="alert alert-danger"><?php echo $manage_group_error; ?></div>
    <?php } ?>

    <!-- Add Group Button -->
    <button class="btn btn-primary mb-4" data-bs-toggle="modal" data-bs-target="#addGroupModal">Add New Group</button>

    <!-- Add Group Modal -->
    <div class="modal fade" id="addGroupModal" tabindex="-1" aria-labelledby="addGroupModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post" action="groups.php">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addGroupModalLabel">Add Group</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3">
                            <label for="groupname" class="form-label">Group Name</label>
                            <input type="text" class="form-control" id="groupname" name="groupname" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add Group</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit/Delete Groups Table -->
    <h4 class="mt-5">Edit or Delete Groups</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Group Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['groupname']); ?></td>
                    <td>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editGroupModal" onclick="populateEditForm('<?php echo htmlspecialchars($row['id']); ?>', '<?php echo htmlspecialchars($row['groupname']); ?>')">Edit</button>
                        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addExtensionModal" onclick="loadExtensions(<?php echo $row['id']; ?>)">Add Extensions</button>
                        <form method="post" action="groups.php" style="display:inline-block;">
                            <input type="hidden" name="groupID" value="<?php echo htmlspecialchars($row['id']); ?>">
                            <input type="hidden" name="action" value="delete">
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<!-- Add Extensions Modal -->
<div class="modal fade" id="addExtensionModal" tabindex="-1" aria-labelledby="addExtensionModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="groups.php">
                <div class="modal-header">
                    <h5 class="modal-title" id="addExtensionModalLabel">Add Extensions to Group</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="extension-groupID" name="groupID"> <!-- Hidden input for group ID -->
                    <input type="hidden" name="action" value="add_extensions"> <!-- Specify the action -->

                    <!-- Select All/Unselect All checkbox -->
                    <div class="form-check mb-3">
                        <input type="checkbox" class="form-check-input" id="select_all_extensions">
                        <label class="form-check-label" for="select_all_extensions">Select All/Unselect All Extensions</label>
                    </div>

                    <div class="row">
                        <?php foreach ($extensions as $extension) { ?>
                            <div class="col-md-4">
                                <div class="form-check">
                                    <input class="form-check-input extension-checkbox" type="checkbox" name="selected_extensions[]" value="<?php echo htmlspecialchars($extension); ?>">
                                    <label class="form-check-label"><?php echo htmlspecialchars($extension); ?></label>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Extensions</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Group Modal -->
<div class="modal fade" id="editGroupModal" tabindex="-1" aria-labelledby="editGroupModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="groups.php">
                <div class="modal-header">
                    <h5 class="modal-title" id="editGroupModalLabel">Edit Group</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" id="edit-groupID" name="groupID">
                    <div class="mb-3">
                        <label for="edit-groupname" class="form-label">Group Name</label>
                        <input type="text" class="form-control" id="edit-groupname" name="groupname" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update Group</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function populateEditForm(id, groupname) {
        document.getElementById('edit-groupID').value = id;
        document.getElementById('edit-groupname').value = groupname;
    }

    function loadExtensions(groupID) {
        // Set the group ID in the hidden input field of the form
        document.getElementById('extension-groupID').value = groupID;

        // Fetch existing extensions for the group via AJAX
        fetch('get_group_extensions.php?groupID=' + groupID)
            .then(response => response.json())
            .then(data => {
                // Reset all checkboxes
                document.querySelectorAll('.extension-checkbox').forEach(checkbox => {
                    checkbox.checked = false;
                });

                // Check the checkboxes for the extensions already in the group
                data.forEach(extension => {
                    document.querySelector('.extension-checkbox[value="' + extension + '"]').checked = true;
                });
            });
    }

    // Select/Unselect All functionality
    document.getElementById('select_all_extensions').addEventListener('change', function() {
        document.querySelectorAll('.extension-checkbox').forEach(checkbox => {
            checkbox.checked = this.checked;
        });
    });
</script>

<?php include 'footer.php'; ?>
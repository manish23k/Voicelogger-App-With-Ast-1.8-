<?php
// Start session if not already started
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    echo "Unauthorized access.";
    exit();
}
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

// Asterisk AMI connection details
$host = '127.0.0.1';
$port = 5038;
$username = 'cron'; // Replace with actual username
$password = '1234'; // Replace with actual password

$liveCalls = []; // Array to store live calls

// Connect to Asterisk AMI
$socket = @fsockopen($host, $port, $errno, $errstr, 5);

if ($socket) {
    fwrite($socket, "Action: Login\r\nUsername: $username\r\nSecret: $password\r\nEvents: Off\r\n\r\n");

    stream_set_timeout($socket, 5);
    $response = '';

    while (!feof($socket)) {
        $line = fgets($socket, 128);
        if ($line === false) break;
        $response .= $line;
        if (strpos($line, 'Response: Success') !== false || strpos($line, 'Message: Authentication accepted') !== false) {
            break;
        } elseif (strpos($line, 'Response: Error') !== false || strpos($line, 'Message: Authentication failed') !== false) {
            break;
        }
    }

    if (strpos($response, 'Response: Success') !== false) {
        // Connected to Asterisk AMI successfully, fetch live call data
        fwrite($socket, "Action: Command\r\nCommand: core show channels concise\r\n\r\n");

        $response = '';
        while (!feof($socket)) {
            $line = fgets($socket, 128);
            if ($line === false) break;
            $response .= $line;
            if (strpos($line, '--END COMMAND--') !== false) {
                break; // End of command output
            }
        }

        // Process live call data
        $liveCallLines = explode("\n", $response);
        foreach ($liveCallLines as $line) {
            // Clean up the line and remove "Output: " if it's present
            $cleanedLine = preg_replace(['/^Output: /', '/^SIP\//'], '', trim($line));
            if (!empty($cleanedLine) && strpos($cleanedLine, '!') !== false) {
                $liveCalls[] = $cleanedLine;
            }
        }
        // Display live calls in a table format
        if (!empty($liveCalls)) {
            echo '<table class="table table-bordered">';
            echo '<thead><tr>';
            echo '<th>Channel</th><th>Context</th><th>Exten</th><th>Priority</th>';
            echo '<th>State</th><th>Application</th><th>Data</th>';
            echo '<th>CallerID</th><th>Duration</th><th>Actions</th>'; // Added actions for Barge and Listen
            echo '</tr></thead><tbody>';

            foreach ($liveCalls as $call) {
                $callDetails = explode('!', $call);
                $channel = htmlspecialchars($callDetails[0]);  // First column is the channel

                echo '<tr>';
                foreach ($callDetails as $detail) {
                    echo '<td>' . htmlspecialchars($detail) . '</td>';
                }

                // Add Listen and Barge buttons with cleaned channel data
                echo '<td>';
                $cleanedChannel = urlencode($channel); // Proper URL encoding of the channel
                $ext = htmlspecialchars($_SESSION['manager_extension']); // Assuming you stored manager extension in session
                echo '<a href="spy.php?action=spy&channel=' . $cleanedChannel . '&ext=' . $ext . '" class="btn btn-sm btn-info">Listen</a> ';
                echo '<a href="spy.php?action=barge&channel=' . $cleanedChannel . '&ext=' . $ext . '" class="btn btn-sm btn-warning">Barge</a>';
                echo '</td>';

                echo '</tr>';
            }

            echo '</tbody></table>';
        } else {
            echo '<p>No live calls currently.</p>';
        }

    } else {
        echo "Failed to log in to Asterisk AMI.";
    }

    fclose($socket);
} else {
    echo "Error connecting to Asterisk AMI: $errstr ($errno)";
}
?>

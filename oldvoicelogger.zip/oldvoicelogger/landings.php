<?php
include 'config.php'; // Include your database configuration
include 'header.php'; // Include header for menus and other common elements

// Initialize variables
$manage_landing_error = '';
$manage_landing_success = '';
$extension = '';
$callerid = '';
$callername = '';
$id = '';

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action == 'add') {
            // Add Landing
            $extension = trim($_POST['extension']);
            $callerid = trim($_POST['callerid']);
            $callername = trim($_POST['callername']);

            if ($stmt = $dbConnection->prepare('INSERT INTO landings (extension, callerid, callername) VALUES (?, ?, ?)')) {
                $stmt->bind_param('sss', $extension, $callerid, $callername);

                if ($stmt->execute()) {
                    $manage_landing_success = 'Landing added successfully!';
                } else {
                    $manage_landing_error = 'Error adding landing: ' . $dbConnection->error;
                }

                $stmt->close();
            } else {
                $manage_landing_error = 'Database error: unable to prepare statement. ' . $dbConnection->error;
            }

        } elseif ($action == 'edit') {
            // Edit Landing
            $id = (int)$_POST['id'];
            $extension = trim($_POST['extension']);
            $callerid = trim($_POST['callerid']);
            $callername = trim($_POST['callername']);

            if ($stmt = $dbConnection->prepare('UPDATE landings SET extension = ?, callerid = ?, callername = ? WHERE id = ?')) {
                $stmt->bind_param('sssi', $extension, $callerid, $callername, $id);

                if ($stmt->execute()) {
                    $manage_landing_success = 'Landing updated successfully!';
                } else {
                    $manage_landing_error = 'Error updating landing: ' . $dbConnection->error;
                }

                $stmt->close();
            } else {
                $manage_landing_error = 'Database error: unable to prepare statement. ' . $dbConnection->error;
            }

        } elseif ($action == 'delete') {
            // Delete Landing
            $id = (int)$_POST['id'];

            if ($stmt = $dbConnection->prepare('DELETE FROM landings WHERE id = ?')) {
                $stmt->bind_param('i', $id);

                if ($stmt->execute()) {
                    $manage_landing_success = 'Routing deleted successfully!';
                } else {
                    $manage_landing_error = 'Error deleting landing: ' . $dbConnection->error;
                }

                $stmt->close();
            } else {
                $manage_landing_error = 'Database error: unable to prepare statement. ' . $dbConnection->error;
            }
        }
    }
}

// Fetch landings for displaying in the list
$result = $dbConnection->query('SELECT * FROM landings');

if (!$result) {
    die('Error fetching landing details: ' . $dbConnection->error); // Specific error message
}

?>

<div class="container mt-5">
    <h2>Manage Routings</h2>
    <?php if ($manage_landing_success) { ?>
        <div class="alert alert-success"><?php echo $manage_landing_success; ?></div>
    <?php } elseif ($manage_landing_error) { ?>
        <div class="alert alert-danger"><?php echo $manage_landing_error; ?></div>
    <?php } ?>

    <!-- Add Landing Button -->
    <button class="btn btn-primary mb-4" data-bs-toggle="modal" data-bs-target="#addLandingModal">Add Routing</button>

    <!-- Add Landing Modal -->
    <div class="modal fade" id="addLandingModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post" action="landings.php">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Routing</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3">
                            <label for="extension" class="form-label">Extension</label>
                            <input type="text" class="form-control" id="extension" name="extension">
                        </div>
                        <div class="mb-3">
                            <label for="callerid" class="form-label">Caller ID</label>
                            <input type="text" class="form-control" id="callerid" name="callerid">
                        </div>
                        <div class="mb-3">
                            <label for="callername" class="form-label">Caller Name</label>
                            <input type="text" class="form-control" id="callername" name="callername">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add Routing</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Landing Modal -->
    <div class="modal fade" id="editLandingModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post" action="landings.php">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Routing</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" id="edit-id">
                        <input type="hidden" name="action" value="edit">
                        <div class="mb-3">
                            <label for="edit-extension" class="form-label">Extension</label>
                            <input type="text" class="form-control" id="edit-extension" name="extension">
                        </div>
                        <div class="mb-3">
                            <label for="edit-callerid" class="form-label">Caller ID</label>
                            <input type="text" class="form-control" id="edit-callerid" name="callerid">
                        </div>
                        <div class="mb-3">
                            <label for="edit-callername" class="form-label">Caller Name</label>
                            <input type="text" class="form-control" id="edit-callername" name="callername">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update Routing</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit/Delete Landing Table -->
    <h4 class="mt-5">Edit or Delete Routing</h4>
    <table class="table table-bordered">
        
        <thead>
            <tr>
                <th>Extension</th>
                <th>Caller ID</th>
                <th>Caller Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['extension']); ?></td>
                    <td><?php echo htmlspecialchars($row['callerid']); ?></td>
                    <td><?php echo htmlspecialchars($row['callername']); ?></td>
                    <td>
                        <button type="button" class="btn btn-warning btn-sm" onclick="populateEditForm(
                            '<?php echo htmlspecialchars($row['id']); ?>',
                            '<?php echo htmlspecialchars($row['extension']); ?>',
                            '<?php echo htmlspecialchars($row['callerid']); ?>',
                            '<?php echo htmlspecialchars($row['callername']); ?>'
                        )">Edit</button>
                        <form method="post" action="landings.php" style="display:inline-block;">
                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
                            <input type="hidden" name="action" value="delete">
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script>
function populateEditForm(id, extension, callerid, callername) {
    document.getElementById('edit-id').value = id;
    document.getElementById('edit-extension').value = extension;
    document.getElementById('edit-callerid').value = callerid;
    document.getElementById('edit-callername').value = callername;
    var editModal = new bootstrap.Modal(document.getElementById('editLandingModal'));
    editModal.show();
}
</script>

<?php include 'footer.php'; ?>

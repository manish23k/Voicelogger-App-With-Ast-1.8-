<?php
// Asterisk AMI connection details
$host = '127.0.0.1';
$port = 5038;
$username = 'cron';
$password = '1234';

// Function to connect and fetch peer status
function get_peer_status($host, $port, $username, $password) {
    $socket = @fsockopen($host, $port, $errno, $errstr, 5);

    if (!$socket) {
        echo "Error: Unable to connect to AMI";
        return;
    }

    stream_set_timeout($socket, 3);

    // Login action
    fwrite($socket, "Action: Login\r\nUsername: $username\r\nSecret: $password\r\nEvents: Off\r\n\r\n");

    // Capture login response
    while (!feof($socket)) {
        $line = fgets($socket, 128);
        if (strpos($line, 'Response: Success') !== false) {
            break;
        }
    }

    // Send the command to show peers
    fwrite($socket, "Action: SIPpeers\r\n\r\n");

    $output = '';

    while (!feof($socket)) {
        $line = fgets($socket, 128);
        $output .= $line;

        // End when command is done
        if (strpos($line, '--END COMMAND--') !== false) {
            break;
        }
    }

    // Log off
    fwrite($socket, "Action: Logoff\r\n\r\n");
    fclose($socket);

    return $output;
}

// Fetch SIP peers and return status
$status = get_peer_status($host, $port, $username, $password);

if ($status) {
    echo "<pre>$status</pre>";  // For now, display raw output
} else {
    echo "Failed to retrieve SIP trunk status.";
}
?>
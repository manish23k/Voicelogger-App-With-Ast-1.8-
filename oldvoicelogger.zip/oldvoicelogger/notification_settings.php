<?php
// notification_settings.php

include 'config.php'; // Include your database configuration
include 'header.php'; // Include header for menus and other common elements

$notification_success = '';
$notification_error = '';

// Handle form submissions for settings
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $call_duration_limit = trim($_POST['call_duration_limit']);
    $alert_type = trim($_POST['alert_type']);
    $alert_threshold = trim($_POST['alert_threshold']);
    $admin_email = trim($_POST['admin_email']);
    

    // Validate input
    if (empty($call_duration_limit) || empty($alert_type) || empty($alert_threshold) || empty($admin_email)) {
        $notification_error = 'Please fill in all required fields';
    } else {
        // Save the settings (You may insert these values into a database or a configuration file)
        $stmt = $dbConnection->prepare("INSERT INTO alert_settings (call_duration_limit, alert_type, alert_threshold, admin_email) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('sssss', $call_duration_limit, $alert_type, $alert_threshold, $admin_email, $admin_phone);

        if ($stmt->execute()) {
            $notification_success = 'Alert settings saved successfully';
        } else {
            $notification_error = 'Failed to save alert settings';
        }
    }
}

?>

<div class="container mt-5">
    <h2>Configure Alerts & Notifications</h2>
    <?php if ($notification_success) { ?>
        <div class="alert alert-success"><?php echo $notification_success; ?></div>
    <?php } elseif ($notification_error) { ?>
        <div class="alert alert-danger"><?php echo $notification_error; ?></div>
    <?php } ?>

    <!-- Notification Settings Form -->
    <form method="post" action="notification_settings.php">
        <div class="row">
            <div class="col-md-6">
                <label for="call_duration_limit" class="form-label">Max Call Duration (in minutes)</label>
                <input type="number" class="form-control" id="call_duration_limit" name="call_duration_limit" required>
            </div>
            <div class="col-md-6">
                <label for="alert_type" class="form-label">Alert Type</label>
                <select class="form-control" id="alert_type" name="alert_type" required>
                    <option value="missed">Missed Calls</option>
                    <option value="long_duration">Long Duration Calls</option>
                    <option value="tagged">Calls Tagged with Category</option>
                </select>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-md-6">
                <label for="alert_threshold" class="form-label">Alert Threshold (Minutes)</label>
                <input type="number" class="form-control" id="alert_threshold" name="alert_threshold" required>
            </div>
            <div class="col-md-6">
                <label for="admin_email" class="form-label">Admin Email</label>
                <input type="email" class="form-control" id="admin_email" name="admin_email" required>
            </div>
        </div>
        <button type="submit" class="btn btn-primary mt-4">Save Settings</button>
    </form>
</div>

<?php include 'footer.php'; ?>

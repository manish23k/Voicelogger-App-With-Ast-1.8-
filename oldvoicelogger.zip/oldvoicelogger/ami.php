<?php
$host = '127.0.0.1';  // Replace with your Asterisk server's IP if different
$port = 5038;
$username = 'cron';  // Replace with the AMI username from manager.conf
$password = '1234';  // Replace with the AMI password from manager.conf

$socket = @fsockopen($host, $port, $errno, $errstr, 5);

if (!$socket) {
    echo "Error connecting to Asterisk AMI: $errstr ($errno)";
} else {
    fwrite($socket, "Action: Login\r\nUsername: $username\r\nSecret: $password\r\nEvents: Off\r\n\r\n");

    stream_set_timeout($socket, 5);
    $response = '';

    while (!feof($socket)) {
        $line = fgets($socket, 128);
        if ($line === false) break;
        $response .= $line;
        if (strpos($line, 'Response: Success') !== false || strpos($line, 'Message: Authentication accepted') !== false) {
            break;
        } elseif (strpos($line, 'Response: Error') !== false || strpos($line, 'Message: Authentication failed') !== false) {
            break;
        }
    }

    echo nl2br(htmlspecialchars($response));

    if (strpos($response, 'Response: Success') !== false) {
        echo "<br>Connected to Asterisk AMI successfully.<br>";

        // Send a command to get live calls
        fwrite($socket, "Action: Command\r\nCommand: core show channels concise\r\n\r\n");

        $response = '';
        while (!feof($socket)) {
            $line = fgets($socket, 128);
            if ($line === false) break;
            $response .= $line;
            if (strpos($line, '--END COMMAND--') !== false) {
                break; // End of command output
            }
        }

        // Display live calls data
        echo "<pre>" . nl2br(htmlspecialchars($response)) . "</pre>";
    } else {
        echo "<br>Failed to log in to Asterisk AMI.<br>";
        if (strpos($response, 'Message: Authentication failed') !== false) {
            echo "Authentication failed. Check username and password in manager.conf.";
        }
    }

    fclose($socket);
}
?>
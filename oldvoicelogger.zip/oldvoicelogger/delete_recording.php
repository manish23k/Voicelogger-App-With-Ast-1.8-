<?php
// Include your config for database connection
include 'config.php';

// Check if it's a batch delete request
if (isset($_POST['selected_call_ids'])) {
    $selected_call_ids = json_decode($_POST['selected_call_ids'], true);

    if (is_array($selected_call_ids) && count($selected_call_ids) > 0) {
        foreach ($selected_call_ids as $call_id) {
            $call_id = intval($call_id);

            // Fetch the filename of the recording based on call_id
            $query = "SELECT Filename FROM calldetails WHERE callidpk = $call_id";
            $result = $dbConnection->query($query);
            $row = $result->fetch_assoc();

            if ($row && !empty($row['Filename'])) {
                $filename = $row['Filename'];
                $filepath = '/var/www/recordings/files/' . $filename;

                // Delete the file if it exists
                if (file_exists($filepath)) {
                    unlink($filepath); // Delete the file from the server
                }

                // Delete the database entry
                $delete_query = "DELETE FROM calldetails WHERE callidpk = $call_id";
                if (!$dbConnection->query($delete_query)) {
                    echo "Error deleting record: " . $dbConnection->error;
                    exit;
                }
            }
        }
        // Redirect to calls page with success message after batch deletion
        header("Location: calls.php?delete_success=1");
        exit;
    } else {
        echo "No call IDs selected for deletion!";
        exit;
    }
}

// Check if it's a single delete request (via GET)
if (isset($_GET['call_id'])) {
    $call_id = intval($_GET['call_id']);

    // Fetch the filename of the recording based on call_id
    $query = "SELECT Filename FROM calldetails WHERE callidpk = $call_id";
    $result = $dbConnection->query($query);
    $row = $result->fetch_assoc();

    if ($row && !empty($row['Filename'])) {
        $filename = $row['Filename'];
        $filepath = '/var/www/recordings/files/' . $filename;

        // Delete the file if it exists
        if (file_exists($filepath)) {
            unlink($filepath); // Delete the file from the server
        }

        // Delete the database entry
        $delete_query = "DELETE FROM calldetails WHERE callidpk = $call_id";
        if ($dbConnection->query($delete_query)) {
            // Redirect to calls page with success message
            header("Location: calls.php?delete_success=1");
            exit;
        } else {
            echo "Error deleting record: " . $dbConnection->error;
        }
    } else {
        echo "Recording not found!";
    }
} else {
    echo "Invalid request!";
}
?>

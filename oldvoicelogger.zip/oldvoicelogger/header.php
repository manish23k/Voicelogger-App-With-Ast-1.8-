<?php
// Start session if not already started
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
  header('Location: login.php');
  exit();
}

// Get the current file name without the extension
$currentPage = basename($_SERVER['PHP_SELF'], ".php");
?>
<!DOCTYPE html>
<html lang="en" class="light-style layout-menu-fixed layout-compact" dir="ltr" data-theme="theme-default"
  data-assets-path="assets/" data-template="vertical-menu-template-free">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $currentPage ?? 'Voicecatch V 3.0'; ?></title>
  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />
  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&amp;display=swap">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" />
  <link rel="stylesheet" href="assets/vendor/fonts/materialdesignicons.css" />
  <!-- Menu waves for no-customizer fix -->
  <link rel="stylesheet" href="assets/vendor/libs/node-waves/node-waves.css" />
  <!-- Core CSS -->
  <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
  <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="assets/css/demo.css" />
  <!-- Vendors CSS -->
  <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
  <link rel="stylesheet" href="assets/vendor/libs/apex-charts/apex-charts.css" />
  <script src="assets/vendor/js/helpers.js"></script>
  <script src="assets/js/config.js"></script>

  <style>
    /* FOOTER */
    html, body {
  height: 100%; /* Ensure the full height is used */
  margin: 0; /* Remove default margin */
}

.content-wrapper {
  min-height: calc(100vh - 50px); /* Adjust '50px' to match your footer's height */
  display: flex;
  flex-direction: column;
}

.content-wrapper > .main-content {
  flex: 1; /* Push footer to the bottom */
}

footer {
  background-color: #f8f9fa; /* Optional: Footer background color */
  text-align: center;
  padding: 10px 0;
  position: relative;
  bottom: 0;
  width: 100%;
}
    /* Sidebar styling */
/* Sidebar */
.layout-menu {
  width: 250px;
  height: 100vh;
  background-color: #f8f9fa;
  transition: all 0.3s ease;
  position: fixed;
  z-index: 1030;
}

.layout-menu-collapsed {
  width: 0;
  overflow: hidden;
}

/* Sidebar Toggle Button */
#sidebar-toggle {
  font-size: 18px;
  color: #6c757d;
  background-color: transparent;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
  z-index: 1040;
}

#sidebar-toggle:hover {
  background-color: #e0e0e0;
}

/* Navbar */
.navbar {
  height: 1px;
  background-color: #ffffff;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  z-index: 1050;
  position: fixed;
  width: 100%;
  top: 0;
}

/* Content Wrapper */
.content-wrapper {
  margin-top: 7px;
  margin-left: 20px;
  
  /* margin-bottom: 80px; */
  padding: 20px;
  transition: margin-left 0.3s ease;
}

.layout-menu-collapsed + .content-wrapper {
  margin-left: 0;
}

/* Avatar Dropdown */
.navbar-nav-right {
  display: flex;
  align-items: center;
}

.avatar img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
}

/* Adjust the logo container */
.app-brand {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 10px;
  height: 80px; /* Ensure enough height for the logo */
  box-sizing: border-box;
  border-bottom: 1px solid #e0e0e0; /* Optional: adds a divider */
}

/* Logo image styling */
.app-brand img {
  max-width: 100%;
  height: auto;
  display: block;
}

/* Menu inner padding to avoid overlap */
.menu-inner {
  padding-top: 1px; /* Add space between logo and menu items */
}

/* Sidebar item spacing */
.menu-item {
  padding: 5px 5px;
}

/* Ensure menu icons and text are aligned */
.menu-item .menu-link {
  display: flex;
  align-items: center;
  gap: 1px; /* Space between icon and text */
}

  </style>
</head>

<body>
<nav class="navbar">
  <!-- Sidebar Toggle Button -->
  <div class="d-flex align-items-center">
    <button class="btn btn-outline-secondary me-2" id="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <!-- Logo -->
    <a href="dashboard.php">
      <img src="assets/img/voicecatch_vl.png" alt="Logo" style="width: 180px; height: auto;">
    </a>
  </div>

  <!-- Avatar Dropdown -->
  <div class="navbar-nav-right">
    <ul class="navbar-nav flex-row align-items-center">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
          <div class="avatar avatar-online">
            <img src="assets/img/avatars/1.png" alt="User Avatar">
          </div>
        </a>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="#">My Profile</a></li>
          <li><a class="dropdown-item" href="logout.php">Log Out</a></li>
        </ul>
      </li>
    </ul>
  </div>
</nav>

  <!-- Toggle Sidebar Button (Opens and Closes) -->
  <!-- <button class="open-button" id="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button> -->

  <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme sidenav">
  <div class="app-brand demo">
    <a href="dashboard.php" class="app-brand-link">
      <!-- <img src="assets/img/voicecatch_vl.png" alt="Voice Catch Logo" style="width: 180px; height: auto;"> -->
    </a>
  </div>
  <div class="menu-inner py-1">
          <!-- Dashboard -->
          <?php if (has_permission('view_dashboard')): ?>
            <li class="menu-item <?php echo $currentPage == 'dashboard' ? 'active' : ''; ?>">
              <a href="dashboard.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-home-outline"></i>
                <div data-i18n="Dashboards">Dashboards</div>
              </a>
            </li>
          <?php endif; ?>

          <!-- Call Records -->
          <?php if (has_permission('view_calls')): ?>
            <li class="menu-item <?php echo $currentPage == 'calls' ? 'active' : ''; ?>">
              <a href="calls.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-phone"></i>
                <div>Call Records</div>
              </a>
            </li>
          <?php endif; ?>
          <!-- Groups -->
          <?php if (has_permission('view_groups')): ?>
            <li class="menu-item <?php echo $currentPage == 'groups' ? 'active' : ''; ?>">
              <a href="groups.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-account-group"></i>
                <div>Ext Groups</div>
              </a>
            </li>
          <?php endif; ?>

          <!-- Landings -->
          <?php if (has_permission('view_landings')): ?>
            <li class="menu-item <?php echo $currentPage == 'landings' ? 'active' : ''; ?>">
              <a href="landings.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-account-arrow-right-outline"></i>
                <div>Landings</div>
              </a>
            </li>
          <?php endif; ?>

          <!-- Disable -->
          <?php if (has_permission('view_disable')): ?>
            <li class="menu-item <?php echo $currentPage == 'disable' ? 'active' : ''; ?>">
              <a href="disable.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-cancel"></i>
                <div>Disable</div>
              </a>
            </li>
          <?php endif; ?>

          <!-- Users -->
          <?php if (has_permission('manage_users')): ?>
            <li class="menu-item <?php echo $currentPage == 'users' ? 'active' : ''; ?>">
              <a href="users.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-account"></i>
                <div>Users</div>
              </a>
            </li>
          <?php endif; ?>

          <!-- Manage Roles -->
          <!-- <?php if (has_permission('manage_roles')): ?>
            <li class="menu-item <?php echo $currentPage == 'manage_roles' ? 'active' : ''; ?>">
              <a href="manage_roles.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-account-outline"></i>
                <div>Manage Roles</div>
              </a>
            </li>
          <?php endif; ?> -->

          <!-- Permissions -->
          <?php if (has_permission('manage_permissions')): ?>
            <li class="menu-item <?php echo $currentPage == 'permissions' ? 'active' : ''; ?>">
              <a href="permissions.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-shield-lock-outline"></i>
                <div>Permissions</div>
              </a>
            </li>
          <?php endif; ?>



          <!-- PhoneBook -->
          <?php if (has_permission('view_contact')): ?>
            <li class="menu-item <?php echo $currentPage == 'contact' ? 'active' : ''; ?>">
              <a href="contact.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-email-outline"></i>
                <div>PhoneBook</div>
              </a>
            </li>
          <?php endif; ?>

          <!-- Shutdown -->
          <?php if (has_permission('view_shutdown')): ?>
            <li class="menu-item <?php echo $currentPage == 'shutdown' ? 'active' : ''; ?>">
              <a href="shutdown.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-power"></i>
                <div>Shutdown</div>
              </a>
            </li>
          <?php endif; ?>

          <!-- Maintenance -->
          <?php if (has_permission('view_cleanup')): ?>
            <li class="menu-item <?php echo $currentPage == 'cleanup' ? 'active' : ''; ?>">
              <a href="cleanup.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-delete-outline"></i>
                <div>Maintenance</div>
              </a>
            </li>
          <?php endif; ?>

          <!-- Sip trunk -->
          <!-- <?php if (has_permission('manage_siptrunk')): ?>
            <li class="menu-item <?php echo $currentPage == 'sip_trunks' ? 'active' : ''; ?>">
              <a href="sip_trunks.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-phone-outline"></i>
                <div>SIP Trunk</div>
              </a>
            </li>
          <?php endif; ?>

          
          <?php if (has_permission('manage_notifications')): ?> -->
            <!-- <li class="menu-item <?php echo $currentPage == 'notification_settings' ? 'active' : ''; ?>">
              <a href="notification_settings.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-bell-alert-outline"></i>
                <div>Notifications</div>
              </a>
            </li> -->
          <?php endif; ?>
          <!-- Sysinfo -->
          <?php if (has_permission('view_sysinfo')): ?>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link" onclick="openSysinfo()">
                <i class="menu-icon tf-icons mdi mdi-information-outline"></i>
                <div>Sysinfo</div>
              </a>
            </li>
          <?php endif; ?>
                    <li class="menu-item <?php echo $currentPage == 'logout' ? 'active' : ''; ?>">
              <a href="logout.php" class="menu-link">
                <i class="menu-icon tf-icons mdi mdi-logout"></i>
                <div>Logout</div>
              </a>
            </li>
        </ul>
      </aside>
      <iframe id="sysinfoFrame" src="" style="width: 100%; height: 800px; border: none; display: none;"></iframe>
      <script>
        function openSysinfo() {
          var sysinfoFrame = document.getElementById('sysinfoFrame');
          if (sysinfoFrame.style.display === "none") {
            sysinfoFrame.src = "https://192.168.0.201/phpsysinfo/index.php?disp=bootstrap";
            sysinfoFrame.style.display = "block";
          } else {
            sysinfoFrame.style.display = "none";
            sysinfoFrame.src = "";
          }
        }

        // Sidebar Toggle function (Opens and Closes)
        function toggleSidebar() {
  const layoutMenu = document.getElementById("layout-menu");
  const contentWrapper = document.querySelector(".content-wrapper");

  if (layoutMenu.classList.contains("layout-menu-collapsed")) {
    layoutMenu.classList.remove("layout-menu-collapsed");
    contentWrapper.style.marginLeft = "250px";
  } else {
    layoutMenu.classList.add("layout-menu-collapsed");
    contentWrapper.style.marginLeft = "0";
  }
}
      </script>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
      <!-- Existing content -->
      
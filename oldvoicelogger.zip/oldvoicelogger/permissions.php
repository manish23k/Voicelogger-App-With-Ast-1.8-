<?php
include 'config.php'; // Include your database configuration
include 'header.php'; // Include header for menus and other common elements

// Handle form submissions (add, edit, delete)
$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $permission_name = trim($_POST['permission_name']);
    $description = trim($_POST['description']);
    $permission_type = $_POST['permission_type'];  // Added permission_type field

    if ($action == 'add') {
        // Insert a new permission
        $stmt = $dbConnection->prepare('INSERT INTO permissions (permission_name, description, permission_type) VALUES (?, ?, ?)');
        $stmt->bind_param('sss', $permission_name, $description, $permission_type);
        if ($stmt->execute()) {
            $success_message = 'Permission added successfully.';
        } else {
            $error_message = 'Failed to add permission.';
        }
        $stmt->close();
    } elseif ($action == 'edit') {
        // Update an existing permission
        $permission_id = $_POST['permission_id'];
        $stmt = $dbConnection->prepare('UPDATE permissions SET permission_name = ?, description = ?, permission_type = ? WHERE permission_id = ?');
        $stmt->bind_param('sssi', $permission_name, $description, $permission_type, $permission_id);
        if ($stmt->execute()) {
            $success_message = 'Permission updated successfully.';
        } else {
            $error_message = 'Failed to update permission.';
        }
        $stmt->close();
    }
} elseif ($action == 'delete') {
    // Delete a permission
    $permission_id = $_GET['permission_id'];
    $stmt = $dbConnection->prepare('DELETE FROM permissions WHERE permission_id = ?');
    $stmt->bind_param('i', $permission_id);
    if ($stmt->execute()) {
        $success_message = 'Permission deleted successfully.';
    } else {
        $error_message = 'Failed to delete permission.';
    }
    $stmt->close();
}

// Fetch all permissions from the database
$result = $dbConnection->query('SELECT * FROM permissions ORDER BY permission_id');
$permissions = $result->fetch_all(MYSQLI_ASSOC);
?>

<div class="container mt-5">
    <h2>Manage Permissions</h2>

    <?php if (!empty($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php elseif (!empty($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <!-- Add New Permission Button -->
    <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addPermissionModal">
        Add Permission
    </button>

    <!-- Add New Permission Modal -->
    <div class="modal fade" id="addPermissionModal" tabindex="-1" aria-labelledby="addPermissionModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="permissions.php?action=add" method="post">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addPermissionModalLabel">Add New Permission</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="permission_name" class="form-label">Permission Name</label>
                            <input type="text" class="form-control" id="permission_name" name="permission_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <input type="text" class="form-control" id="description" name="description" required>
                        </div>
                        <div class="mb-3">
                            <label for="permission_type" class="form-label">Permission Type</label>
                            <select class="form-select" id="permission_type" name="permission_type" required>
                                <option value="menu">Menu</option>
                                <option value="button">Button</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add Permission</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <style>
    .blink {
        color: red;
        animation: blink-animation 1s steps(5, start) infinite;
    }

    @keyframes blink-animation {
        to {
            visibility: hidden;
        }
    }
</style>

<h4 class="mt-5">Existing Permissions
    <span class="blink">(Do not Change / Delete Unless you know what are you Doing.)</span>
</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Permission Name</th>
                <th>Description</th>
                <th>Permission Type</th> <!-- Added column for Permission Type -->
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($permissions as $permission): ?>
                <tr>
                    <td><?php echo htmlspecialchars($permission['permission_id']); ?></td>
                    <td><?php echo htmlspecialchars($permission['permission_name']); ?></td>
                    <td><?php echo htmlspecialchars($permission['description']); ?></td>
                    <td><?php echo htmlspecialchars($permission['permission_type']); ?></td> <!-- Display Permission Type -->
                    <td>
                    <button class="btn btn-warning btn-sm editPermissionBtn" 
    data-permission-id="<?php echo $permission['permission_id']; ?>" 
    data-permission-name="<?php echo htmlspecialchars($permission['permission_name']); ?>" 
    data-description="<?php echo htmlspecialchars($permission['description']); ?>"
    data-permission-type="<?php echo htmlspecialchars($permission['permission_type']); ?>"> <!-- Added permission_type -->
    Edit
</button>
                        <a href="permissions.php?action=delete&permission_id=<?php echo $permission['permission_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this permission?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Edit Permission Modal -->
<div class="modal fade" id="editPermissionModal" tabindex="-1" aria-labelledby="editPermissionModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="permissions.php?action=edit" method="post">
                <div class="modal-header">
                    <h5 class="modal-title" id="editPermissionModalLabel">Edit Permission</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_permission_name" class="form-label">Permission Name</label>
                        <input type="text" class="form-control" id="edit_permission_name" name="permission_name" required>
                        <input type="hidden" name="permission_id" id="edit_permission_id">
                    </div>
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">Description</label>
                        <input type="text" class="form-control" id="edit_description" name="description" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_permission_type" class="form-label">Permission Type</label>
                        <select class="form-control" id="edit_permission_type" name="permission_type" required>
                            <option value="menu">Menu</option>
                            <option value="button">Button</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update Permission</button>
                </div>
            </form>
        </div>
    </div>
</div>


<script>
    // Handle the edit button click event
    document.querySelectorAll('.editPermissionBtn').forEach(function(button) {
        button.addEventListener('click', function() {
            var permissionId = this.getAttribute('data-permission-id');
            var permissionName = this.getAttribute('data-permission-name');
            var description = this.getAttribute('data-description');
            var permissionType = this.getAttribute('data-permission-type'); // New attribute for permission type

            // Set the values in the edit form
            document.getElementById('edit_permission_id').value = permissionId;
            document.getElementById('edit_permission_name').value = permissionName;
            document.getElementById('edit_description').value = description;
            document.getElementById('edit_permission_type').value = permissionType; // Set permission type

            // Show the modal
            var editModal = new bootstrap.Modal(document.getElementById('editPermissionModal'));
            editModal.show();
        });
    });
</script>


<?php include 'footer.php'; ?>

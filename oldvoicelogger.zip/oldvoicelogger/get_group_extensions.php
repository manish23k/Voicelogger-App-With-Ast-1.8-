<?php
include 'config.php'; // Include database connection

$groupID = isset($_GET['groupID']) ? (int)$_GET['groupID'] : 0;
$extensions = [];

if ($groupID > 0) {
    // Fetch the extensions for the given group
    $stmt = $dbConnection->prepare("SELECT extension FROM groupextensions WHERE groupid = ?");
    $stmt->bind_param('i', $groupID);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $extensions[] = $row['extension'];
    }

    $stmt->close();
}

header('Content-Type: application/json');
echo json_encode($extensions);

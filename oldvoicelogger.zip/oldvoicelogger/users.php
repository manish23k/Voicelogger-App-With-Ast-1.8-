<?php
include 'config.php';
include 'header.php';

// Handle adding or editing users
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['username'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $role_id = (int)$_POST['role'];
    $status = $_POST['status'];
    $extension_group = $_POST['extension_group'];
    $extension = ($_POST['extension_group'] == 'SELF') ? trim($_POST['extension']) : null;
    $group_id = ($_POST['extension_group'] == 'GROUP') ? (int)$_POST['group_id'] : null;

    $user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;

    if ($user_id == 0) {
        // Add new user
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $stmt = $dbConnection->prepare("INSERT INTO users (username, email, password, role_id, status, extension_group, extension, group_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('sssisssi', $username, $email, $password, $role_id, $status, $extension_group, $extension, $group_id);
    } else {
        // Edit existing user
        if (!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
            $stmt = $dbConnection->prepare("UPDATE users SET username=?, email=?, password=?, role_id=?, status=?, extension_group=?, extension=?, group_id=? WHERE user_id=?");
            $stmt->bind_param('sssisssii', $username, $email, $password, $role_id, $status, $extension_group, $extension, $group_id, $user_id);
        } else {
            $stmt = $dbConnection->prepare("UPDATE users SET username=?, email=?, role_id=?, status=?, extension_group=?, extension=?, group_id=? WHERE user_id=?");
            $stmt->bind_param('ssisssii', $username, $email, $role_id, $status, $extension_group, $extension, $group_id, $user_id);
        }
    }

    if ($stmt->execute()) {
        echo "User saved successfully!";
    } else {
        echo "Error saving user: " . $stmt->error;
    }
}

// Handle deleting a user
if (isset($_GET['delete'])) {
    $user_id = (int)$_GET['delete'];
    $stmt = $dbConnection->prepare("DELETE FROM users WHERE user_id = ?");
    $stmt->bind_param('i', $user_id);
    if ($stmt->execute()) {
        echo "User deleted successfully!";
    } else {
        echo "Error deleting user: " . $dbConnection->error;
    }
    $stmt->close();
}

// Handle adding, editing, and deleting roles
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['role_name'])) {
    $role_name = trim($_POST['role_name']);
    $role_id = isset($_POST['role_id']) ? (int)$_POST['role_id'] : 0;
    $action = $_POST['action'];

    if ($action == 'add') {
        // Add new role
        if (!empty($role_name)) {
            $stmt = $dbConnection->prepare("INSERT INTO roles (role_name) VALUES (?)");
            $stmt->bind_param('s', $role_name);
            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>Role added successfully!</div>";
            } else {
                echo "<div class='alert alert-danger'>Error adding role: " . $stmt->error . "</div>";
            }
            $stmt->close();
        }
    } elseif ($action == 'edit' && $role_id > 0) {
        // Edit existing role
        if (!empty($role_name)) {
            $stmt = $dbConnection->prepare("UPDATE roles SET role_name=? WHERE role_id=?");
            $stmt->bind_param('si', $role_name, $role_id);
            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>Role updated successfully!</div>";
            } else {
                echo "<div class='alert alert-danger'>Error updating role: " . $stmt->error . "</div>";
            }
            $stmt->close();
        }
    }
}


// Handle deleting a role
if (isset($_GET['delete_role'])) {
    $role_id = (int)$_GET['delete_role'];
    $stmt = $dbConnection->prepare("DELETE FROM roles WHERE role_id = ?");
    $stmt->bind_param('i', $role_id);
    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Role deleted successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error deleting role: " . $dbConnection->error . "</div>";
    }
    $stmt->close();
}

// Fetch roles
$roles = [];
$roles_result = $dbConnection->query("SELECT * FROM roles");
if ($roles_result->num_rows > 0) {
    while ($row = $roles_result->fetch_assoc()) {
        $roles[] = $row;
    }
}

// Fetch users
$users_result = $dbConnection->query("
    SELECT users.*, roles.role_name, 
           CASE 
               WHEN users.extension_group = 'GROUP' THEN users.group_id
               WHEN users.extension_group = 'SELF' THEN users.extension
               ELSE NULL 
           END AS extension_or_group_id 
    FROM users 
    LEFT JOIN roles 
    ON users.role_id = roles.role_id
");

// Fetch all permissions dynamically
$permissions_result = $dbConnection->query('SELECT * FROM permissions');

// Initialize permissions of the selected role
$role_permissions = [];
$selected_role_id = $_POST['role_id'] ?? $_GET['role_id'] ?? null;

if ($selected_role_id) {
    $role_permissions_result = $dbConnection->query("SELECT permission_id FROM role_permissions WHERE role_id = $selected_role_id");
    if ($role_permissions_result) {
        while ($row = $role_permissions_result->fetch_assoc()) {
            $role_permissions[] = $row['permission_id'];
        }
    }
}


// Handle permissions form submission separately
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['permissions'])) {
    $role_id = $_POST['role_id'];
    $selected_permissions = $_POST['permissions'] ?? [];

    // Delete existing permissions for the role
    $dbConnection->query("DELETE FROM role_permissions WHERE role_id = $role_id");

    // Insert new permissions
    foreach ($selected_permissions as $permission_id) {
        $dbConnection->query("INSERT INTO role_permissions (role_id, permission_id) VALUES ($role_id, $permission_id)");
    }

    // Fetch updated permissions and return them as JSON
    $updated_permissions = [];
    $role_permissions_result = $dbConnection->query("SELECT permission_id FROM role_permissions WHERE role_id = $role_id");
    while ($row = $role_permissions_result->fetch_assoc()) {
        $updated_permissions[] = $row['permission_id'];
    }

    // Return the updated permissions in JSON format
    //echo json_encode(['success' => true, 'updated_permissions' => $updated_permissions]);
   // exit;
}

?>

<div class="container mt-5">
    <!-- Tabs for Users and Roles -->
    <ul class="nav nav-pills mb-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link <?php echo (!isset($_GET['active_tab']) || $_GET['active_tab'] == 'users') ? 'active' : ''; ?>" id="users-tab" data-bs-toggle="tab" href="#users" role="tab" aria-controls="users" aria-selected="true">Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (isset($_GET['active_tab']) && $_GET['active_tab'] == 'roles') ? 'active' : ''; ?>" id="roles-tab" data-bs-toggle="tab" href="#roles" role="tab" aria-controls="roles" aria-selected="false">User Roles</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (isset($_GET['active_tab']) && $_GET['active_tab'] == 'permissions') ? 'active' : ''; ?>" id="permissions-tab" data-bs-toggle="tab" href="#permissions" role="tab" aria-controls="permissions" aria-selected="false">Manage Permissions</a>
        </li>
    </ul>

    <div class="tab-content" id="myTabContent">
        <!-- Users Tab -->
        <div class="tab-pane fade show <?php echo (!isset($_GET['active_tab']) || $_GET['active_tab'] == 'users') ? 'active' : ''; ?>" id="users" role="tabpanel" aria-labelledby="users-tab">
            <h2>Manage Users</h2>
            <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#userModal">Add User</button>
            <!-- Users Table -->
            <table class="table table-bordered">
            <thead class="table-dark">
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Extension Group</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $users_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['role_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['status']); ?></td>
                            <td><?php echo htmlspecialchars($row['extension_group']); ?></td>
                            <td>
                                <button class="btn btn-sm btn-warning"
                                    onclick="editUser(
                            <?php echo $row['user_id']; ?>, 
                            '<?php echo htmlspecialchars($row['username']); ?>', 
                            '<?php echo htmlspecialchars($row['email']); ?>', 
                            <?php echo $row['role_id']; ?>, 
                            '<?php echo htmlspecialchars($row['status']); ?>', 
                            '<?php echo htmlspecialchars($row['extension_group']); ?>', 
                            '<?php echo htmlspecialchars($row['extension_or_group_id']); ?>'
                        )">Edit</button>
                                <a href="users.php?delete=<?php echo $row['user_id']; ?>&active_tab=users"
                                    class="btn btn-sm btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Roles Tab (User Group Management) -->
        <div class="tab-pane fade <?php echo (isset($_GET['active_tab']) && $_GET['active_tab'] == 'roles') ? 'show active' : ''; ?>" id="roles" role="tabpanel" aria-labelledby="roles-tab">
            <h2>Manage User Roles</h2>
            <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#roleModal">Add Role</button>

            <!-- Roles Table -->
            <table class="table table-bordered">
            <thead class="table-dark">
                    <tr>
                        <th>User Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($roles) > 0): ?>
                        <?php foreach ($roles as $role): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($role['role_name']); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-warning" onclick="editRole(<?php echo $role['role_id']; ?>, '<?php echo htmlspecialchars($role['role_name']); ?>')">Edit</button>
                                    <a href="users.php?delete_role=<?php echo $role['role_id']; ?>&active_tab=roles" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this role?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2">No roles found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Permissions Tab -->
        <div class="tab-pane fade <?php echo (isset($_GET['active_tab']) && $_GET['active_tab'] == 'permissions') ? 'show active' : ''; ?>" id="permissions" role="tabpanel" aria-labelledby="permissions-tab">
            <h2>Manage Role Permissions</h2>

            <form method="get" action="users.php">
    <input type="hidden" name="active_tab" value="permissions"> <!-- Keeps the active tab after form submit -->
    <div class="row">
        <div class="col-md-6">
            <label for="role_id" class="form-label">Select Role</label>
            <select name="role_id" class="form-control" id="role_id" onchange="this.form.submit()" required>
                <option value="">Select a role</option>
                <?php foreach ($roles as $role): ?>
                    <option value="<?php echo htmlspecialchars($role['role_id']); ?>"
                        <?php echo ($selected_role_id == $role['role_id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($role['role_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
</form>

<?php if ($selected_role_id): ?>
    <form method="post" action="users.php?active_tab=permissions">
        <input type="hidden" name="role_id" value="<?php echo $selected_role_id; ?>"> <!-- Retain selected role -->
        <div class="mt-3">
        <h4>Select Permissions</h4>
            <div class="form-check mb-3">
                <input type="checkbox" class="form-check-input" id="select_all_menus">
                <label class="form-check-label" for="select_all_menus">Select All/Unselect All (Menus)</label>
            </div>

            <!-- Menus Section -->
            <div class="row">
                <div class="col-md-12">
                    <h5>Menus</h5>
                    <?php
                    $menu_permissions_query = "SELECT * FROM permissions WHERE permission_type = 'menu'";
                    $menu_permissions_result = $dbConnection->query($menu_permissions_query);

                    while ($permission = $menu_permissions_result->fetch_assoc()) {
                    ?>
                        <div class="form-check form-check-inline">
                            <input type="checkbox" class="form-check-input menu-checkbox"
                                name="permissions[]"
                                value="<?php echo $permission['permission_id']; ?>"
                                id="permission_<?php echo $permission['permission_id']; ?>"
                                <?php echo in_array($permission['permission_id'], $role_permissions) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="permission_<?php echo $permission['permission_id']; ?>">
                                <?php echo $permission['permission_name']; ?> - <?php echo $permission['description']; ?>
                            </label>
                        </div>
                    <?php } ?>
                </div>
            </div>

            <!-- Select All for Buttons -->
            <div class="form-check mb-3 mt-4">
                <input type="checkbox" class="form-check-input" id="select_all_buttons">
                <label class="form-check-label" for="select_all_buttons">Select All/Unselect All (Buttons)</label>
            </div>

            <!-- Buttons Section -->
            <div class="row">
                <div class="col-md-12">
                    <h5>Buttons</h5>
                    <?php
                    $button_permissions_query = "SELECT * FROM permissions WHERE permission_type = 'button'";
                    $button_permissions_result = $dbConnection->query($button_permissions_query);

                    while ($permission = $button_permissions_result->fetch_assoc()) {
                    ?>
<div class="form-check form-check-inline">
    <input type="checkbox" class="form-check-input menu-checkbox"
        name="permissions[]"
        value="<?php echo $permission['permission_id']; ?>"
        id="permission_<?php echo $permission['permission_id']; ?>"
        <?php echo in_array($permission['permission_id'], $role_permissions) ? 'checked' : ''; ?>>
    <label class="form-check-label" for="permission_<?php echo $permission['permission_id']; ?>">
        <?php echo $permission['permission_name']; ?> - <?php echo $permission['description']; ?>
    </label>
</div>
                    <?php } ?>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Save Permissions</button>
    </form>
<?php endif; ?>
        </div>


    </div>
</div>

<!-- Modals for Adding/Editing -->
<div class="modal fade" id="userModal" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="userForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="userModalLabel">Add/Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="user_id" name="user_id">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password">
                        <small class="form-text text-muted">Leave blank to keep the current password when editing.</small>
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <select class="form-control" id="role" name="role" required>
                            <?php foreach ($roles as $role_row): ?>
                                <option value="<?php echo $role_row['role_id']; ?>"><?php echo htmlspecialchars($role_row['role_name']); ?></option>
                            <?php endforeach; ?>

                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="extension_group" class="form-label">Extension Group</label>
                        <select class="form-control" id="extension_group" name="extension_group" onchange="toggleExtensionInput()" required>
                            <option value="ALL">All Extensions</option>
                            <option value="GROUP">Specific Group</option>
                            <option value="SELF">Self</option>
                        </select>
                    </div>
                    <div class="mb-3" id="group_select" style="display: none;">
                        <label for="group_id" class="form-label">Select Group</label>
                        <select class="form-control" id="group_id" name="group_id">
                            <?php
                            $group_result = $dbConnection->query("SELECT id, groupname FROM groups");
                            while ($group_row = $group_result->fetch_assoc()) { ?>
                                <option value="<?php echo $group_row['id']; ?>"><?php echo htmlspecialchars($group_row['groupname']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="mb-3" id="extension_input" style="display: none;">
                        <label for="extension" class="form-label">Extension Number</label>
                        <input type="text" class="form-control" id="extension" name="extension" placeholder="Enter extension number if Self is selected">
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-control" id="status" name="status" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal for Adding/Editing Role -->
<div class="modal fade" id="roleModal" tabindex="-1" aria-labelledby="roleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="users.php?active_tab=roles">
                <input type="hidden" name="role_id" id="role_hidden"> <!-- Hidden field for role ID -->
                <input type="hidden" name="action" id="role_action" value="add"> <!-- Default to add -->
                <div class="modal-header">
                    <h5 class="modal-title" id="roleModalLabel">Add/Edit Role</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="role_name" class="form-label">Role Name</label>
                        <input type="text" class="form-control" id="role_name" name="role_name" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Role</button>
                </div>
            </form>
        </div>
    </div>
</div>


<script>
    function toggleExtensionInput() {
        var extensionGroup = document.getElementById('extension_group').value;
        var groupSelect = document.getElementById('group_select');
        var extensionInput = document.getElementById('extension_input');

        if (extensionGroup === 'GROUP') {
            groupSelect.style.display = 'block';
            extensionInput.style.display = 'none';
        } else if (extensionGroup === 'SELF') {
            groupSelect.style.display = 'none';
            extensionInput.style.display = 'block';
        } else {
            groupSelect.style.display = 'none';
            extensionInput.style.display = 'none';
        }
    }

    // Open modal and pre-fill form when editing a role
    function editRole(role_id, role_name) {
        document.getElementById('role_hidden').value = role_id; // Set role ID in the hidden field
        document.getElementById('role_name').value = role_name; // Set role name
        document.getElementById('role_action').value = 'edit'; // Set the form action to edit
        var roleModal = new bootstrap.Modal(document.getElementById('roleModal'));
        roleModal.show();
    }

    // Clear the form when adding a new role
    document.addEventListener('DOMContentLoaded', function() {
        var modalButton = document.querySelector('.btn-primary[data-bs-target="#roleModal"]');
        if (modalButton) {
            modalButton.addEventListener('click', function() {
                document.getElementById('role_hidden').value = ''; // Clear role ID
                document.getElementById('role_name').value = ''; // Clear role name
                document.getElementById('role_action').value = 'add'; // Set form action to add
            });
        }
    });


    // Open modal and pre-fill form when editing a user
    function editUser(user_id, username, email, role_id, status, extension_group, extension_or_group_id) {
        document.getElementById('user_id').value = user_id;
        document.getElementById('username').value = username;
        document.getElementById('email').value = email;
        document.getElementById('role').value = role_id;
        document.getElementById('status').value = status;
        document.getElementById('extension_group').value = extension_group;

        toggleExtensionInput();

        if (extension_group === 'SELF') {
            document.getElementById('extension').value = extension_or_group_id || '';
        } else if (extension_group === 'GROUP') {
            document.getElementById('group_id').value = extension_or_group_id || '';
        } else {
            document.getElementById('extension').value = '';
            document.getElementById('group_id').value = '';
        }

        var userModal = new bootstrap.Modal(document.getElementById('userModal'));
        userModal.show();
    }

    //Permission
// Handle form submission for permissions
document.querySelector('#permissions_form').addEventListener('submit', function (event) {

    event.preventDefault(); // Prevent default form submission

    let formData = new FormData(this); // Prepare form data for AJAX submission

    // Send the form data to the server using fetch
    fetch('users.php?active_tab=permissions', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())  // Parse the JSON response
    .then(data => {
        if (data.success) {
            // Success message
            alert('Permissions updated successfully!');

            // Uncheck all permissions first to reset the view
            document.querySelectorAll('input[name="permissions[]"]').forEach(checkbox => {
                checkbox.checked = false;
            });

            // Check the updated permissions from the server response
            data.updated_permissions.forEach(permission_id => {
                let checkbox = document.getElementById(`permission_${permission_id}`);
                if (checkbox) {
                    checkbox.checked = true;
                }
            });
        } else {
            alert('Failed to update permissions');
        }
    })
    .catch(error => {
        console.error('Error updating permissions:', error);
        alert('An error occurred while updating permissions.');
    });
});




    // Select All for Menus
    document.getElementById('select_all_menus').addEventListener('change', function() {
        let checkboxes = document.querySelectorAll('.menu-checkbox');
        for (let checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    });

    // Select All for Buttons
    document.getElementById('select_all_buttons').addEventListener('change', function() {
        let checkboxes = document.querySelectorAll('.button-checkbox');
        for (let checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    });

    // Function to set the correct active tab based on the URL parameter
    function setActiveTab() {
        const urlParams = new URLSearchParams(window.location.search);
        const activeTab = urlParams.get('active_tab');

        if (activeTab) {
            document.querySelectorAll('.nav-link').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(tabPane => tabPane.classList.remove('show', 'active'));

            document.getElementById(activeTab + '-tab').classList.add('active');
            document.getElementById(activeTab).classList.add('show', 'active');
        }
    }

    // Call the function on page load
    document.addEventListener('DOMContentLoaded', setActiveTab);
</script>

<?php include 'footer.php'; ?>
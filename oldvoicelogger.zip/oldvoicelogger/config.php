<?php
// config.php

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'cron');
define('DB_PASSWORD', '1234');
define('DB_NAME', 'voicecatch');

// Function to establish a database connection
function getDatabaseConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

    // Check for connection errors
    if ($conn->connect_error) {
        // Handle error based on PHP version
        if (version_compare(PHP_VERSION, '8.0.0') >= 0) {
            // PHP 8.0 or newer - use exceptions
            throw new Exception("Connection failed: " . $conn->connect_error);
        } else {
            // PHP 7.x - use traditional error handling
            die("Connection failed: " . $conn->connect_error);
        }
    }

    return $conn;
}

// Establish a database connection when the file is included
try {
    $dbConnection = getDatabaseConnection();
} catch (Exception $e) {
    echo "Database connection error: " . $e->getMessage();
    exit; // Stop script execution if there is a connection error
}
// Start session
if (!isset($_SESSION)) {
    session_start();
}

// Function to fetch user permissions based on role
function fetch_user_permissions($role_id, $dbConnection) {
    $permissions = [];

    $stmt = $dbConnection->prepare("
        SELECT permissions.permission_name
        FROM role_permissions
        JOIN permissions ON role_permissions.permission_id = permissions.permission_id
        WHERE role_permissions.role_id = ?
    ");
    $stmt->bind_param('i', $role_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $permissions[] = $row['permission_name'];
    }

    $stmt->close();
    
    return $permissions;
}

// Check if the user is logged in and fetch permissions
if (isset($_SESSION['role_id'])) {
    // Fetch and store permissions for the logged-in user
    $_SESSION['permissions'] = fetch_user_permissions($_SESSION['role_id'], $dbConnection);
}

// Add this to config.php or a helper file
function has_permission($permission_name) {
    return isset($_SESSION['permissions']) && in_array($permission_name, $_SESSION['permissions']);
}

?>

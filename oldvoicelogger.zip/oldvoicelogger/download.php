<?php
// Include your config for database connection
include 'config.php';

// Check if batch download is requested (via POST)
if (isset($_POST['selected_files'])) {
    $selected_files = json_decode($_POST['selected_files'], true);
    
    if (is_array($selected_files) && count($selected_files) > 0) {
        // Create a new Zip Archive
        $zip = new ZipArchive();
        $zip_filename = 'recordings_' . date('Ymd_His') . '.zip';
        $zip_filepath = '/tmp/' . $zip_filename;

        if ($zip->open($zip_filepath, ZipArchive::CREATE) !== true) {
            exit("Unable to create zip file");
        }

        // Loop through each selected file and add it to the zip
        foreach ($selected_files as $filename) {
            $decoded_filename = urldecode($filename);
            $filepath = '/var/www/recordings/files/' . $decoded_filename;

            if (file_exists($filepath)) {
                $zip->addFile($filepath, basename($decoded_filename));
            }
        }

        // Close the zip archive
        $zip->close();

        // Set headers to download the zip file
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zip_filename) . '"');
        header('Content-Length: ' . filesize($zip_filepath));
        readfile($zip_filepath);

        // Delete the zip file after download
        unlink($zip_filepath);
        exit;
    } else {
        echo "No files selected for download!";
        exit;
    }
}

// Check if single file download is requested (via GET)
if (isset($_GET['file'])) {
    $filename = urldecode($_GET['file']); // Get the file name from the URL
    $filepath = '/var/www/recordings/files/' . $filename;

    // Check if the file exists
    if (file_exists($filepath)) {
        // Set headers to initiate file download
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
    } else {
        echo "File not found!";
    }
} else {
    echo "No file specified!";
}
?>

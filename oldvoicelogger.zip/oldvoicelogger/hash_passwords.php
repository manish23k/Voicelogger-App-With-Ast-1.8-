<?php
include 'config.php';

// Retrieve all users
$result = $conn->query('SELECT id, username, password FROM users');

while ($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $username = $row['username'];
    $plain_password = $row['password'];
    
    // Hash the plain text password
    $hashed_password = password_hash($plain_password, PASSWORD_DEFAULT);

    // Update the password in the database
    if ($stmt = $conn->prepare('UPDATE users SET password = ? WHERE id = ?')) {
        $stmt->bind_param('si', $hashed_password, $id);
        $stmt->execute();
        $stmt->close();
    } else {
        echo 'Database error: unable to prepare statement. ' . $conn->error;
    }
}

$conn->close();
echo 'Passwords updated successfully.';
?>

<?php
include 'config.php'; // Include your database configuration
include 'header.php'; // Include header for menus and other common elements

// Handle shutdown and reboot actions
$shutdown_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action == 'shutdown') {
            // Execute shutdown command
            $output = shell_exec('sudo /sbin/shutdown -h now');
            $shutdown_message = 'The server is shutting down!';
        } elseif ($action == 'reboot') {
            // Execute reboot command
            $output = shell_exec('sudo /sbin/reboot');
            $shutdown_message = 'The server is rebooting!';
        }
    }
}
?>

<div class="container mt-5">
    <h2>Shutdown and Reboot Server</h2>
    <?php if ($shutdown_message) { ?>
        <div class="alert alert-success"><?php echo $shutdown_message; ?></div>
    <?php } ?>

    <div class="d-flex justify-content-around mt-4">
        <form method="post" action="shutdown.php" class="text-center">
            <input type="hidden" name="action" value="shutdown">
            <button type="submit" class="btn btn-danger btn-lg" onclick="return confirm('Are you sure you want to shutdown the server?');">Shutdown Server</button>
        </form>

        <form method="post" action="shutdown.php" class="text-center">
            <input type="hidden" name="action" value="reboot">
            <button type="submit" class="btn btn-warning btn-lg" onclick="return confirm('Are you sure you want to reboot the server?');">Reboot Server</button>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>

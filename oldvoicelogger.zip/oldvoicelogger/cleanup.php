<?php
session_start();
include 'config.php'; // Include your database configuration

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['days'])) {
    $days = (int)$_POST['days'];
    $cutoff_date = date('Y-m-d H:i:s', strtotime("-$days days"));

    // Get the list of recordings to delete
    $query = "SELECT Filename, StartTime FROM calldetails WHERE StartTime < ?";
    $stmt = $dbConnection->prepare($query);
    $stmt->bind_param("s", $cutoff_date);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $filename = $row['Filename'];
        $recording_path = "/var/www/recordings/files/" . date('Y/m/d', strtotime($row['StartTime'])) . "/" . $filename;

        // Delete the file from the filesystem
        if (file_exists($recording_path)) {
            unlink($recording_path);
        }
    }

    // Delete records from the database
    $delete_query = "DELETE FROM calldetails WHERE StartTime < ?";
    $delete_stmt = $dbConnection->prepare($delete_query);
    $delete_stmt->bind_param("s", $cutoff_date);
    $delete_stmt->execute();

    // Provide feedback to the user
    $message = "Successfully deleted recordings older than $days days.";
}

include 'header.php'; // Include header
?>

<div class="container mt-5">
    <h2>Scheduled Call Recordings Cleanup</h2>
    <?php if (!empty($message)) { ?>
        <div class="alert alert-success"><?php echo $message; ?></div>
    <?php } ?>

    <form method="post" action="cleanup.php">
        <div class="mb-3">
            <label for="days" class="form-label">Enter Number of Days</label>
            <input type="number" name="days" class="form-control" id="days" placeholder="E.g. 30" min="1" required>
        </div>
        <button type="submit" class="btn btn-danger">Delete Old Recordings</button>
    </form>
</div>

<?php include 'footer.php'; ?>

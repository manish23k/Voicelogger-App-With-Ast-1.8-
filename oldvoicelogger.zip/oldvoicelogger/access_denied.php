<?php include 'header.php'; ?>
<div class="alert alert-danger mt-5">
    <h4>Access Denied!</h4>
    <p>You do not have permission to view this page.</p>
</div>
<?php include 'footer.php'; ?>

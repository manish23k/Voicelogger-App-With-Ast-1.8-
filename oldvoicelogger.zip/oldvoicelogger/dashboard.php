<?php
// Start session if not already started
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}

include 'config.php'; // Include your database configuration
include 'header.php'; // Include header for menus and other common elements

$manage_landing_error = '';
$manage_landing_success = '';


// Handle Manager's Extension Input
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['manager_extension'])) {
        $_SESSION['manager_extension'] = trim($_POST['manager_extension']);
    }
}

$manager_extension = isset($_SESSION['manager_extension']) ? $_SESSION['manager_extension'] : '';

// Fetch call statistics from the calldetails table
$incomingCalls = 0;
$outgoingCalls = 0;
$missedCalls = 0;
$noAnswerCalls = 0;
$totalCalls = 0;

$result = $dbConnection->query('SELECT Type, COUNT(*) as Count FROM calldetails GROUP BY Type');
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $totalCalls += $row['Count'];
        switch (strtolower($row['Type'])) {
            case 'incoming':
                $incomingCalls = $row['Count'];
                break;
            case 'outgoing':
                $outgoingCalls = $row['Count'];
                break;
            case 'missed':
                $missedCalls = $row['Count'];
                break;
            case 'noanswer':
                $noAnswerCalls = $row['Count'];
                break;
        }
    }
} else {
    $manage_landing_error = 'Error fetching call statistics: ' . $dbConnection->error;
}

?>

<div class="container mt-5">
    <h2>Dashboard</h2>
    <?php if ($manage_landing_success) { ?>
        <div class="alert alert-success"><?php echo $manage_landing_success; ?></div>
    <?php } elseif ($manage_landing_error) { ?>
        <div class="alert alert-danger"><?php echo $manage_landing_error; ?></div>
    <?php } ?>

    <!-- Tabs for switching between Call Statistics, Live Calls, and Linux Storage -->
    <div class="container mt-5">
        <!-- <h2>Dashboard</h2> -->

        <!-- Tabs for switching between Call Statistics, Live Calls, and Linux Storage -->
        <ul class="nav nav-pills mb-3" id="dashboardTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="call-stats-tab" data-bs-toggle="tab" data-bs-target="#call-stats" type="button" role="tab" aria-controls="call-stats" aria-selected="true">
                    Call Statistics
                </button>
            </li>
            <!-- <li class="nav-item" role="presentation">
                <button class="nav-link" id="live-calls-tab" data-bs-toggle="tab" data-bs-target="#live-calls" type="button" role="tab" aria-controls="live-calls" aria-selected="false">
                    Live Calls
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="linux-storage-tab" data-bs-toggle="tab" data-bs-target="#linux-storage" type="button" role="tab" aria-controls="linux-storage" aria-selected="false">
                    Linux Storage
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="sip-trunk-tab" data-bs-toggle="tab" data-bs-target="#sip-trunk" type="button" role="tab" aria-controls="sip-trunk" aria-selected="false">
                    SIP Trunk Status
                </button>
            </li> -->

        </ul>
        <div class="tab-content" id="dashboardTabsContent">
            <!-- Call Statistics Tab -->
            <div class="tab-pane fade show active" id="call-stats" role="tabpanel" aria-labelledby="call-stats-tab">
                <!-- Date Filters -->
                <div class="row mt-4">
                    <div class="col-md-5">
                        <label for="start-date">Start Date:</label>
                        <input type="date" id="start-date" class="form-control">
                    </div>
                    <div class="col-md-5">
                        <label for="end-date">End Date:</label>
                        <input type="date" id="end-date" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-primary mt-4" id="filter-btn">FILTER</button>
                    </div>
                </div>

                <!-- Call Statistics -->
                <div class="row mt-4">
                    <div class="col-md-2">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="mdi mdi-phone-incoming-outline mdi-36px"></i>
                                <h4><?php echo $incomingCalls; ?></h4>
                                <p>Incoming Calls</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="mdi mdi-phone-outgoing-outline mdi-36px"></i>
                                <h4><?php echo $outgoingCalls; ?></h4>
                                <p>Outgoing Calls</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="mdi mdi-phone-missed-outline mdi-36px"></i>
                                <h4><?php echo $missedCalls; ?></h4>
                                <p>Missed Calls</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="mdi mdi-phone-cancel-outline mdi-36px"></i>
                                <h4><?php echo $noAnswerCalls; ?></h4>
                                <p>No Answer</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="mdi mdi-phone-classic mdi-36px"></i>
                                <h4><?php echo $totalCalls; ?></h4>
                                <p>Total Calls</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Graphs -->
                <div class="row mt-4">
                    <div class="col-md-6">
                        <canvas id="pieChart" width="300" height="300"></canvas> <!-- Adjusted size -->
                    </div>
                    <div class="col-md-6">
                        <canvas id="barChart" width="300" height="300"></canvas> <!-- Adjusted size -->
                    </div>
                </div>
            </div>

            <!-- Live Calls Tab -->
            <div class="tab-pane fade" id="live-calls" role="tabpanel" aria-labelledby="live-calls-tab">
                <h4 class="mt-4">Live Calls</h4>

                <!-- Add Refresh Interval and Extension Input -->
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="manager-extension">Enter Your Extension to Listen Calls:</label>
                        <input type="text" class="form-control" id="manager-extension" value="<?php echo isset($_SESSION['manager_extension']) ? $_SESSION['manager_extension'] : ''; ?>">
                        <button class="btn btn-primary mt-2" onclick="saveExtension()">SAVE EXTENSION</button>
                    </div>
                    <div class="col-md-6">
                        <label for="refresh-interval">Refresh Interval (seconds):</label>
                        <input type="number" id="refresh-interval" min="5" class="form-control mb-3" style="width: 150px;">
                        <button class="btn btn-primary" onclick="startAutoRefresh()">Start Auto Refresh</button>
                    </div>
                </div>

                <div id="live-calls-content">
                    <!-- Live call content loaded via AJAX -->
                    <p>No live calls currently.</p>
                </div>
            </div>

            <!-- Linux Storage Tab -->
            <div class="tab-pane fade" id="linux-storage" role="tabpanel" aria-labelledby="linux-storage-tab">
                <h4 class="mt-4">Linux Storage Information</h4>
                <div id="linux-storage-content">
                    <?php
                    // Fetch Linux storage information
                    $dfOutput = shell_exec('df -h');
                    $storageData = [];

                    if ($dfOutput) {
                        $dfLines = explode("\n", trim($dfOutput));
                        echo '<table class="table table-bordered"><thead><tr><th>Filesystem</th><th>Size</th><th>Used</th><th>Avail</th><th>Use%</th><th>Mounted on</th></tr></thead><tbody>';
                        foreach ($dfLines as $index => $line) {
                            if ($index == 0) continue; // Skip the header line
                            $columns = preg_split('/\s+/', $line);
                            echo '<tr>';
                            foreach ($columns as $column) {
                                echo '<td>' . htmlspecialchars($column) . '</td>';
                            }
                            echo '</tr>';

                            // Store data for pie chart, ensure the values are numeric for processing
                            if (count($columns) >= 6) {
                                $size = rtrim($columns[1], 'G'); // Remove 'G' to get the size as a numeric value
                                $used = rtrim($columns[2], 'G'); // Used space in GB
                                $available = rtrim($columns[3], 'G'); // Available space in GB

                                // Check if numeric to avoid errors
                                if (is_numeric($size) && is_numeric($used)) {
                                    $free = (float)$size - (float)$used;
                                    $storageData[] = [
                                        'filesystem' => $columns[0],
                                        'used' => (float)$used,
                                        'free' => (float)$free, // Calculated free space
                                    ];
                                }
                            }
                        }
                        echo '</tbody></table>';
                    } else {
                        echo '<p>Unable to fetch storage information.</p>';
                    }
                    ?>
                    <div class="row mt-4">
                        <div class="col-md-6"> <!-- Adjusted size of the canvas container -->
                            <canvas id="storageChart" width="300" height="300"></canvas>
                        </div>
                    </div>
                </div>
            </div>

                        <!-- SIP Trunk Status Tab -->
                        <div class="tab-pane fade" id="sip-trunk" role="tabpanel" aria-labelledby="sip-trunk-tab">
                <h4 class="mt-4">SIP Trunk Status</h4>
                <div id="sip-trunk-status-content">
                    <p>Loading SIP Trunk Status...</p>
                </div>
            </div>
    </div>

</div>
</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    function drawCallCharts() {
        var ctxPie = document.getElementById('pieChart').getContext('2d');
        var ctxBar = document.getElementById('barChart').getContext('2d');

        // Pie chart for call distribution
        new Chart(ctxPie, {
            type: 'pie',
            data: {
                labels: ['Missed Calls', 'No Answer Calls', 'Incoming Calls', 'Outgoing Calls'],
                datasets: [{
                    data: [<?php echo $missedCalls; ?>, <?php echo $noAnswerCalls; ?>, <?php echo $incomingCalls; ?>, <?php echo $outgoingCalls; ?>],
                    backgroundColor: ['#FF6384', '#FFCD56', '#36A2EB', '#4BC0C0'],
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        // Bar chart for call statistics
        new Chart(ctxBar, {
            type: 'bar',
            data: {
                labels: ['Missed Calls', 'No Answer Calls', 'Incoming Calls', 'Outgoing Calls'],
                datasets: [{
                    label: 'Call Type Statistics',
                    data: [<?php echo $missedCalls; ?>, <?php echo $noAnswerCalls; ?>, <?php echo $incomingCalls; ?>, <?php echo $outgoingCalls; ?>],
                    backgroundColor: ['#FF6384', '#FFCD56', '#36A2EB', '#4BC0C0'],
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        drawCallCharts(); // Ensure the charts are drawn when the page is loaded
    });


function drawStorageChart() {
    var ctxStorage = document.getElementById('storageChart').getContext('2d');

    var storageLabels = <?php echo json_encode(array_column($storageData, 'filesystem')); ?>;
    var storageUsed = <?php echo json_encode(array_column($storageData, 'used')); ?>;
    var storageFree = <?php echo json_encode(array_column($storageData, 'free')); ?>;

    // Prepare data with both used and free space for each filesystem
    var datasets = [];
    for (var i = 0; i < storageLabels.length; i++) {
        datasets.push({
            label: storageLabels[i],
            data: [storageUsed[i], storageFree[i]],  // Used and free space for each partition
            backgroundColor: ['#FF6384', '#4BC0C0'],  // Colors for used and free space
            borderColor: '#fff',
            borderWidth: 2
        });
    }

    // Combine used and free space into one dataset for pie chart
    new Chart(ctxStorage, {
        type: 'pie',
        data: {
            labels: ['Used Space', 'Free Space'],
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function(tooltipItem) {
                            return tooltipItem.label + ': ' + tooltipItem.raw + ' GB';
                        }
                    }
                }
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    drawStorageChart(); // Ensure storage chart is drawn when the page is loaded
});





    // Live Calls Tab Click Event
    function fetchLiveCalls() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'fetch_live_calls.php', true);
        xhr.onload = function() {
            if (xhr.status === 200) {
                document.getElementById('live-calls-content').innerHTML = xhr.responseText;
            } else {
                document.getElementById('live-calls-content').innerHTML = 'Error loading live calls.';
            }
        };
        xhr.onerror = function() {
            console.error("An error occurred while loading live calls");
        };
        xhr.send();
    }

    // Function to save manager extension in session
    function saveExtension() {
        var extension = document.getElementById('manager-extension').value;
        if (extension) {
            // Store extension in session via AJAX
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'save_extension.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (xhr.status === 200) {
                    alert('Extension saved successfully.');
                }
            };
            xhr.send('extension=' + encodeURIComponent(extension));
        }
    }

    // Auto-refresh live calls
    var autoRefreshInterval;

    function startAutoRefresh() {
        var interval = parseInt(document.getElementById('refresh-interval').value) * 1000;

        if (isNaN(interval) || interval < 5000) {
            alert('Please enter a valid refresh interval of at least 5 seconds.');
            return;
        }

        clearInterval(autoRefreshInterval); // Clear any existing interval
        fetchLiveCalls(); // Fetch live calls immediately
        autoRefreshInterval = setInterval(fetchLiveCalls, interval); // Set auto-refresh interval
    }

// SIP Trunk Status Tab Click Event
document.getElementById('sip-trunk-tab').addEventListener('click', function() {
    fetchSipTrunkStatus();
});

// Live Calls Tab Click Event
document.getElementById('live-calls-tab').addEventListener('click', function() {
    fetchLiveCalls(); // Example function for fetching live calls
});

// Function to fetch SIP Trunk status via AJAX
function fetchSipTrunkStatus() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'fetch_sip_trunk_status.php', true); // Your fetch SIP trunk status PHP file
    xhr.onload = function() {
        if (xhr.status === 200) {
            document.getElementById('sip-trunk-status-content').innerHTML = xhr.responseText;
        } else {
            document.getElementById('sip-trunk-status-content').innerHTML = 'Error loading SIP trunk status.';
        }
    };
    xhr.onerror = function() {
        document.getElementById('sip-trunk-status-content').innerHTML = 'Error loading SIP trunk status.';
    };
    xhr.send();
}
</script>
<?php include 'footer.php'; ?>


<?php
// Start session if not already started
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}
include 'config.php'; // Include your database configuration

// Turn off error reporting during CSV export to prevent output
if (!isset($_POST['export_csv'])) {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(E_ALL);
} else {
    error_reporting(0); // Disable output when exporting CSV
}

// Initialize variables
$call_type = $start_date = $end_date = $start_time = $end_time = $client_id = $client_name = $comments = $extensions = $phone = $pbx_ext = $call_tag = '';
$filter_query = '';
$manage_call_error = '';
$manage_call_success = '';
$limit = 10; // Number of records per page
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1; // Current page number
$offset = ($page - 1) * $limit; // Calculate the offset for SQL query

// Fetch user extension group from session
$extension_group = $_SESSION['extension_group'] ?? 'ALL';
$user_extensions = []; // To store extensions based on the group

// Check user's extension group and modify the query accordingly
if ($extension_group === 'SELF') {
    // If 'SELF', the user can only view calls of their own extension
    $user_extension = $_SESSION['user_extension'] ?? ''; 
    $filter_query .= " AND calldetails.Extension = '$user_extension'";
} elseif ($extension_group === 'GROUP') {
    // If 'GROUP', the user can view calls of extensions in the group
    $group_extensions = $_SESSION['group_extensions'] ?? [];
    if (!empty($group_extensions)) {
        $extensions_list = implode("','", $group_extensions); // Sanitize for SQL
        $filter_query .= " AND calldetails.Extension IN ('$extensions_list')";
    } else {
        // If no group extensions are found, return no results
        $filter_query .= " AND 1=0"; // Return no results
    }
} elseif ($extension_group === 'ALL') {
    // If 'ALL', no need to filter by extension
    $filter_query .= ""; // No additional filter for extensions
}

// Handle form submissions for filtering
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Initialize variables
    $call_type = isset($_POST['call_type']) ? trim($_POST['call_type']) : '';
    $start_date = isset($_POST['start_date']) ? trim($_POST['start_date']) : '';
    $end_date = isset($_POST['end_date']) ? trim($_POST['end_date']) : '';
    $start_time = isset($_POST['start_time']) ? trim($_POST['start_time']) : '';
    $end_time = isset($_POST['end_time']) ? trim($_POST['end_time']) : '';
    $client_id = isset($_POST['client_id']) ? trim($_POST['client_id']) : '';
    $client_name = isset($_POST['client_name']) ? trim($_POST['client_name']) : '';
    $comments = isset($_POST['comments']) ? trim($_POST['comments']) : '';
    $extensions = isset($_POST['extensions']) ? trim($_POST['extensions']) : '';
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $pbx_ext = isset($_POST['pbx_ext']) ? trim($_POST['pbx_ext']) : '';
    $call_tag = isset($_POST['call_tag']) ? trim($_POST['call_tag']) : '';

    // Build filter query
    if (!empty($call_type)) {
        $filter_query .= " AND calldetails.Type = '$call_type'";
    }
    if (!empty($start_date) && !empty($end_date)) {
        $filter_query .= " AND calldetails.Date BETWEEN '$start_date' AND '$end_date'";
    }
    if (!empty($start_time) && !empty($end_time)) {
        $filter_query .= " AND calldetails.StartTime BETWEEN '$start_time' AND '$end_time'";
    }
    if (!empty($client_id)) {
        $filter_query .= " AND contacts.CustId = '$client_id'";
    }
    if (!empty($client_name)) {
        $filter_query .= " AND contacts.CustName = '$client_name'";
    }
    if (!empty($comments)) {
        $filter_query .= " AND call_tags.comment LIKE '%$comments%'";
    }
    if (!empty($extensions)) {
        $filter_query .= " AND calldetails.Extension LIKE '%$extensions%'";
    }
    if (!empty($phone)) {
        $filter_query .= " AND calldetails.PhoneNumber LIKE '%$phone%'";
    }
    if (!empty($pbx_ext)) {
        $filter_query .= " AND calldetails.pbxextn LIKE '%$pbx_ext%'";
    }
    if (!empty($call_tag)) {
        $filter_query .= " AND call_tags.tag LIKE '%$call_tag%'";
    }
}

// Build the total count query with all filters
$total_count_query = "
SELECT COUNT(*) as total
FROM calldetails
LEFT JOIN contacts ON (
    SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.PhoneNumber, -10)
    OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.MobileNumber, -10)
    OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternatePhoneNumber, -10)
    OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternateMobileNumber, -10)
)
" . (!empty($call_tag) || !empty($comments) ? " LEFT JOIN call_tags ON calldetails.callidpk = call_tags.call_id" : "") . "
WHERE 1=1 $filter_query";

$total_count_result = $dbConnection->query($total_count_query);

// Check if the query executed successfully
if (!$total_count_result) {
    die('SQL Error (total count): ' . $dbConnection->error . " | Query: " . $total_count_query);
}

$total_count_row = $total_count_result->fetch_assoc();
$total_count = $total_count_row['total'];


// Fetch call details with pagination
$query = "
    SELECT calldetails.*, 
           DATE(calldetails.StartTime) AS Date, 
           TIME(calldetails.StartTime) AS Time,
           CASE 
               WHEN LENGTH(calldetails.PhoneNumber) >= 10 
               AND (
                   SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.PhoneNumber, -10)
                   OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.MobileNumber, -10)
                   OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternatePhoneNumber, -10)
                   OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternateMobileNumber, -10)
               )
               THEN contacts.CustName
               ELSE ''  -- Empty if no match or not a valid phone number
           END AS ClientName,
           contacts.CustId AS ClientID,
           call_tags.tag AS CallTag,
           call_tags.comment AS CallComment
    FROM calldetails
    LEFT JOIN contacts
    ON LENGTH(calldetails.PhoneNumber) >= 10
    AND (
        SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.PhoneNumber, -10)
        OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.MobileNumber, -10)
        OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternatePhoneNumber, -10)
        OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternateMobileNumber, -10)
    )
    LEFT JOIN call_tags
    ON calldetails.callidpk = call_tags.call_id
    WHERE 1=1 $filter_query
    ORDER BY calldetails.StartTime DESC 
    LIMIT $limit OFFSET $offset
";

// Check if the query executed successfully
$result = $dbConnection->query($query);
if (!$result) {
    // If the query failed, print the error
    die('SQL Error (fetch call details): ' . $dbConnection->error . " | Query: " . $query);
}


// Fetch call summary counts
$summary_query = "
SELECT 
    SUM(CASE WHEN calldetails.Type = 'Incoming' THEN 1 ELSE 0 END) AS Incoming,
    SUM(CASE WHEN calldetails.Type = 'Outgoing' THEN 1 ELSE 0 END) AS Outgoing,
    SUM(CASE WHEN calldetails.Type = 'Missed' THEN 1 ELSE 0 END) AS Missed,
    SUM(CASE WHEN calldetails.Type = 'NoAnswer' THEN 1 ELSE 0 END) AS NoAnswer,
    COUNT(*) AS TotalCalls
FROM calldetails
LEFT JOIN contacts ON (
    SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.PhoneNumber, -10)
    OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.MobileNumber, -10)
    OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternatePhoneNumber, -10)
    OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternateMobileNumber, -10)
)
" . (!empty($call_tag) || !empty($comments) ? " LEFT JOIN call_tags ON calldetails.callidpk = call_tags.call_id" : "") . "
WHERE 1=1 $filter_query";

// Execute the query
$summary_result = $dbConnection->query($summary_query);

if (!$summary_result) {
    die('SQL Error (call summary): ' . $dbConnection->error . " | Query: " . $summary_query);
}

$counts = $summary_result->fetch_assoc();


// CSV Export
if (isset($_POST['export_csv']) && $_POST['export_csv'] == 1) {

    // Turn off error reporting to avoid any output before CSV headers
    error_reporting(0);

    // Get the current date and time in the desired format
    $timestamp = date('Ymd_His');
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="call_logs_' . $timestamp . '.csv"');

    // Output CSV header
    $output = fopen('php://output', 'w');
    fputcsv($output, ["PBX Ext", "Extension", "Phone Number", "Date", "Time", "Duration", "Call Type", "Tag", "Comment", "Recording Link", "Client Name"]);

    // Fetch call details for CSV without limit
    $csv_query = "
        SELECT calldetails.*, 
               DATE(calldetails.StartTime) AS Date, 
               TIME(calldetails.StartTime) AS Time,
               contacts.CustName AS ClientName,
               contacts.CustId AS ClientID,
               call_tags.tag AS CallTag,
               call_tags.comment AS CallComment
        FROM calldetails
        LEFT JOIN contacts
        ON (
            SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.PhoneNumber, -10)
            OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.MobileNumber, -10)
            OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternatePhoneNumber, -10)
            OR SUBSTRING(calldetails.PhoneNumber, -10) = SUBSTRING(contacts.AlternateMobileNumber, -10)
        )
        LEFT JOIN call_tags
        ON calldetails.callidpk = call_tags.call_id
        WHERE 1=1 $filter_query
        ORDER BY calldetails.StartTime DESC
    ";

    $csv_result = $dbConnection->query($csv_query);

    while ($row = $csv_result->fetch_assoc()) {
        $filename = $row['Filename'];
        $recording_url = "https://192.168.0.201/RECORDINGS/$filename";
        fputcsv($output, [
            $row['pbxextn'],
            $row['Extension'],
            $row['PhoneNumber'],
            $row['Date'],
            $row['Time'],
            gmdate('H:i:s', strtotime($row['EndTime']) - strtotime($row['StartTime'])),
            $row['Type'],
            $row['CallTag'],
            $row['CallComment'],
            $recording_url,
            $row['ClientName']
        ]);
    }
    fclose($output);
    exit;
}


include 'header.php'; // Move this after the CSV logic to avoid sending HTML before headers

?>
<style>
    .audio-player {
        width: 200px;
        /* Set initial width */
        transition: width 0.3s ease-in-out;
    }

    .audio-player.expanded {
        width: 600px;
        /* Width when expanded */
    }
</style>
<div class="container mt-5">
    <h2>Manage Call Records</h2>
    <?php if ($manage_call_success) { ?>
        <div class="alert alert-success"><?php echo $manage_call_success; ?></div>
    <?php } elseif ($manage_call_error) { ?>
        <div class="alert alert-danger"><?php echo $manage_call_error; ?></div>
    <?php } ?>

    <!-- Filter Section -->
    <h4>Filter Calls</h4>
    <form method="post" action="calls.php">
        <div class="row">
            <div class="col-md-3">
                <label for="call_type" class="form-label">Call Type</label>
                <select class="form-control" id="call_type" name="call_type">
                    <option value="">All</option>
                    <option value="incoming" <?php if ($call_type == 'incoming')
                        echo 'selected'; ?>>Incoming</option>
                    <option value="outgoing" <?php if ($call_type == 'outgoing')
                        echo 'selected'; ?>>Outgoing</option>
                    <option value="missed" <?php if ($call_type == 'missed')
                        echo 'selected'; ?>>Missed</option>
                    <option value="no answer" <?php if ($call_type == 'no answer')
                        echo 'selected'; ?>>No Answer</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="start_date" class="form-label">Date From</label>
                <input type="date" class="form-control" id="start_date" name="start_date"
                    value="<?php echo htmlspecialchars($start_date); ?>">
            </div>
            <div class="col-md-3">
                <label for="end_date" class="form-label">Date To</label>
                <input type="date" class="form-control" id="end_date" name="end_date"
                    value="<?php echo htmlspecialchars($end_date); ?>">
            </div>
            <div class="col-md-3">
                <label for="start_time" class="form-label">Time From (HH:MM:SS)</label>
                <input type="time" class="form-control" id="start_time" name="start_time"
                    value="<?php echo htmlspecialchars($start_time); ?>">
            </div>
            <div class="col-md-3">
                <label for="end_time" class="form-label">Time To (HH:MM:SS)</label>
                <input type="time" class="form-control" id="end_time" name="end_time"
                    value="<?php echo htmlspecialchars($end_time); ?>">
            </div>
            <div class="col-md-3">
                <label for="client_id" class="form-label">Client ID</label>
                <input type="text" class="form-control" id="client_id" name="client_id"
                    value="<?php echo htmlspecialchars($client_id); ?>">
            </div>
            <div class="col-md-3">
                <label for="client_name" class="form-label">Client Name</label>
                <input type="text" class="form-control" id="client_name" name="client_name"
                    value="<?php echo htmlspecialchars($client_name); ?>">
            </div>
            <div class="col-md-3">
                <label for="call_tag" class="form-label">Call Tag</label>
                <input type="text" class="form-control" id="call_tag" name="call_tag"
                    value="<?php echo htmlspecialchars($call_tag); ?>">
            </div>
            <div class="col-md-3">
                <label for="comments" class="form-label">Comments</label>
                <input type="text" class="form-control" id="comments" name="comments"
                    value="<?php echo htmlspecialchars($comments); ?>">
            </div>
            <div class="col-md-3">
                <label for="extensions" class="form-label">Extensions</label>
                <input type="text" class="form-control" id="extensions" name="extensions"
                    value="<?php echo htmlspecialchars($extensions); ?>">
            </div>
            <div class="col-md-3">
                <label for="phone" class="form-label">Phone Num.</label>
                <input type="text" class="form-control" id="phone" name="phone"
                    value="<?php echo htmlspecialchars($phone); ?>">
            </div>
            <div class="col-md-3">
                <label for="pbx_ext" class="form-label">PBX Ext</label>
                <input type="text" class="form-control" id="pbx_ext" name="pbx_ext"
                    value="<?php echo htmlspecialchars($pbx_ext); ?>">
            </div>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Search</button>
        <button type="reset" class="btn btn-secondary mt-3">Clear</button>
    </form>

    <!-- Calls Summary Section -->
    <div class="container mt-5">
        <h5 class="card-header">Calls Summary</h5>
        <table class="table table-bordered text-center mb-4">
            <thead>
                <tr>
                    <th>
                        <i class="mdi mdi-phone-incoming mdi-24px"></i><br>
                        INCOMING<br><?php echo htmlspecialchars($counts['Incoming'] ?? 0); ?>
                    </th>
                    <th>
                        <i class="mdi mdi-phone-outgoing mdi-24px"></i><br>
                        OUTGOING<br><?php echo htmlspecialchars($counts['Outgoing'] ?? 0); ?>
                    </th>
                    <th>
                        <i class="mdi mdi-phone-missed mdi-24px"></i><br>
                        MISSED<br><?php echo htmlspecialchars($counts['Missed'] ?? 0); ?>
                    </th>
                    <th>
                        <i class="mdi mdi-phone-cancel mdi-24px"></i><br>
                        NO ANSWER<br><?php echo htmlspecialchars($counts['NoAnswer'] ?? 0); ?>
                    </th>
                    <th>
                        <i class="mdi mdi-phone mdi-24px"></i><br>
                        TOTAL CALLS<br><?php echo htmlspecialchars($counts['TotalCalls'] ?? 0); ?>
                    </th>
                </tr>
            </thead>
        </table>
    </div>


    <!-- Icon for CSV Export on Top Right -->
    <?php if (has_permission('export_csv')): ?>
    <div class="d-flex justify-content-end p-2">
        <form method="post" action="calls.php">
            <input type="hidden" name="export_csv" value="1">
            <button type="submit" class="btn btn-outline-success" title="Export to CSV">
                <i class="fas fa-download"></i> Export CSV
            </button>
        </form>
    </div>
    <?php endif; ?>

    <!-- Icons for Select All, Multiple Download, and Delete -->
    <div class="d-flex justify-content-start p-2">
        <input type="checkbox" id="select-all" title="Select All">
        <?php if (has_permission('batch_download_recordings')): ?>
        <button type="button" class="btn btn-outline-primary btn-sm" id="download-selected" title="Bulk Download Selected">
            <i class="mdi mdi-download-multiple mdi-24px"></i>
        </button>
        <?php endif; ?>
        <?php if (has_permission('batch_delete_recordings')): ?>
        <button type="button" class="btn btn-outline-danger btn-sm" id="delete-selected" title="Bulk Delete Selected">
            <i class="mdi mdi-delete mdi-24px"></i>
        </button>
        <?php endif; ?>
    </div>
    <!-- Records Table -->
    <div class="card">
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead class="table-dark">
                    <tr>
                        <th>Select</th>
                        <th>PBX Ext</th>
                        <th>Extension</th>
                        <th>Phone Number</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Duration</th>
                        <th>Call Type</th>
                        <th>Tag</th>
                        <th>Comment</th>
                        <th>Recording</th>
                        <th>Actions</th>
                        <th>Client</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) {
                        $filename = $row['Filename'];
                        $recording_file_path = "/var/www/recordings/files/$filename";
                        $file_exists = file_exists($recording_file_path);
                        $recording_url = "https://192.168.0.201/RECORDINGS/$filename";
                        ?>
                        <tr>
                            <td><input type="checkbox" class="select-row" data-call-id="<?php echo $row['callidpk']; ?>"
                                    data-file-name="<?php echo urlencode($filename); ?>"></td>
                            <td><?php echo htmlspecialchars($row['pbxextn'] ?? 'NA'); ?></td>
                            <td><?php echo htmlspecialchars($row['Extension'] ?? 'NA'); ?></td>
                            <td><?php echo htmlspecialchars($row['PhoneNumber'] ?? 'NA'); ?></td>
                            <td><?php echo htmlspecialchars($row['Date']); ?></td>
                            <td><?php echo htmlspecialchars($row['Time']); ?></td>
                            <td><?php echo htmlspecialchars(gmdate('H:i:s', strtotime($row['EndTime']) - strtotime($row['StartTime']))); ?>
                            </td>
                            <td><?php echo htmlspecialchars($row['Type']); ?></td>
                            <td><?php echo htmlspecialchars($row['CallTag'] ?? ''); ?></td>
                            <td>
                                <!-- The pencil icon to edit the comment -->
                                <?php if (has_permission('comments')): ?>
                                <a href="javascript:void(0);" class="btn btn-sm btn-warning edit-comment-btn"
                                    data-call-id="<?php echo $row['callidpk']; ?>"
                                    data-tag="<?php echo htmlspecialchars($row['CallTag']); ?>"
                                    data-comment="<?php echo htmlspecialchars($row['CallComment']); ?>">
                                    <i class="mdi mdi-pencil"></i>
                                    
                                </a>

                                <!-- Display the comment below the pencil icon -->
                                <?php if (!empty($row['CallComment'])) { ?>
                                    <div class="comment-text mt-1">
                                        <?php echo htmlspecialchars($row['CallComment']); ?>
                                    </div>
                                <?php } ?>
                                <?php endif; ?>
                            </td>

                            <td>
                            <?php if (has_permission('play_rec')): ?>
                                <?php if (!empty($row['Filename']) && $file_exists) { ?>
                                    <audio class="audio-player" controls>
                                        <source src="<?php echo $recording_url; ?>" type="audio/wav">
                                        Your browser does not support the audio tag.
                                    </audio>
                                <?php } else { ?>
                                    No Recording Found
                                <?php } ?>
                                <?php endif; ?>
                            </td>
                            <td>
                            <?php if (has_permission('download_rec')): ?>
                                <?php if (!empty($row['Filename']) && $file_exists) { ?>
                                    <a href="download.php?file=<?php echo urlencode($row['Filename']); ?>"
                                        title="Download Recording">
                                        <i class="mdi mdi-download mdi-24px"></i>
                                    </a>
                                <?php } ?>
                                <?php endif; ?>
                                <?php if (has_permission('delete')): ?>
                                <a href="delete_recording.php?call_id=<?php echo urlencode($row['callidpk']); ?>"
                                    title="Delete Recording"
                                    onclick="return confirm('Are you sure you want to delete this recording?');">
                                    <i class="mdi mdi-delete mdi-24px"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                            <td><?php echo !empty($row['ClientName']) ? htmlspecialchars($row['ClientName']) : ''; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <!-- Pagination -->
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <?php
                    $query_string = http_build_query(array_merge($_GET, [
                        'call_type' => $call_type,
                        'start_date' => $start_date,
                        'end_date' => $end_date,
                        'start_time' => $start_time,
                        'end_time' => $end_time,
                        'client_id' => $client_id,
                        'client_name' => $client_name,
                        'comments' => $comments,
                        'extensions' => $extensions,
                        'phone' => $phone,
                        'pbx_ext' => $pbx_ext,
                        'call_tag' => $call_tag,

                    ]));
                    $total_pages = ceil($total_count / $limit);
                    for ($i = 1; $i <= $total_pages; $i++) {
                        $active = ($i == $page) ? 'active' : '';
                        echo "<li class='page-item $active'><a class='page-link' href='calls.php?page=$i&$query_string'>$i</a></li>";
                    }
                    ?>
                </ul>
            </nav>
        </div>
    </div>
</div>

<!-- Modal for Tagging and Commenting -->
<div class="modal fade" id="tagCommentModal" tabindex="-1" aria-labelledby="tagCommentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tagCommentModalLabel">Add Tag and Comment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="tagCommentForm">
                    <input type="hidden" id="callId" name="call_id">
                    <div class="mb-3">
                        <label for="tag" class="form-label">Tag</label>
                        <input type="text" class="form-control" id="tag" name="tag" required>
                    </div>
                    <div class="mb-3">
                        <label for="comment" class="form-label">Comment</label>
                        <textarea class="form-control" id="comment" name="comment" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Include WaveSurfer.js library -->
<script src="https://unpkg.com/wavesurfer.js"></script>
<script>
    // Logic for WaveSurfer and handling modal for tagging/commenting
    document.addEventListener('DOMContentLoaded', function () {
        <?php while ($row = $result->fetch_assoc()) { ?>
            var wavesurfer_<?php echo $row['Filename']; ?> = WaveSurfer.create({
                container: '#waveform-<?php echo $row['Filename']; ?>',
                waveColor: '#00f',
                progressColor: '#0f0',
                height: 60
            });
            wavesurfer_<?php echo $row['Filename']; ?>.load('https://192.168.0.201/RECORDINGS/<?php echo $row['Filename']; ?>.wav');
        <?php } ?>
    });

    document.addEventListener('click', function (event) {
        if (event.target.closest('.edit-comment-btn')) {
            var button = event.target.closest('.edit-comment-btn');
            var callId = button.getAttribute('data-call-id');
            var tag = button.getAttribute('data-tag');
            var comment = button.getAttribute('data-comment');

            // Set values in the modal form
            document.getElementById('callId').value = callId;
            document.getElementById('tag').value = tag;
            document.getElementById('comment').value = comment;

            // Open the modal
            var modal = new bootstrap.Modal(document.getElementById('tagCommentModal'));
            modal.show();
        }
    });

    // Handle the form submission
    document.getElementById('tagCommentForm').addEventListener('submit', function (event) {
        event.preventDefault();
        var formData = new FormData(this);

        fetch('comments.php', {
            method: 'POST',
            body: formData
        }).then(response => response.json()).then(data => {
            if (data.success) {
                alert('Tag and comment saved successfully');
                location.reload();
            } else {
                alert('Failed to save tag and comment');
            }
        });
    });

</script>

<script>
    // Add event listeners to all audio elements
    document.querySelectorAll('.audio-player').forEach(function (audioPlayer) {
        // Expand player when clicked
        audioPlayer.addEventListener('play', function () {
            audioPlayer.classList.add('expanded');
        });

        // Shrink player when paused or ended
        audioPlayer.addEventListener('pause', function () {
            audioPlayer.classList.remove('expanded');
        });
        audioPlayer.addEventListener('ended', function () {
            audioPlayer.classList.remove('expanded');
        });
    });


    // Select All functionality
    document.getElementById('select-all').addEventListener('change', function () {
        const isChecked = this.checked;
        document.querySelectorAll('.select-row').forEach(function (checkbox) {
            checkbox.checked = isChecked;
        });
    });

    // Batch Download Selected
    document.getElementById('download-selected').addEventListener('click', function () {
        const selectedRows = document.querySelectorAll('.select-row:checked');
        if (selectedRows.length === 0) {
            alert('No recordings selected for download.');
            return;
        }

        const selectedFiles = [];
        selectedRows.forEach(function (row) {
            selectedFiles.push(row.dataset.fileName);
        });

        // Trigger batch download via form
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'download.php';  // Use existing download.php for batch download

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_files';
        input.value = JSON.stringify(selectedFiles);
        form.appendChild(input);

        document.body.appendChild(form);
        form.submit();
    });

    document.getElementById('delete-selected').addEventListener('click', function () {
        const selectedRows = document.querySelectorAll('.select-row:checked');
        if (selectedRows.length === 0) {
            alert('No recordings selected for deletion.');
            return;
        }

        if (!confirm('Are you sure you want to delete selected recordings?')) {
            return;
        }

        const selectedCallIds = [];
        selectedRows.forEach(function (row) {
            selectedCallIds.push(row.dataset.callId);
        });

        // Trigger batch delete via form
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'delete_recording.php';  // Make sure it's pointing to the correct PHP file

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_call_ids';
        input.value = JSON.stringify(selectedCallIds);
        form.appendChild(input);

        document.body.appendChild(form);
        form.submit();
    });


</script>

<?php include 'footer.php'; ?>
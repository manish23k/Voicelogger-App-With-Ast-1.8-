<?php
// Start session if not already started
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}

include 'config.php'; // Include your database configuration

// Turn off error reporting during CSV export to prevent output
if (!isset($_GET['download_csv'])) {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(E_ALL);
} else {
    error_reporting(0); // Disable output when exporting CSV
}

$manage_contact_error = '';
$manage_contact_success = '';

// Check if 'download_csv' is set
if (isset($_GET['download_csv'])) {
    // Define the file path to your sample CSV
    $csv_file_path = __DIR__ . '/sample_contacts.csv'; // Ensure this path is correct

    // Check if the file exists
    if (file_exists($csv_file_path)) {
        // Clear output buffering if active
        if (ob_get_level()) {
            ob_end_clean();
        }

        // Set headers to initiate file download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="sample_contacts.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');

        // Read and output the file content
        readfile($csv_file_path);
    } else {
        // If the file is not found, display an error
        echo 'Sample CSV file not found.';
    }

    exit; // Stop further script execution after CSV is output
}

include 'header.php'; // Include header for menus and other common elements


// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action == 'add') {
            // Add Contact
            $custName = trim($_POST['custName']);
            $phoneNumber = trim($_POST['phoneNumber']);
            $mobileNumber = trim($_POST['mobileNumber']);
            $alternatePhoneNumber = trim($_POST['alternatePhoneNumber']);
            $company = trim($_POST['company']);
            $alternateMobileNumber = trim($_POST['alternateMobileNumber']);
            $address = trim($_POST['address']);
            $custId = trim($_POST['custId']);

            $stmt = $dbConnection->prepare('INSERT INTO contacts (CustName, PhoneNumber, MobileNumber, AlternatePhoneNumber, Company, AlternateMobileNumber, Address, CustId) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->bind_param('sssssssi', $custName, $phoneNumber, $mobileNumber, $alternatePhoneNumber, $company, $alternateMobileNumber, $address, $custId);

            if ($stmt->execute()) {
                $manage_contact_success = 'Contact added successfully!';
            } else {
                $manage_contact_error = 'Error adding contact: ' . $dbConnection->error;
            }

            $stmt->close();

        } elseif ($action == 'edit') {
            // Edit Contact
            $contactId = (int)$_POST['contactId'];
            $custName = trim($_POST['custName']);
            $phoneNumber = trim($_POST['phoneNumber']);
            $mobileNumber = trim($_POST['mobileNumber']);
            $alternatePhoneNumber = trim($_POST['alternatePhoneNumber']);
            $company = trim($_POST['company']);
            $alternateMobileNumber = trim($_POST['alternateMobileNumber']);
            $address = trim($_POST['address']);
            $custId = trim($_POST['custId']);

            $stmt = $dbConnection->prepare('UPDATE contacts SET CustName = ?, PhoneNumber = ?, MobileNumber = ?, AlternatePhoneNumber = ?, Company = ?, AlternateMobileNumber = ?, Address = ?, CustId = ? WHERE ContactId = ?');
            $stmt->bind_param('ssssssssi', $custName, $phoneNumber, $mobileNumber, $alternatePhoneNumber, $company, $alternateMobileNumber, $address, $custId, $contactId);

            if ($stmt->execute()) {
                $manage_contact_success = 'Contact updated successfully!';
            } else {
                $manage_contact_error = 'Error updating contact: ' . $dbConnection->error;
            }

            $stmt->close();

        } elseif ($action == 'delete') {
            // Delete Contact
            $contactId = (int)$_POST['contactId'];

            $stmt = $dbConnection->prepare('DELETE FROM contacts WHERE ContactId = ?');
            $stmt->bind_param('i', $contactId);

            if ($stmt->execute()) {
                $manage_contact_success = 'Contact deleted successfully!';
            } else {
                $manage_contact_error = 'Error deleting contact: ' . $dbConnection->error;
            }

            $stmt->close();
        } elseif ($action == 'upload_csv') {
            // Upload CSV
            if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] == 0) {
                $csvFile = fopen($_FILES['csv_file']['tmp_name'], 'r');
                fgetcsv($csvFile); // Skip the header row

                $insertedRows = 0;
                while (($row = fgetcsv($csvFile, 1000, ",")) !== FALSE) {
                    $custName = trim($row[0]);
                    $phoneNumber = trim($row[1]);
                    $mobileNumber = trim($row[2]);
                    $alternatePhoneNumber = trim($row[3]);
                    $company = trim($row[4]);
                    $alternateMobileNumber = trim($row[5]);
                    $address = trim($row[6]);
                    $custId = trim($row[7]);

                    $stmt = $dbConnection->prepare('INSERT INTO contacts (CustName, PhoneNumber, MobileNumber, AlternatePhoneNumber, Company, AlternateMobileNumber, Address, CustId) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
                    $stmt->bind_param('ssssssss', $custName, $phoneNumber, $mobileNumber, $alternatePhoneNumber, $company, $alternateMobileNumber, $address, $custId);
                    if ($stmt->execute()) {
                        $insertedRows++;
                    }
                    $stmt->close();
                }
                fclose($csvFile);

                if ($insertedRows > 0) {
                    $manage_contact_success = "$insertedRows contacts added successfully from CSV!";
                } else {
                    $manage_contact_error = "No contacts were added. Please check your CSV file.";
                }
            } else {
                $manage_contact_error = "Error uploading CSV file.";
            }
        }
    }
}

// Fetch contacts for displaying in the list
$result = $dbConnection->query('SELECT * FROM contacts');

if (!$result) {
    die('Error fetching contact details: ' . $dbConnection->error); // Specific error message
}

?>

<div class="container mt-5">
    
    <h2>Manage Contacts</h2>
    <?php if ($manage_contact_success) { ?>
        <div class="alert alert-success"><?php echo $manage_contact_success; ?></div>
    <?php } elseif ($manage_contact_error) { ?>
        <div class="alert alert-danger"><?php echo $manage_contact_error; ?></div>
    <?php } ?>

    <!-- Button to trigger Add Contact modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addContactModal">Add Contact</button>
    
    <!-- Button to trigger Upload CSV modal -->
    <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#uploadCSVModal">Upload CSV</button>
    
    <!-- Button to download sample CSV -->
    <a href="contact.php?download_csv=true" class="btn btn-info">Download Sample CSV</a>


    <!-- Contact List -->
    <h4 class="mt-5">Contacts</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Cust Name</th>
                <th>Phone Number</th>
                <th>Mobile Number</th>
                <th>Alternate Phone Number</th>
                <th>Company</th>
                <th>Alternate Mobile Number</th>
                <th>Address</th>
                <th>Cust Id</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['CustName']); ?></td>
                    <td><?php echo htmlspecialchars($row['PhoneNumber']); ?></td>
                    <td><?php echo htmlspecialchars($row['MobileNumber']); ?></td>
                    <td><?php echo htmlspecialchars($row['AlternatePhoneNumber']); ?></td>
                    <td><?php echo htmlspecialchars($row['Company']); ?></td>
                    <td><?php echo htmlspecialchars($row['AlternateMobileNumber']); ?></td>
                    <td><?php echo htmlspecialchars($row['Address']); ?></td>
                    <td><?php echo htmlspecialchars($row['CustId']); ?></td>
                    <td>
                    <?php if (has_permission('edit')): ?>
                        <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editContactModal<?php echo $row['ContactId']; ?>">Edit</button>
                        <?php endif; ?>
                        <?php if (has_permission('delete')): ?>
                        <form method="post" action="contact.php" style="display:inline-block;">
                            <input type="hidden" name="contactId" value="<?php echo htmlspecialchars($row['ContactId']); ?>">
                            <input type="hidden" name="action" value="delete">
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>

                <!-- Edit Contact Modal -->
                <div class="modal fade" id="editContactModal<?php echo $row['ContactId']; ?>" tabindex="-1" aria-labelledby="editContactModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editContactModalLabel">Edit Contact</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="contact.php">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="contactId" value="<?php echo htmlspecialchars($row['ContactId']); ?>">

                    <div class="mb-3">
                        <label for="custName" class="form-label">Cust Name</label>
                        <input type="text" class="form-control" id="custName" name="custName" value="<?php echo htmlspecialchars($row['CustName']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="phoneNumber" class="form-label">Phone Number</label>
                        <input type="text" class="form-control" id="phoneNumber" name="phoneNumber" value="<?php echo htmlspecialchars($row['PhoneNumber']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="mobileNumber" class="form-label">Mobile Number</label>
                        <input type="text" class="form-control" id="mobileNumber" name="mobileNumber" value="<?php echo htmlspecialchars($row['MobileNumber']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="alternatePhoneNumber" class="form-label">Alternate Phone Number</label>
                        <input type="text" class="form-control" id="alternatePhoneNumber" name="alternatePhoneNumber" value="<?php echo htmlspecialchars($row['AlternatePhoneNumber']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="company" class="form-label">Company</label>
                        <input type="text" class="form-control" id="company" name="company" value="<?php echo htmlspecialchars($row['Company']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="alternateMobileNumber" class="form-label">Alternate Mobile Number</label>
                        <input type="text" class="form-control" id="alternateMobileNumber" name="alternateMobileNumber" value="<?php echo htmlspecialchars($row['AlternateMobileNumber']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($row['Address']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="custId" class="form-label">Cust Id</label>
                        <input type="text" class="form-control" id="custId" name="custId" value="<?php echo htmlspecialchars($row['CustId']); ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php } ?>
</tbody>
</table>

<!-- Add Contact Modal -->
<div class="modal fade" id="addContactModal" tabindex="-1" aria-labelledby="addContactModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <?php if (has_permission('add')): ?>
                <h5 class="modal-title" id="addContactModalLabel">Add Contact</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <?php endif; ?>
            </div>
            <form method="post" action="contact.php">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">

                    <div class="mb-3">
                        <label for="custName" class="form-label">Cust Name</label>
                        <input type="text" class="form-control" id="custName" name="custName">
                    </div>
                    <div class="mb-3">
                        <label for="phoneNumber" class="form-label">Phone Number</label>
                        <input type="text" class="form-control" id="phoneNumber" name="phoneNumber">
                    </div>
                    <div class="mb-3">
                        <label for="mobileNumber" class="form-label">Mobile Number</label>
                        <input type="text" class="form-control" id="mobileNumber" name="mobileNumber">
                    </div>
                    <div class="mb-3">
                        <label for="alternatePhoneNumber" class="form-label">Alternate Phone Number</label>
                        <input type="text" class="form-control" id="alternatePhoneNumber" name="alternatePhoneNumber">
                    </div>
                    <div class="mb-3">
                        <label for="company" class="form-label">Company</label>
                        <input type="text" class="form-control" id="company" name="company">
                    </div>
                    <div class="mb-3">
                        <label for="alternateMobileNumber" class="form-label">Alternate Mobile Number</label>
                        <input type="text" class="form-control" id="alternateMobileNumber" name="alternateMobileNumber">
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" class="form-control" id="address" name="address">
                    </div>
                    <div class="mb-3">
                        <label for="custId" class="form-label">Cust Id</label>
                        <input type="text" class="form-control" id="custId" name="custId">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Contact</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Upload CSV Modal -->
<div class="modal fade" id="uploadCSVModal" tabindex="-1" aria-labelledby="uploadCSVModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="uploadCSVModalLabel">Upload Contacts CSV</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="contact.php" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="upload_csv">
                    <div class="mb-3">
                        <label for="csv_file" class="form-label">Select CSV File</label>
                        <input type="file" class="form-control" id="csv_file" name="csv_file" accept=".csv" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Upload CSV</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['extension'])) {
    $extension = trim($_POST['extension']);
    $_SESSION['manager_extension'] = $extension;
    echo "Extension saved: $extension";
}
?>